// Feedbin-style Readability & Full-Text Content Extractor
class ReaderExtractor {

    static extractArticle(html, fallbackTitle = '') {
        try {
            const parser = new DOMParser();
            const doc = parser.parseFromString(html, 'text/html');

            // Remove non-content elements
            const removeSelectors = [
                'script', 'style', 'noscript', 'iframe', 'header', 'footer', 'nav',
                'aside', '.nav', '.navigation', '.sidebar', '.menu', '.cookie', '.advertisement',
                '.ad', '.ads', '.banner', '.social-share', '.share-buttons', '.comments',
                '#comments', '#disqus_thread', '.related-posts', '.newsletter'
            ];

            removeSelectors.forEach(selector => {
                doc.querySelectorAll(selector).forEach(el => el.remove());
            });

            // Find best candidate for article content
            const candidateSelectors = [
                'article',
                '[itemprop="articleBody"]',
                '.article-content',
                '.post-content',
                '.entry-content',
                '.story-body',
                '.content-body',
                '.main-content',
                'main'
            ];

            let bestElement = null;

            for (const selector of candidateSelectors) {
                const el = doc.querySelector(selector);
                if (el && el.textContent.trim().length > 300) {
                    bestElement = el;
                    break;
                }
            }

            // Fallback: score elements by paragraph count and text length
            if (!bestElement) {
                const elements = doc.querySelectorAll('div, section');
                let maxScore = 0;

                elements.forEach(el => {
                    const paragraphs = el.querySelectorAll('p');
                    const textLength = el.textContent.trim().length;
                    const score = paragraphs.length * 100 + textLength;

                    if (score > maxScore && paragraphs.length >= 2) {
                        maxScore = score;
                        bestElement = el;
                    }
                });
            }

            if (!bestElement) {
                return null;
            }

            // Clean up relative URLs to absolute if base is available
            const cleanContent = this.cleanExtractedHtml(bestElement);
            return cleanContent;

        } catch (e) {
            console.error('Extraction error:', e);
            return null;
        }
    }

    static cleanExtractedHtml(element) {
        // Clone element
        const clone = element.cloneNode(true);

        // Remove dangerous or unnecessary attributes
        const allElements = clone.querySelectorAll('*');
        allElements.forEach(el => {
            el.removeAttribute('style');
            el.removeAttribute('class');
            el.removeAttribute('id');
            el.removeAttribute('onclick');
            el.removeAttribute('data-track');
        });

        // Ensure images are responsive
        clone.querySelectorAll('img').forEach(img => {
            img.setAttribute('loading', 'lazy');
            // Remove huge inline width/height
            img.removeAttribute('width');
            img.removeAttribute('height');
        });

        return clone.innerHTML;
    }
}
