// High-Speed In-Memory + Persistent IndexedDB Storage Engine for Kevki
class KevkiStorage {

    constructor() {
        this.dbName = 'KevkiDB';
        this.dbVersion = 1;
        this.db = null;
        this._feedsCache = null;
        this._articlesCache = null;
    }

    async init() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(this.dbName, this.dbVersion);

            request.onupgradeneeded = (event) => {
                const db = event.target.result;

                if (!db.objectStoreNames.contains('feeds')) {
                    const feedsStore = db.createObjectStore('feeds', { keyPath: 'id' });
                    feedsStore.createIndex('category', 'category', { unique: false });
                }

                if (!db.objectStoreNames.contains('articles')) {
                    const articlesStore = db.createObjectStore('articles', { keyPath: 'id' });
                    articlesStore.createIndex('feedId', 'feedId', { unique: false });
                    articlesStore.createIndex('timestamp', 'timestamp', { unique: false });
                    articlesStore.createIndex('unread', 'unread', { unique: false });
                    articlesStore.createIndex('starred', 'starred', { unique: false });
                }

                if (!db.objectStoreNames.contains('settings')) {
                    db.createObjectStore('settings', { keyPath: 'key' });
                }
            };

            request.onsuccess = async (event) => {
                this.db = event.target.result;
                await this._warmCache();
                resolve(this.db);
            };

            request.onerror = (event) => {
                console.error('IndexedDB init error:', event.target.error);
                reject(event.target.error);
            };
        });
    }

    async _warmCache() {
        return new Promise((resolve) => {
            try {
                const tx = this.db.transaction(['feeds', 'articles'], 'readonly');
                const feedsReq = tx.objectStore('feeds').getAll();
                const articlesReq = tx.objectStore('articles').getAll();

                feedsReq.onsuccess = () => {
                    this._feedsCache = feedsReq.result || [];
                };
                articlesReq.onsuccess = () => {
                    this._articlesCache = new Map();
                    (articlesReq.result || []).forEach(a => {
                        this._articlesCache.set(a.id, a);
                    });
                };
                tx.oncomplete = () => resolve();
                tx.onerror = () => resolve();
            } catch (e) {
                resolve();
            }
        });
    }

    async getAllFeeds() {
        if (this._feedsCache !== null) {
            return [...this._feedsCache];
        }
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['feeds'], 'readonly');
            const store = transaction.objectStore('feeds');
            const request = store.getAll();

            request.onsuccess = () => {
                this._feedsCache = request.result || [];
                resolve([...this._feedsCache]);
            };
            request.onerror = () => reject(request.error);
        });
    }

    async saveFeed(feed) {
        if (this._feedsCache !== null) {
            const idx = this._feedsCache.findIndex(f => f.id === feed.id);
            if (idx >= 0) {
                this._feedsCache[idx] = feed;
            } else {
                this._feedsCache.push(feed);
            }
        }
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['feeds'], 'readwrite');
            const store = transaction.objectStore('feeds');
            const request = store.put(feed);

            request.onsuccess = () => resolve(feed);
            request.onerror = () => reject(request.error);
        });
    }

    async deleteFeed(feedId) {
        if (this._feedsCache !== null) {
            this._feedsCache = this._feedsCache.filter(f => f.id !== feedId);
        }
        if (this._articlesCache !== null) {
            for (const [id, art] of this._articlesCache.entries()) {
                if (art.feedId === feedId) {
                    this._articlesCache.delete(id);
                }
            }
        }
        return new Promise((resolve, reject) => {
            const tx = this.db.transaction(['feeds', 'articles'], 'readwrite');
            const feedsStore = tx.objectStore('feeds');
            const articlesStore = tx.objectStore('articles');

            feedsStore.delete(feedId);

            const index = articlesStore.index('feedId');
            const req = index.openCursor(IDBKeyRange.only(feedId));
            req.onsuccess = (event) => {
                const cursor = event.target.result;
                if (cursor) {
                    cursor.delete();
                    cursor.continue();
                }
            };

            tx.oncomplete = () => resolve(true);
            tx.onerror = () => reject(tx.error);
        });
    }

    async deleteArticle(articleId) {
        if (this._articlesCache !== null) {
            this._articlesCache.delete(articleId);
        }
        return new Promise((resolve, reject) => {
            const tx = this.db.transaction(['articles'], 'readwrite');
            const store = tx.objectStore('articles');
            store.delete(articleId);
            tx.oncomplete = () => resolve(true);
            tx.onerror = () => reject(tx.error);
        });
    }

    async updateArticleTag(articleId, tag) {
        const cleanTag = tag ? tag.trim() : '';
        if (this._articlesCache !== null && this._articlesCache.has(articleId)) {
            this._articlesCache.get(articleId).customTag = cleanTag;
        }
        return new Promise((resolve, reject) => {
            const tx = this.db.transaction(['articles'], 'readwrite');
            const store = tx.objectStore('articles');
            const req = store.get(articleId);
            req.onsuccess = () => {
                const art = req.result;
                if (art) {
                    art.customTag = cleanTag;
                    store.put(art);
                }
            };
            tx.oncomplete = () => resolve(true);
            tx.onerror = () => reject(tx.error);
        });
    }

    async saveArticles(newArticles, feedId) {
        const newlyAdded = [];
        return new Promise((resolve, reject) => {
            const tx = this.db.transaction(['articles'], 'readwrite');
            const store = tx.objectStore('articles');

            for (const article of newArticles) {
                article.feedId = feedId;

                if (this._articlesCache !== null) {
                    const existing = this._articlesCache.get(article.id);
                    if (existing) {
                        article.unread = existing.unread;
                        article.starred = existing.starred;
                        if (existing.customTag) article.customTag = existing.customTag;
                        if (existing.fullContent) article.fullContent = existing.fullContent;
                    } else {
                        newlyAdded.push(article);
                    }
                    this._articlesCache.set(article.id, article);
                    store.put(article);
                } else {
                    const getReq = store.get(article.id);
                    getReq.onsuccess = () => {
                        const existing = getReq.result;
                        if (existing) {
                            article.unread = existing.unread;
                            article.starred = existing.starred;
                            if (existing.customTag) article.customTag = existing.customTag;
                            if (existing.fullContent) article.fullContent = existing.fullContent;
                        } else {
                            newlyAdded.push(article);
                        }
                        store.put(article);
                    };
                }
            }

            tx.oncomplete = () => resolve({ newlyAdded, totalCount: newArticles.length });
            tx.onerror = () => reject(tx.error);
        });
    }

    async saveSingleArticle(article) {
        if (this._articlesCache !== null) {
            this._articlesCache.set(article.id, article);
        }
        return new Promise((resolve, reject) => {
            const tx = this.db.transaction(['articles'], 'readwrite');
            const store = tx.objectStore('articles');
            store.put(article);
            tx.oncomplete = () => resolve(article);
            tx.onerror = () => reject(tx.error);
        });
    }

    async getAllArticleIds() {
        if (this._articlesCache !== null) {
            return Array.from(this._articlesCache.keys());
        }
        return new Promise((resolve) => {
            try {
                const tx = this.db.transaction(['articles'], 'readonly');
                const store = tx.objectStore('articles');
                if (store.getAllKeys) {
                    const req = store.getAllKeys();
                    req.onsuccess = () => resolve(req.result || []);
                    req.onerror = () => resolve([]);
                } else {
                    resolve([]);
                }
            } catch (e) {
                resolve([]);
            }
        });
    }

    async getArticleById(articleId) {
        if (this._articlesCache !== null && this._feedsCache !== null) {
            const article = this._articlesCache.get(articleId);
            if (!article) return null;
            if (article.feedId === 'saved_items') {
                article.feedTitle = article.domain || 'Kaydedilen';
                article.feedIcon = article.domain ? `https://www.google.com/s2/favicons?domain=${article.domain}&sz=128` : '';
                article.categoryName = article.customTag || 'Kaydedilenler';
                return article;
            }
            const feed = this._feedsCache.find(f => f.id === article.feedId);
            article.feedTitle = feed ? feed.title : (article.domain || 'Kaynak');
            article.feedIcon = feed && feed.icon ? feed.icon.replace(/favicons\?domain=([^&]+)$/, 'favicons?domain=$1&sz=128') : '';
            article.categoryName = article.customTag || (feed && feed.category ? feed.category : 'Genel');
            return article;
        }

        return new Promise((resolve, reject) => {
            const tx = this.db.transaction(['articles', 'feeds'], 'readonly');
            const articlesStore = tx.objectStore('articles');
            const feedsStore = tx.objectStore('feeds');

            const req = articlesStore.get(articleId);
            req.onsuccess = () => {
                const article = req.result;
                if (!article) {
                    resolve(null);
                    return;
                }
                if (article.feedId === 'saved_items') {
                    article.feedTitle = article.domain || 'Kaydedilen';
                    article.feedIcon = article.domain ? `https://www.google.com/s2/favicons?domain=${article.domain}&sz=128` : '';
                    article.categoryName = article.customTag || 'Kaydedilenler';
                    resolve(article);
                    return;
                }
                const feedReq = feedsStore.get(article.feedId);
                feedReq.onsuccess = () => {
                    const feed = feedReq.result;
                    article.feedTitle = feed ? feed.title : (article.domain || 'Kaynak');
                    article.feedIcon = feed && feed.icon ? feed.icon.replace(/favicons\?domain=([^&]+)$/, 'favicons?domain=$1&sz=128') : '';
                    article.categoryName = article.customTag || (feed && feed.category ? feed.category : 'Genel');
                    resolve(article);
                };
                feedReq.onerror = () => resolve(article);
            };
            req.onerror = () => reject(req.error);
        });
    }

    async getArticles({
        filter = 'all',
        feedId = null,
        category = null,
        searchQuery = '',
        sortBy = 'newest'
    } = {}) {
        if (this._feedsCache === null || this._articlesCache === null) {
            await this._warmCache();
        }

        const feedMap = {};
        (this._feedsCache || []).forEach(f => { feedMap[f.id] = f; });

        let articles = [];
        for (const a of (this._articlesCache ? this._articlesCache.values() : [])) {
            const isSaved = (a.feedId === 'saved_items');
            const f = feedMap[a.feedId];
            if (!isSaved && !f) continue;

            if (isSaved) {
                a.feedTitle = a.author || a.domain || 'Kaydedilen';
                a.feedIcon = a.domain ? `https://www.google.com/s2/favicons?domain=${a.domain}&sz=128` : '';
                a.categoryName = a.customTag || 'Kaydedilenler';
            } else {
                a.feedTitle = f ? f.title : (a.domain || 'Kaynak');
                a.feedIcon = f && f.icon ? f.icon.replace(/favicons\?domain=([^&]+)$/, 'favicons?domain=$1&sz=128') : '';
                a.categoryName = a.customTag || (f && f.category ? f.category : 'Genel');
            }

            if (feedId && a.feedId !== feedId) continue;
            if (!feedId && category && a.categoryName !== category) continue;

            if (filter === 'unread' && !a.unread) continue;
            if (filter === 'starred' && !a.starred) continue;
            if (filter === 'tagged' && !a.customTag && (!a.categoryName || a.categoryName === 'Genel')) continue;

            articles.push(a);
        }

        if (searchQuery && searchQuery.trim()) {
            const q = searchQuery.toLowerCase().trim();
            articles = articles.filter(a =>
                (a.title && a.title.toLowerCase().includes(q)) ||
                (a.summary && a.summary.toLowerCase().includes(q)) ||
                (a.feedTitle && a.feedTitle.toLowerCase().includes(q)) ||
                (a.categoryName && a.categoryName.toLowerCase().includes(q))
            );
        }

        if (sortBy === 'oldest') {
            articles.sort((a, b) => a.timestamp - b.timestamp);
        } else if (sortBy === 'shortest') {
            articles.sort((a, b) => (a.readingTimeMin || 1) - (b.readingTimeMin || 1));
        } else if (sortBy === 'longest') {
            articles.sort((a, b) => (b.readingTimeMin || 1) - (a.readingTimeMin || 1));
        } else if (sortBy === 'title_az') {
            articles.sort((a, b) => (a.title || '').localeCompare(b.title || '', 'tr'));
        } else if (sortBy === 'source_az') {
            articles.sort((a, b) => (a.feedTitle || '').localeCompare(b.feedTitle || '', 'tr'));
        } else {
            articles.sort((a, b) => b.timestamp - a.timestamp);
        }

        return articles;
    }

    async markArticleRead(articleId, isRead) {
        if (this._articlesCache !== null && this._articlesCache.has(articleId)) {
            this._articlesCache.get(articleId).unread = !isRead;
        }
        return new Promise((resolve, reject) => {
            const tx = this.db.transaction(['articles'], 'readwrite');
            const store = tx.objectStore('articles');
            const req = store.get(articleId);

            req.onsuccess = () => {
                const article = req.result;
                if (article) {
                    article.unread = !isRead;
                    store.put(article);
                }
            };

            tx.oncomplete = () => resolve(true);
            tx.onerror = () => reject(tx.error);
        });
    }

    async markAllRead(feedId = null, category = null) {
        if (this._articlesCache !== null) {
            for (const a of this._articlesCache.values()) {
                if (feedId && a.feedId !== feedId) continue;
                if (category && a.categoryName !== category) continue;
                a.unread = false;
            }
        }
        return new Promise((resolve, reject) => {
            const tx = this.db.transaction(['articles', 'feeds'], 'readwrite');
            const articlesStore = tx.objectStore('articles');
            const feedsStore = tx.objectStore('feeds');

            const feedsReq = feedsStore.getAll();
            feedsReq.onsuccess = () => {
                const feedMap = {};
                (feedsReq.result || []).forEach(f => { feedMap[f.id] = f; });

                const req = articlesStore.openCursor();
                req.onsuccess = (event) => {
                    const cursor = event.target.result;
                    if (cursor) {
                        const article = cursor.value;
                        let match = true;
                        if (feedId && article.feedId !== feedId) match = false;
                        if (category) {
                            const f = feedMap[article.feedId];
                            const catName = article.customTag || (f && f.category ? f.category : '');
                            if (catName !== category) match = false;
                        }

                        if (match && article.unread) {
                            article.unread = false;
                            cursor.update(article);
                        }
                        cursor.continue();
                    }
                };
            };

            tx.oncomplete = () => resolve(true);
            tx.onerror = () => reject(tx.error);
        });
    }

    async toggleStar(articleId) {
        if (this._articlesCache !== null && this._articlesCache.has(articleId)) {
            const cached = this._articlesCache.get(articleId);
            cached.starred = !cached.starred;
        }
        return new Promise((resolve, reject) => {
            const tx = this.db.transaction(['articles'], 'readwrite');
            const store = tx.objectStore('articles');
            const req = store.get(articleId);

            req.onsuccess = () => {
                const article = req.result;
                if (article) {
                    article.starred = !article.starred;
                    if (this._articlesCache !== null) {
                        this._articlesCache.set(articleId, article);
                    }
                    store.put(article);
                    resolve(article.starred);
                } else {
                    resolve(false);
                }
            };

            tx.onerror = () => reject(tx.error);
        });
    }

    async saveFullContent(articleId, fullContent) {
        if (this._articlesCache !== null && this._articlesCache.has(articleId)) {
            this._articlesCache.get(articleId).fullContent = fullContent;
        }
        return new Promise((resolve, reject) => {
            const tx = this.db.transaction(['articles'], 'readwrite');
            const store = tx.objectStore('articles');
            const req = store.get(articleId);

            req.onsuccess = () => {
                const article = req.result;
                if (article) {
                    article.fullContent = fullContent;
                    store.put(article);
                }
            };

            tx.oncomplete = () => resolve(true);
            tx.onerror = () => reject(tx.error);
        });
    }

    async clearAllData() {
        this._feedsCache = [];
        this._articlesCache = new Map();
        return new Promise((resolve, reject) => {
            const tx = this.db.transaction(['articles', 'feeds'], 'readwrite');
            tx.objectStore('articles').clear();
            tx.objectStore('feeds').clear();
            tx.oncomplete = () => resolve(true);
            tx.onerror = () => reject(tx.error);
        });
    }

    async getSetting(key, defaultValue = null) {
        return new Promise((resolve) => {
            const tx = this.db.transaction(['settings'], 'readonly');
            const store = tx.objectStore('settings');
            const req = store.get(key);
            req.onsuccess = () => {
                resolve(req.result ? req.result.value : defaultValue);
            };
            req.onerror = () => resolve(defaultValue);
        });
    }

    async setSetting(key, value) {
        return new Promise((resolve, reject) => {
            const tx = this.db.transaction(['settings'], 'readwrite');
            const store = tx.objectStore('settings');
            const req = store.put({ key: key, value: value });
            req.onsuccess = () => resolve(value);
            tx.onerror = () => reject(req.error);
        });
    }

    async exportOpml() {
        const feeds = await this.getAllFeeds();
        const categories = {};

        feeds.forEach(f => {
            const cat = f.category || 'Genel';
            if (!categories[cat]) categories[cat] = [];
            categories[cat].push(f);
        });

        let opml = `<?xml version="1.0" encoding="UTF-8"?>\n`;
        opml += `<opml version="1.0">\n`;
        opml += `  <head>\n    <title>Kevki Dışa Aktarım</title>\n  </head>\n`;
        opml += `  <body>\n`;

        for (const [cat, list] of Object.entries(categories)) {
            opml += `    <outline text="${escapeXml(cat)}" title="${escapeXml(cat)}">\n`;
            list.forEach(feed => {
                opml += `      <outline type="rss" text="${escapeXml(feed.title)}" title="${escapeXml(feed.title)}" xmlUrl="${escapeXml(feed.url)}" htmlUrl="${escapeXml(feed.siteUrl || '')}"/>\n`;
            });
            opml += `    </outline>\n`;
        }

        opml += `  </body>\n</opml>`;
        return opml;
    }

    async importOpml(opmlText) {
        const parser = new DOMParser();
        const doc = parser.parseFromString(opmlText, 'text/xml');
        const outlines = doc.querySelectorAll('outline[xmlUrl]');
        const importedFeeds = [];

        outlines.forEach(outline => {
            const title = outline.getAttribute('title') || outline.getAttribute('text') || 'Kaynak';
            const url = outline.getAttribute('xmlUrl');
            const siteUrl = outline.getAttribute('htmlUrl') || '';

            let category = 'Genel';
            const parent = outline.parentElement;
            if (parent && parent.tagName.toLowerCase() === 'outline' && !parent.getAttribute('xmlUrl')) {
                category = parent.getAttribute('title') || parent.getAttribute('text') || 'Genel';
            }
            if (url && url.includes('youtube.com/feeds/videos.xml') && category === 'Genel') {
                category = 'YouTube';
            } else if (url && url.includes('reddit.com/r/') && category === 'Genel') {
                category = 'Reddit';
            }

            if (url) {
                const id = 'feed_' + Math.abs(this.hashCode(url)).toString(36);
                let icon = '';
                try {
                    const host = new URL(siteUrl || url).hostname;
                    icon = `https://www.google.com/s2/favicons?domain=${host}&sz=128`;
                } catch (ignored) {}
                importedFeeds.push({
                    id: id,
                    title: title.trim(),
                    url: url.trim(),
                    siteUrl: siteUrl.trim(),
                    category: category.trim(),
                    icon: icon,
                    notificationsEnabled: true
                });
            }
        });

        for (const feed of importedFeeds) {
            await this.saveFeed(feed);
        }

        return importedFeeds;
    }

    /**
     * Universal Importer for:
     * - YouTube Subscriptions (Google Takeout subscriptions.csv / subscriptions.json / OPML)
     * - Reddit (subscribed_subreddits.csv / saved_posts.csv / saved_comments.csv / JSON / subreddit list)
     * - WhatsApp Channels (channel URLs or exported WhatsApp Channel text logs)
     * - Pocket, Instapaper, Matter, Raindrop.io, Readwise Reader (.csv, .html, .json, .opml)
     */
    async importFromExternalService(contentText, fileName = '', serviceName = '') {
        const trimmed = (contentText || '').trim();
        if (!trimmed) return { articlesCount: 0, feedsCount: 0, importedFeeds: [] };

        const svcLower = (serviceName || '').toLowerCase();
        const fileLower = (fileName || '').toLowerCase();

        // 1. Check if OPML / XML feed list
        if (trimmed.includes('<opml') || trimmed.includes('xmlUrl=')) {
            const feeds = await this.importOpml(trimmed);
            return { articlesCount: 0, feedsCount: feeds.length, importedFeeds: feeds };
        }

        const savedArticles = [];
        const importedFeeds = [];

        // 2. Check if WhatsApp Channel export / text log
        if (svcLower.includes('whatsapp') || fileLower.includes('whatsapp') || trimmed.includes('whatsapp.com/channel/')) {
            // Extract any WhatsApp channel URLs as feeds
            const chMatches = trimmed.match(/https?:\/\/(?:www\.)?(?:whatsapp\.com|wa\.me)\/channel\/[a-zA-Z0-9_-]+/gi) || [];
            const uniqueChannels = [...new Set(chMatches)];
            for (const chUrl of uniqueChannels) {
                const idPart = chUrl.split('/channel/')[1] || '';
                const feed = {
                    id: 'feed_' + Math.abs(this.hashCode(chUrl)).toString(36),
                    title: `WhatsApp Kanalı (${idPart.substring(0, 8)})`,
                    url: chUrl,
                    siteUrl: chUrl,
                    category: 'WhatsApp',
                    icon: 'https://www.google.com/s2/favicons?domain=whatsapp.com&sz=64',
                    notificationsEnabled: true
                };
                await this.saveFeed(feed);
                importedFeeds.push(feed);
            }

            // Also parse message logs if text has content beyond bare URLs
            const nonUrlText = trimmed.replace(/https?:\/\/(?:www\.)?(?:whatsapp\.com|wa\.me)\/channel\/[a-zA-Z0-9_-]+/gi, '').trim();
            if (nonUrlText.length > 15) {
                const waArticles = FeedParser.parseWhatsAppTextExport(trimmed, 'WhatsApp Kanalı');
                for (const art of waArticles) {
                    await this.saveSingleArticle(art);
                    savedArticles.push(art);
                }
            }
            if (importedFeeds.length > 0 || savedArticles.length > 0) {
                return { articlesCount: savedArticles.length, feedsCount: importedFeeds.length, importedFeeds };
            }
        }

        // 3. Check if JSON (Google Takeout YouTube subscriptions.json, Reddit JSON, Readwise/Matter JSON)
        if (trimmed.startsWith('[') || trimmed.startsWith('{')) {
            try {
                const parsedJson = JSON.parse(trimmed);
                const list = Array.isArray(parsedJson) ? parsedJson : (parsedJson.items || parsedJson.subscriptions || parsedJson.data?.children || []);
                for (const item of list) {
                    // YouTube Takeout JSON item
                    const ytChannelId = item?.snippet?.resourceId?.channelId || item?.channelId || item?.channel_id;
                    if (ytChannelId && /^UC[a-zA-Z0-9_-]{20,}$/.test(ytChannelId)) {
                        const chTitle = item?.snippet?.title || item?.title || `YouTube (${ytChannelId.substring(0, 8)})`;
                        const feedUrl = `https://www.youtube.com/feeds/videos.xml?channel_id=${ytChannelId}`;
                        const feed = {
                            id: 'feed_' + Math.abs(this.hashCode(feedUrl)).toString(36),
                            title: chTitle.trim(),
                            url: feedUrl,
                            siteUrl: `https://www.youtube.com/channel/${ytChannelId}`,
                            category: 'YouTube',
                            icon: 'https://www.google.com/s2/favicons?domain=youtube.com',
                            notificationsEnabled: true
                        };
                        await this.saveFeed(feed);
                        importedFeeds.push(feed);
                        continue;
                    }

                    // Reddit JSON item
                    const redditData = item?.data || item;
                    if (redditData?.subreddit || redditData?.display_name_prefixed) {
                        const subName = (redditData.display_name || redditData.subreddit || '').replace(/^\/?r\//i, '').trim();
                        if (redditData.permalink || redditData.url) {
                            const link = redditData.permalink
                                ? (redditData.permalink.startsWith('http') ? redditData.permalink : `https://www.reddit.com${redditData.permalink}`)
                                : redditData.url;
                            const title = redditData.title || this.extractTitleFromRedditUrl(link) || `r/${subName}`;
                            savedArticles.push(this.buildImportedArticle(link, title, 'Reddit', Date.now()));
                        } else if (subName) {
                            const feedUrl = `https://www.reddit.com/r/${subName}/.rss`;
                            const feed = {
                                id: 'feed_' + Math.abs(this.hashCode(feedUrl)).toString(36),
                                title: `r/${subName}`,
                                url: feedUrl,
                                siteUrl: `https://www.reddit.com/r/${subName}/`,
                                category: 'Reddit',
                                icon: 'https://www.google.com/s2/favicons?domain=reddit.com',
                                notificationsEnabled: true
                            };
                            await this.saveFeed(feed);
                            importedFeeds.push(feed);
                        }
                        continue;
                    }

                    // Generic JSON bookmark item
                    const url = item?.url || item?.link || item?.given_url;
                    if (url && /^https?:\/\//i.test(url)) {
                        const title = item?.title || FeedParser.extractDomain(url) || url;
                        savedArticles.push(this.buildImportedArticle(url, title, serviceName || 'İçe Aktarılan', Date.now()));
                    }
                }
                for (const art of savedArticles) {
                    await this.saveSingleArticle(art);
                }
                return { articlesCount: savedArticles.length, feedsCount: importedFeeds.length, importedFeeds };
            } catch (e) {
                console.warn('JSON import fallback to CSV/text:', e);
            }
        }

        // 4. Check if HTML export (Pocket / Instapaper / Raindrop bookmarks)
        if (trimmed.startsWith('<!DOCTYPE') || trimmed.startsWith('<html') || trimmed.includes('<a href=')) {
            const parser = new DOMParser();
            const doc = parser.parseFromString(trimmed, 'text/html');
            const links = doc.querySelectorAll('a[href]');
            links.forEach(a => {
                const href = (a.getAttribute('href') || '').trim();
                if (!href.startsWith('http://') && !href.startsWith('https://')) return;
                const title = (a.textContent || '').trim() || FeedParser.extractDomain(href) || href;
                const tags = a.getAttribute('tags') || serviceName || 'İçe Aktarılan';
                const timeAttr = a.getAttribute('time_added') || a.getAttribute('add_date');
                const ts = timeAttr && /^\d+$/.test(timeAttr) ? parseInt(timeAttr, 10) * 1000 : Date.now();
                savedArticles.push(this.buildImportedArticle(href, title, tags, ts));
            });
        } else {
            // 5. Parse CSV / Line-by-line (YouTube Takeout CSV, Reddit CSV, Pocket, Instapaper, Matter, Raindrop, Readwise)
            const rows = this.parseCsvRows(trimmed);
            if (rows.length > 0) {
                const header = rows[0].map(h => h.toLowerCase().trim());

                // Check 5A: Google Takeout YouTube Subscriptions CSV
                // Columns: "Channel Id,Channel Url,Channel Title" or "Kanal Kimliği,Kanal URL'si,Kanal Başlığı"
                const ytIdIdx = header.findIndex(h => h === 'channel id' || h === 'channel_id' || h.includes('kanal kimli'));
                const ytUrlIdx = header.findIndex(h => h === 'channel url' || h === 'channel_url' || h.includes('kanal url'));
                const ytTitleIdx = header.findIndex(h => h === 'channel title' || h === 'channel_title' || h.includes('kanal başlı'));

                if (ytIdIdx >= 0 || ytUrlIdx >= 0 || svcLower.includes('youtube')) {
                    const startRow = (ytIdIdx >= 0 || ytUrlIdx >= 0) ? 1 : 0;
                    for (let i = startRow; i < rows.length; i++) {
                        const row = rows[i];
                        if (!row || row.length === 0) continue;
                        let channelId = ytIdIdx >= 0 && row[ytIdIdx] ? row[ytIdIdx].trim() : '';
                        const rawUrl = ytUrlIdx >= 0 && row[ytUrlIdx] ? row[ytUrlIdx].trim() : (row[0] || '').trim();
                        let chTitle = ytTitleIdx >= 0 && row[ytTitleIdx] ? row[ytTitleIdx].trim() : (row[2] || row[1] || '').trim();

                        if (!channelId) {
                            const m = rawUrl.match(/(UC[a-zA-Z0-9_-]{22})/);
                            if (m) channelId = m[1];
                        }
                        if (channelId && /^UC[a-zA-Z0-9_-]{20,}$/.test(channelId)) {
                            const feedUrl = `https://www.youtube.com/feeds/videos.xml?channel_id=${channelId}`;
                            const feed = {
                                id: 'feed_' + Math.abs(this.hashCode(feedUrl)).toString(36),
                                title: chTitle || `YouTube (${channelId.substring(0, 8)})`,
                                url: feedUrl,
                                siteUrl: `https://www.youtube.com/channel/${channelId}`,
                                category: 'YouTube',
                                icon: 'https://www.google.com/s2/favicons?domain=youtube.com',
                                notificationsEnabled: true
                            };
                            await this.saveFeed(feed);
                            importedFeeds.push(feed);
                        }
                    }
                    if (importedFeeds.length > 0) {
                        return { articlesCount: 0, feedsCount: importedFeeds.length, importedFeeds };
                    }
                }

                // Check 5B: Reddit Export CSV (subscribed_subreddits.csv, saved_posts.csv, saved_comments.csv)
                const subIdx = header.findIndex(h => h === 'subreddit' || h === 'subreddit_name');
                const permalinkIdx = header.findIndex(h => h === 'permalink');

                if (subIdx >= 0 && permalinkIdx < 0) {
                    // subscribed_subreddits.csv
                    for (let i = 1; i < rows.length; i++) {
                        const rawSub = (rows[i][subIdx] || '').replace(/^\/?r\//i, '').trim();
                        if (!rawSub || !/^[a-zA-Z0-9_]{2,50}$/.test(rawSub)) continue;
                        const feedUrl = `https://www.reddit.com/r/${rawSub}/.rss`;
                        const feed = {
                            id: 'feed_' + Math.abs(this.hashCode(feedUrl)).toString(36),
                            title: `r/${rawSub}`,
                            url: feedUrl,
                            siteUrl: `https://www.reddit.com/r/${rawSub}/`,
                            category: 'Reddit',
                            icon: 'https://www.google.com/s2/favicons?domain=reddit.com',
                            notificationsEnabled: true
                        };
                        await this.saveFeed(feed);
                        importedFeeds.push(feed);
                    }
                    if (importedFeeds.length > 0) {
                        return { articlesCount: 0, feedsCount: importedFeeds.length, importedFeeds };
                    }
                }

                if (permalinkIdx >= 0 || svcLower.includes('reddit')) {
                    const startRow = permalinkIdx >= 0 ? 1 : 0;
                    for (let i = startRow; i < rows.length; i++) {
                        const row = rows[i];
                        const cell = permalinkIdx >= 0 ? (row[permalinkIdx] || '').trim() : (row.find(c => (c || '').includes('reddit.com') || /^\/?r\//i.test((c || '').trim())) || (row[0] || '').trim());
                        if (!cell) continue;

                        // If it's a bare subreddit like "r/turkey" or "technology"
                        if (/^(?:\/?r\/)?[a-zA-Z0-9_]{2,40}$/.test(cell) && !cell.includes('/comments/')) {
                            const subName = cell.replace(/^\/?r\//i, '');
                            const feedUrl = `https://www.reddit.com/r/${subName}/.rss`;
                            const feed = {
                                id: 'feed_' + Math.abs(this.hashCode(feedUrl)).toString(36),
                                title: `r/${subName}`,
                                url: feedUrl,
                                siteUrl: `https://www.reddit.com/r/${subName}/`,
                                category: 'Reddit',
                                icon: 'https://www.google.com/s2/favicons?domain=reddit.com',
                                notificationsEnabled: true
                            };
                            await this.saveFeed(feed);
                            importedFeeds.push(feed);
                        } else if (cell.includes('reddit.com/r/') && !cell.includes('/comments/')) {
                            const m = cell.match(/reddit\.com\/r\/([a-zA-Z0-9_]+)/i);
                            if (m && m[1]) {
                                const subName = m[1];
                                const feedUrl = `https://www.reddit.com/r/${subName}/.rss`;
                                const feed = {
                                    id: 'feed_' + Math.abs(this.hashCode(feedUrl)).toString(36),
                                    title: `r/${subName}`,
                                    url: feedUrl,
                                    siteUrl: `https://www.reddit.com/r/${subName}/`,
                                    category: 'Reddit',
                                    icon: 'https://www.google.com/s2/favicons?domain=reddit.com',
                                    notificationsEnabled: true
                                };
                                await this.saveFeed(feed);
                                importedFeeds.push(feed);
                            }
                        } else {
                            // Saved Reddit post permalink
                            const fullUrl = cell.startsWith('http') ? cell : `https://www.reddit.com${cell.startsWith('/') ? '' : '/'}${cell}`;
                            const title = this.extractTitleFromRedditUrl(fullUrl) || fullUrl;
                            savedArticles.push(this.buildImportedArticle(fullUrl, title, 'Reddit', Date.now() - i * 1000));
                        }
                    }
                    for (const art of savedArticles) {
                        await this.saveSingleArticle(art);
                    }
                    if (importedFeeds.length > 0 || savedArticles.length > 0) {
                        return { articlesCount: savedArticles.length, feedsCount: importedFeeds.length, importedFeeds };
                    }
                }

                // Check 5C: Standard CSV (OPML/CSV Feed Lists or Saved Links CSV)
                const urlIdx = header.findIndex(h => h === 'url' || h === 'link' || h === 'uri' || h === 'given_url' || h === 'xmlurl' || h === 'feed_url' || h === 'rss');
                const titleIdx = header.findIndex(h => h === 'title' || h === 'name' || h === 'text');
                const tagIdx = header.findIndex(h => h === 'tags' || h === 'folder' || h === 'collection' || h === 'category');
                const dateIdx = header.findIndex(h => h.includes('time') || h.includes('date') || h === 'created' || h === 'saved_at');
                const isFeedCsvHeader = header.some(h => h === 'xmlurl' || h === 'feed_url' || h === 'rss' || h === 'feed');

                const startRow = urlIdx >= 0 ? 1 : 0;
                for (let i = startRow; i < rows.length; i++) {
                    const row = rows[i];
                    let url = '';
                    if (urlIdx >= 0 && row[urlIdx]) {
                        url = row[urlIdx].trim();
                    } else {
                        const found = row.find(cell => /^https?:\/\//i.test((cell || '').trim()));
                        if (found) url = found.trim();
                    }
                    if (!url || (!url.startsWith('http://') && !url.startsWith('https://'))) continue;

                    const title = (titleIdx >= 0 && row[titleIdx] ? row[titleIdx].trim() : '') || FeedParser.extractDomain(url) || url;
                    const tag = (tagIdx >= 0 && row[tagIdx] ? row[tagIdx].trim() : '') || 'Genel';

                    if (isFeedCsvHeader || /\.(rss|xml|atom)(\?.*)?$/i.test(url) || url.includes('/feeds/videos.xml') || url.includes('/feed')) {
                        let icon = '';
                        try {
                            const host = new URL(url).hostname;
                            icon = `https://www.google.com/s2/favicons?domain=${host}&sz=128`;
                        } catch (ignored) {}
                        const feed = {
                            id: 'feed_' + Math.abs(this.hashCode(url)).toString(36),
                            title: title,
                            url: url,
                            siteUrl: url,
                            category: tag || 'Genel',
                            icon: icon,
                            notificationsEnabled: true
                        };
                        await this.saveFeed(feed);
                        importedFeeds.push(feed);
                        continue;
                    }

                    let ts = Date.now();
                    if (dateIdx >= 0 && row[dateIdx]) {
                        const rawDate = row[dateIdx].trim();
                        if (/^\d{9,13}$/.test(rawDate)) {
                            ts = rawDate.length === 10 ? parseInt(rawDate, 10) * 1000 : parseInt(rawDate, 10);
                        } else {
                            const parsedD = new Date(rawDate);
                            if (!isNaN(parsedD.getTime())) ts = parsedD.getTime();
                        }
                    }
                    savedArticles.push(this.buildImportedArticle(url, title, tag, ts));
                }
            }
        }

        for (const art of savedArticles) {
            await this.saveSingleArticle(art);
        }

        return { articlesCount: savedArticles.length, feedsCount: importedFeeds.length, importedFeeds };
    }

    extractTitleFromRedditUrl(url) {
        if (!url) return '';
        const m = url.match(/\/r\/([a-zA-Z0-9_]+)\/comments\/[a-zA-Z0-9]+\/([^/?#]+)/i);
        if (m) {
            const sub = m[1];
            const slug = decodeURIComponent(m[2]).replace(/_/g, ' ').trim();
            const capitalized = slug ? slug.charAt(0).toUpperCase() + slug.slice(1) : '';
            return capitalized ? `${capitalized} (r/${sub})` : `r/${sub} Paylaşımı`;
        }
        return '';
    }

    buildImportedArticle(url, title, tag, timestamp) {
        const domain = FeedParser.extractDomain(url);
        const videoId = FeedParser.extractYoutubeVideoId(url);
        return {
            id: FeedParser.hashString('saved_' + url),
            guid: 'saved_' + url,
            feedId: 'saved_items',
            title: title,
            link: url,
            domain: domain,
            author: '',
            pubDate: new Date(timestamp).toISOString(),
            timestamp: timestamp,
            summary: url,
            content: `<p><a href="${escapeXml(url)}">${escapeXml(title)}</a></p>`,
            fullContent: null,
            thumbnail: videoId ? `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg` : '',
            readingTimeMin: 3,
            customTag: tag ? tag.split(',')[0].trim() : '',
            unread: true,
            starred: true,
            isVideo: Boolean(videoId),
            videoId: videoId || null,
            isPodcast: false,
            audioUrl: null,
            audioType: null,
            audioDuration: null,
            mediaType: videoId ? 'video' : 'article'
        };
    }

    parseCsvRows(text) {
        const rows = [];
        let current = [];
        let field = '';
        let inQuotes = false;
        for (let i = 0; i < text.length; i++) {
            const c = text[i];
            if (inQuotes) {
                if (c === '"') {
                    if (i + 1 < text.length && text[i + 1] === '"') {
                        field += '"';
                        i++;
                    } else {
                        inQuotes = false;
                    }
                } else {
                    field += c;
                }
            } else {
                if (c === '"') {
                    inQuotes = true;
                } else if (c === ',') {
                    current.push(field);
                    field = '';
                } else if (c === '\n' || c === '\r') {
                    if (c === '\r' && i + 1 < text.length && text[i + 1] === '\n') i++;
                    current.push(field);
                    if (current.some(v => v.trim() !== '')) rows.push(current);
                    current = [];
                    field = '';
                } else {
                    field += c;
                }
            }
        }
        if (field || current.length > 0) {
            current.push(field);
            if (current.some(v => v.trim() !== '')) rows.push(current);
        }
        return rows;
    }

    hashCode(str) {
        let hash = 0;
        for (let i = 0; i < str.length; i++) {
            hash = ((hash << 5) - hash) + str.charCodeAt(i);
            hash |= 0;
        }
        return hash;
    }
}

function escapeXml(unsafe) {
    if (!unsafe) return '';
    return unsafe.replace(/[<>&'"]/g, c => {
        switch (c) {
            case '<': return '&lt;';
            case '>': return '&gt;';
            case '&': return '&amp;';
            case '\'': return '&apos;';
            case '"': return '&quot;';
        }
    });
}
