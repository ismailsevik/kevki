// Kevki Application Controller — High-Speed Engine with Native YouTube Stream, Reddit, WhatsApp Channels & In-App Purchases

window.nativeFetchCallbacks = {};
window.onNativeFetchResult = function(callbackId, success, status, data, error) {
    const cb = window.nativeFetchCallbacks[callbackId];
    if (cb) {
        delete window.nativeFetchCallbacks[callbackId];
        cb({ success, status, data, error });
    }
};

window.nativeYoutubeCallbacks = {};
window.onNativeYoutubeStreamResult = function(callbackId, jsonStr) {
    const cb = window.nativeYoutubeCallbacks[callbackId];
    if (cb) {
        delete window.nativeYoutubeCallbacks[callbackId];
        try {
            cb(JSON.parse(jsonStr));
        } catch (e) {
            cb({ success: false, error: 'JSON ayrıştırma hatası' });
        }
    }
};

window.nativePurchaseCallbacks = {};
window.onNativePurchaseResult = function(callbackId, jsonStr) {
    const cb = window.nativePurchaseCallbacks[callbackId];
    if (cb) {
        delete window.nativePurchaseCallbacks[callbackId];
        try {
            cb(JSON.parse(jsonStr));
        } catch (e) {
            cb({ success: false, error: 'Satın alma yanıtı okunamadı' });
        }
    }
};

window.nativeFileCallbacks = {};
window.onNativeFilePicked = function(callbackId, jsonStr) {
    const cb = window.nativeFileCallbacks[callbackId];
    if (cb) {
        delete window.nativeFileCallbacks[callbackId];
        try {
            cb(JSON.parse(jsonStr));
        } catch (e) {
            cb({ success: false, error: 'Dosya okunamadı' });
        }
    }
};

window.handleNativeBackPressed = function() {
    if (window.app) {
        return window.app.onHardwareBack();
    }
    return false;
};

class NativeBridge {
    static isAndroid() {
        return typeof window.Android !== 'undefined';
    }

    static async fetchUrl(url) {
        if (this.isAndroid()) {
            return new Promise((resolve) => {
                const callbackId = 'cb_' + Date.now() + '_' + Math.floor(Math.random() * 10000);
                window.nativeFetchCallbacks[callbackId] = resolve;
                window.Android.fetchUrl(url, callbackId);
            });
        } else {
            try {
                let res;
                try {
                    res = await fetch(url);
                } catch (e) {
                    const proxyUrl = 'https://api.allorigins.win/raw?url=' + encodeURIComponent(url);
                    res = await fetch(proxyUrl);
                }
                const text = await res.text();
                return { success: res.ok, status: res.status, data: text, error: res.ok ? null : 'HTTP ' + res.status };
            } catch (err) {
                return { success: false, status: 0, data: null, error: err.message };
            }
        }
    }

    static async resolveYoutubeVideo(videoId) {
        if (this.isAndroid() && window.Android.resolveYoutubeVideo) {
            return new Promise((resolve) => {
                const callbackId = 'yt_' + Date.now() + '_' + Math.floor(Math.random() * 10000);
                window.nativeYoutubeCallbacks[callbackId] = resolve;
                window.Android.resolveYoutubeVideo(videoId, callbackId);
            });
        }
        return { success: false, error: 'Android köprüsü bulunamadı' };
    }

    static getBillingState() {
        if (this.isAndroid() && window.Android.getBillingState) {
            try {
                return JSON.parse(window.Android.getBillingState());
            } catch (e) {
                return { isPro: false };
            }
        }
        try {
            const raw = localStorage.getItem('kevki_billing_state');
            return raw ? JSON.parse(raw) : { isPro: false };
        } catch (e) {
            return { isPro: false };
        }
    }

    static async launchPurchaseFlow(sku, planTitle, priceText) {
        if (this.isAndroid() && window.Android.launchPurchaseFlow) {
            return new Promise((resolve) => {
                const callbackId = 'iap_' + Date.now() + '_' + Math.floor(Math.random() * 10000);
                window.nativePurchaseCallbacks[callbackId] = resolve;
                window.Android.launchPurchaseFlow(sku, planTitle, priceText, callbackId);
            });
        } else {
            const ok = confirm(`${planTitle} (${priceText}) paketini satın almak istiyor musunuz?`);
            if (!ok) return { success: false, cancelled: true };
            const state = {
                success: true,
                isPro: true,
                sku,
                planTitle,
                priceText,
                orderId: 'GPA.3392-' + Math.floor(1000 + Math.random() * 9000),
                purchaseTime: Date.now()
            };
            localStorage.setItem('kevki_billing_state', JSON.stringify(state));
            return state;
        }
    }

    static async restorePurchases() {
        if (this.isAndroid() && window.Android.restorePurchases) {
            return new Promise((resolve) => {
                const callbackId = 'iap_res_' + Date.now();
                window.nativePurchaseCallbacks[callbackId] = resolve;
                window.Android.restorePurchases(callbackId);
            });
        }
        return this.getBillingState();
    }

    static async cancelSubscription() {
        if (this.isAndroid() && window.Android.cancelSubscription) {
            return new Promise((resolve) => {
                const callbackId = 'iap_can_' + Date.now();
                window.nativePurchaseCallbacks[callbackId] = resolve;
                window.Android.cancelSubscription(callbackId);
            });
        }
        localStorage.removeItem('kevki_billing_state');
        return { success: true, isPro: false };
    }

    static async pickImportFile() {
        if (this.isAndroid() && window.Android.pickImportFile) {
            return new Promise((resolve) => {
                const callbackId = 'file_' + Date.now() + '_' + Math.floor(Math.random() * 10000);
                window.nativeFileCallbacks[callbackId] = resolve;
                window.Android.pickImportFile(callbackId);
            });
        }
        return null;
    }

    static syncBackgroundState(feeds, globalNotifyEnabled, seenIds) {
        if (this.isAndroid() && window.Android.syncBackgroundState) {
            try {
                const liteFeeds = (feeds || []).map(f => ({
                    id: f.id,
                    title: f.title,
                    url: f.url,
                    notificationsEnabled: f.notificationsEnabled !== false
                }));
                window.Android.syncBackgroundState(
                    JSON.stringify(liteFeeds),
                    Boolean(globalNotifyEnabled),
                    JSON.stringify(seenIds || [])
                );
            } catch (e) {
                console.warn('syncBackgroundState error:', e);
            }
        }
    }

    static share(title, url) {
        if (this.isAndroid()) {
            window.Android.shareArticle(title, url);
        } else if (navigator.share) {
            navigator.share({ title, url }).catch(() => {});
        } else {
            prompt('Bağlantıyı kopyalayın:', url);
        }
    }

    static openExternal(url) {
        if (this.isAndroid()) {
            window.Android.openExternal(url);
        } else {
            window.open(url, '_blank');
        }
    }

    static toast(msg) {
        if (this.isAndroid()) {
            window.Android.showToast(msg);
        } else {
            console.log('[Toast]', msg);
        }
    }

    static haptic(type = 0) {
        if (this.isAndroid()) {
            window.Android.triggerHaptic(type);
        }
    }

    static setStatusBarColor(hexColor, darkIcons) {
        if (this.isAndroid()) {
            window.Android.setStatusBarColor(hexColor, darkIcons);
        }
    }

    static setNavState(canGoBack) {
        if (this.isAndroid()) {
            window.Android.setNavState(canGoBack);
        }
    }

    static showNotification(title, message, articleId = '', notificationId = 1) {
        if (this.isAndroid() && window.Android.showNotification) {
            window.Android.showNotification(title, message, articleId, notificationId);
        } else if ('Notification' in window && Notification.permission === 'granted') {
            new Notification(title, { body: message });
        }
    }

    static requestNotificationPermission() {
        if (this.isAndroid() && window.Android.requestNotificationPermission) {
            window.Android.requestNotificationPermission();
        } else if ('Notification' in window && Notification.permission !== 'granted') {
            Notification.requestPermission();
        }
    }
}

class KevkiApp {
    constructor() {
        this.storage = new KevkiStorage();
        this.activeTab = 'library'; // 'discover' | 'library' | 'settings'
        this.activeSubPage = null; // null | 'page-add' | 'page-import' | 'page-feeds' | 'page-appearance' | 'page-reader'
        this.subPageStack = [];
        this.savedReaderScrollTop = 0;

        this.currentFilter = 'all'; // 'all' | 'starred' | 'unread'
        this.currentCategory = null;
        this.currentFeedId = null;
        this.searchQuery = '';
        this.sortBy = 'newest'; // 'newest' | 'oldest' | 'shortest' | 'longest' | 'title_az' | 'source_az'

        this.currentArticleId = null;
        this.contextArticle = null;
        this.editingFeed = null;
        this.pendingImportService = 'OPML_CSV';

        this.articles = [];
        this.discoverArticles = [];
        this.feeds = [];
        this.isSyncing = false;

        // In-App Purchase State (Lifetime One-Time Only)
        this.billingState = { isPro: false };
        this.lifetimePlan = {
            sku: 'kevki_pro_lifetime',
            title: 'Ömür Boyu Premium (Tek Seferlik)',
            price: '₺399,99'
        };

        // Appearance & Settings
        this.theme = 'dark';
        this.fontFamily = 'sans';
        this.fontSize = 18;
        this.notificationsEnabled = true;

        // Podcast & Background Audio Engine
        this.audio = new Audio();
        this.currentAudioArticle = null;
        this.isAudioPlaying = false;
        this.audioSpeed = 1.0;

        this.fastPollTimer = null;
    }

    async init() {
        await this.storage.init();

        // Purge legacy default feeds once
        const purgedLegacy = await this.storage.getSetting('purged_legacy_defaults_v2', false);
        if (!purgedLegacy) {
            if (typeof LEGACY_DEFAULT_FEED_IDS !== 'undefined' && Array.isArray(LEGACY_DEFAULT_FEED_IDS)) {
                for (const legacyId of LEGACY_DEFAULT_FEED_IDS) {
                    try {
                        await this.storage.deleteFeed(legacyId);
                    } catch (ignored) {}
                }
            }
            await this.storage.setSetting('purged_legacy_defaults_v2', true);
        }

        let savedTheme = await this.storage.getSetting('theme', 'dark');
        if (savedTheme === 'folio') savedTheme = 'dark';
        this.theme = savedTheme;
        this.fontFamily = await this.storage.getSetting('fontFamily', 'sans');
        this.fontSize = await this.storage.getSetting('fontSize', 18);
        this.sortBy = await this.storage.getSetting('sortBy', 'newest');
        this.notificationsEnabled = await this.storage.getSetting('notificationsEnabled', true);

        this.applyTheme(this.theme);
        this.applyFont(this.fontFamily);
        this.applyFontSize(this.fontSize);
        this.updateSortUI();

        this.billingState = NativeBridge.getBillingState();
        this.updateBillingUI();

        if (this.notificationsEnabled) {
            NativeBridge.requestNotificationPermission();
        }

        const notifyToggle = document.getElementById('setting-notify-toggle');
        if (notifyToggle) {
            notifyToggle.checked = this.notificationsEnabled;
            notifyToggle.onchange = async () => {
                this.notificationsEnabled = notifyToggle.checked;
                await this.storage.setSetting('notificationsEnabled', this.notificationsEnabled);
                await this.syncWithNativeBackgroundService();
                if (this.notificationsEnabled) {
                    NativeBridge.requestNotificationPermission();
                    NativeBridge.toast('Anlık bildirimler etkinleştirildi');
                } else {
                    NativeBridge.toast('Bildirimler kapatıldı');
                }
            };
        }

        this.initAudioEngine();

        await this.loadFeeds();
        await this.refreshAllViews();
        this.bindEvents();
        this.initSwipeGestures();

        this.switchTab('library');
        await this.syncWithNativeBackgroundService();

        // Non-blocking background feed sync
        setTimeout(() => {
            this.syncAllFeeds(true);
            this.startFastRealtimeSyncLoop();
        }, 120);
    }

    onHardwareBack() {
        const ctxBackdrop = document.getElementById('context-menu-backdrop');
        if (ctxBackdrop && ctxBackdrop.style.display !== 'none') {
            ctxBackdrop.style.display = 'none';
            this.updateNavState();
            return true;
        }
        const sortBackdrop = document.getElementById('sort-menu-backdrop');
        if (sortBackdrop && sortBackdrop.style.display !== 'none') {
            sortBackdrop.style.display = 'none';
            this.updateNavState();
            return true;
        }

        if (this.activeSubPage) {
            this.closeSubPage();
            return true;
        }

        if (this.currentFeedId) {
            this.currentFeedId = null;
            this.refreshAllViews();
            this.updateNavState();
            return true;
        }

        if (this.activeTab !== 'library') {
            this.switchTab('library');
            return true;
        }

        return false;
    }

    updateNavState() {
        const hasPopup =
            document.getElementById('context-menu-backdrop').style.display !== 'none' ||
            document.getElementById('sort-menu-backdrop').style.display !== 'none';
        const canGoBack = Boolean(this.activeSubPage) || Boolean(this.currentFeedId) || (this.activeTab !== 'library') || hasPopup;
        NativeBridge.setNavState(canGoBack);
    }

    switchTab(tabName) {
        this.activeTab = tabName;
        this.subPageStack = [];
        this.closeSubPage(false);

        document.querySelectorAll('.app-page').forEach(p => p.classList.remove('active'));
        const targetPage = document.getElementById('page-' + tabName);
        if (targetPage) targetPage.classList.add('active');

        document.querySelectorAll('.bottom-nav-item').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.tab === tabName);
        });

        this.updateNavState();
    }

    openSubPage(pageId) {
        if (this.activeSubPage && this.activeSubPage !== pageId) {
            if (this.activeSubPage === 'page-reader' && pageId === 'page-appearance') {
                const readerScroll = document.getElementById('reader-scroll');
                if (readerScroll) {
                    this.savedReaderScrollTop = readerScroll.scrollTop;
                }
                this.subPageStack.push('page-reader');
                const appPage = document.getElementById('page-appearance');
                if (appPage) {
                    appPage.classList.add('open');
                }
                this.activeSubPage = 'page-appearance';
                this.updateNavState();
                return;
            }
        }

        this.subPageStack = [];
        document.querySelectorAll('.app-subpage').forEach(sp => sp.classList.remove('open'));
        const page = document.getElementById(pageId);
        if (page) {
            page.classList.add('open');
            this.activeSubPage = pageId;
        }
        this.updateNavState();
    }

    closeSubPage(updateState = true) {
        // If we opened Appearance from Reader, return directly to the open Reader article at the same scroll offset!
        if (this.subPageStack.length > 0) {
            const currentEl = this.activeSubPage ? document.getElementById(this.activeSubPage) : null;
            if (currentEl) currentEl.classList.remove('open');

            const prevPageId = this.subPageStack.pop();
            const prevEl = document.getElementById(prevPageId);
            if (prevEl) {
                prevEl.classList.add('open');
                this.activeSubPage = prevPageId;
                if (prevPageId === 'page-reader') {
                    const readerScroll = document.getElementById('reader-scroll');
                    if (readerScroll) {
                        readerScroll.scrollTop = this.savedReaderScrollTop || 0;
                    }
                }
            } else {
                this.activeSubPage = null;
            }
            if (updateState) this.updateNavState();
            return;
        }

        if (this.activeSubPage === 'page-reader') {
            this.stopReaderVideoPlayer();
        }
        document.querySelectorAll('.app-subpage').forEach(sp => sp.classList.remove('open'));
        this.activeSubPage = null;
        if (updateState) this.updateNavState();
    }

    stopReaderVideoPlayer() {
        const videoPlayer = document.getElementById('reader-video-player');
        if (videoPlayer) {
            try {
                videoPlayer.pause();
                videoPlayer.removeAttribute('src');
                videoPlayer.load();
            } catch (ignored) {}
        }
        const videoIframe = document.getElementById('reader-video-iframe');
        if (videoIframe) {
            try {
                videoIframe.src = 'about:blank';
                videoIframe.style.display = 'none';
            } catch (ignored) {}
        }
    }

    async syncWithNativeBackgroundService() {
        try {
            const allIds = await this.storage.getAllArticleIds();
            NativeBridge.syncBackgroundState(this.feeds, this.notificationsEnabled, allIds);
        } catch (e) {
            console.warn('Failed to sync background state:', e);
        }
    }

    startFastRealtimeSyncLoop() {
        if (this.fastPollTimer) clearInterval(this.fastPollTimer);
        const intervalMs = (this.billingState && this.billingState.isPro) ? 10000 : 18000;
        this.fastPollTimer = setInterval(() => {
            if (!this.isSyncing && this.feeds.length > 0) {
                this.syncAllFeeds(true);
            }
        }, intervalMs);
    }

    async onBackgroundPollUpdate() {
        if (!this.isSyncing) {
            await this.syncAllFeeds(true);
        }
    }

    applyTheme(theme) {
        this.theme = theme;
        document.documentElement.setAttribute('data-theme', theme);
        this.storage.setSetting('theme', theme);

        if (theme === 'light') {
            NativeBridge.setStatusBarColor('#faf7f0', true);
        } else if (theme === 'sepia') {
            NativeBridge.setStatusBarColor('#f4ecdc', true);
        } else if (theme === 'midnight') {
            NativeBridge.setStatusBarColor('#000000', false);
        } else {
            NativeBridge.setStatusBarColor('#161513', false);
        }

        document.querySelectorAll('.appearance-option-btn[data-theme]').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.theme === theme);
        });
    }

    applyFont(font) {
        this.fontFamily = font;
        let fontVal = 'var(--font-sans)';
        if (font === 'serif') fontVal = 'var(--font-serif)';
        if (font === 'mono') fontVal = 'var(--font-mono)';
        document.documentElement.style.setProperty('--current-font', fontVal);
        this.storage.setSetting('fontFamily', font);

        document.querySelectorAll('.font-opt-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.font === font);
        });
    }

    applyFontSize(size) {
        this.fontSize = Math.min(Math.max(size, 13), 26);
        document.documentElement.style.setProperty('--reader-font-size', this.fontSize + 'px');
        this.storage.setSetting('fontSize', this.fontSize);
        const el = document.getElementById('font-size-display');
        if (el) el.textContent = this.fontSize + 'px';
    }

    // ========================================================
    // IN-APP PURCHASE (LIFETIME ONE-TIME ONLY) MANAGEMENT
    // ========================================================
    updateBillingUI() {
        const isPro = Boolean(this.billingState && this.billingState.isPro);
        const topBadge = document.getElementById('pro-top-badge');
        if (topBadge) topBadge.classList.toggle('visible', isPro);

        const iapToggle = document.getElementById('setting-iap-toggle');
        if (iapToggle) {
            iapToggle.checked = isPro;
        }

        const iapTitle = document.getElementById('iap-row-title');
        const iapDesc = document.getElementById('iap-row-desc');
        if (iapTitle && iapDesc) {
            if (isPro) {
                iapTitle.textContent = 'Ömür Boyu Premium (Tek Seferlik) • Aktif';
                iapDesc.textContent = `Tek seferlik ömür boyu tam sürüm lisansınız etkin (${this.billingState.orderId || 'GPA.3392'})`;
            } else {
                iapTitle.textContent = 'Ömür Boyu Premium (Tek Seferlik)';
                iapDesc.textContent = 'Tek seferlik ₺399,99 ödeme ile ömür boyu tüm özelliklere sınırsız erişin';
            }
        }
    }

    // ========================================================
    // PODCAST & BACKGROUND YOUTUBE AUDIO ENGINE
    // ========================================================
    initAudioEngine() {
        const audio = this.audio;

        audio.addEventListener('timeupdate', () => {
            if (!isNaN(audio.duration) && audio.duration > 0) {
                const cur = audio.currentTime;
                const dur = audio.duration;
                const pct = (cur / dur) * 100;

                const seekBar = document.getElementById('podcast-seek-bar');
                const curTimeEl = document.getElementById('podcast-time-cur');
                if (seekBar && !seekBar.dataset.seeking) {
                    seekBar.value = pct;
                }
                if (curTimeEl) {
                    curTimeEl.textContent = this.formatTimeSeconds(cur);
                }

                const miniFill = document.getElementById('mini-player-progress-fill');
                const miniSub = document.getElementById('mini-player-subtitle');
                if (miniFill) miniFill.style.width = pct + '%';
                if (miniSub) miniSub.textContent = `${this.formatTimeSeconds(cur)} / ${this.formatTimeSeconds(dur)}`;
            }
        });

        audio.addEventListener('loadedmetadata', () => {
            const dur = audio.duration;
            const totalEl = document.getElementById('podcast-time-total');
            if (totalEl && !isNaN(dur)) {
                totalEl.textContent = this.formatTimeSeconds(dur);
            }
        });

        audio.addEventListener('play', () => {
            this.isAudioPlaying = true;
            this.updateAudioButtonsUI(true);
            this.showMiniPlayer();
        });

        audio.addEventListener('pause', () => {
            this.isAudioPlaying = false;
            this.updateAudioButtonsUI(false);
        });

        audio.addEventListener('ended', () => {
            this.isAudioPlaying = false;
            this.updateAudioButtonsUI(false);
            const seekBar = document.getElementById('podcast-seek-bar');
            if (seekBar) seekBar.value = 0;
            const miniFill = document.getElementById('mini-player-progress-fill');
            if (miniFill) miniFill.style.width = '0%';
        });

        const seekBar = document.getElementById('podcast-seek-bar');
        if (seekBar) {
            seekBar.addEventListener('input', () => {
                seekBar.dataset.seeking = 'true';
            });
            seekBar.addEventListener('change', () => {
                delete seekBar.dataset.seeking;
                if (!isNaN(audio.duration) && audio.duration > 0) {
                    audio.currentTime = (seekBar.value / 100) * audio.duration;
                }
            });
        }

        const btnPlay = document.getElementById('btn-podcast-play');
        if (btnPlay) btnPlay.onclick = () => this.togglePodcastPlay();
        const btnRw = document.getElementById('btn-podcast-rw');
        if (btnRw) btnRw.onclick = () => this.stepPodcast(-15);
        const btnFf = document.getElementById('btn-podcast-ff');
        if (btnFf) btnFf.onclick = () => this.stepPodcast(30);
        const btnSpeed = document.getElementById('btn-podcast-speed');
        if (btnSpeed) btnSpeed.onclick = () => this.cyclePodcastSpeed();

        const btnMiniPlay = document.getElementById('btn-mini-play');
        if (btnMiniPlay) btnMiniPlay.onclick = () => this.togglePodcastPlay();
        const btnMiniClose = document.getElementById('btn-mini-close');
        if (btnMiniClose) btnMiniClose.onclick = () => this.stopPodcast();
        const miniMeta = document.getElementById('mini-player-meta');
        if (miniMeta) {
            miniMeta.onclick = () => {
                if (this.currentAudioArticle) {
                    this.openArticle(this.currentAudioArticle);
                }
            };
        }
    }

    playPodcast(article) {
        if (!article || !article.audioUrl) return;

        if (this.currentAudioArticle && this.currentAudioArticle.id === article.id) {
            if (!this.isAudioPlaying) {
                this.audio.play().catch(e => console.warn('Audio play error:', e));
            }
            return;
        }

        this.currentAudioArticle = article;
        this.audio.src = article.audioUrl;
        this.audio.playbackRate = this.audioSpeed;
        this.audio.play().catch(e => {
            console.warn('Audio play error:', e);
            NativeBridge.toast('Ses oynatılamadı');
        });

        const miniTitle = document.getElementById('mini-player-title');
        const miniThumb = document.getElementById('mini-player-thumb');
        if (miniTitle) miniTitle.textContent = article.title;
        if (miniThumb) {
            if (article.thumbnail) {
                miniThumb.innerHTML = `<img src="${article.thumbnail}" onerror="this.parentElement.innerHTML='🎙️'">`;
            } else {
                miniThumb.innerHTML = `🎙️`;
            }
        }
        this.showMiniPlayer();
    }

    togglePodcastPlay() {
        if (!this.currentAudioArticle) {
            const readerArticle = this.articles.find(a => a.id === this.currentArticleId) ||
                                  this.discoverArticles.find(a => a.id === this.currentArticleId);
            if (readerArticle && readerArticle.audioUrl) {
                this.playPodcast(readerArticle);
                return;
            }
            return;
        }

        if (this.isAudioPlaying) {
            this.audio.pause();
        } else {
            this.audio.play().catch(e => console.warn('Audio play error:', e));
        }
    }

    stepPodcast(seconds) {
        if (this.audio) {
            this.audio.currentTime = Math.max(0, Math.min(this.audio.currentTime + seconds, this.audio.duration || 999999));
        }
    }

    cyclePodcastSpeed() {
        const speeds = [1.0, 1.25, 1.5, 2.0];
        let idx = speeds.indexOf(this.audioSpeed);
        idx = (idx + 1) % speeds.length;
        this.audioSpeed = speeds[idx];
        if (this.audio) this.audio.playbackRate = this.audioSpeed;
        const btn = document.getElementById('btn-podcast-speed');
        if (btn) btn.textContent = this.audioSpeed.toFixed(1) + 'x';
    }

    updateAudioButtonsUI(isPlaying) {
        const playIcon = document.getElementById('icon-podcast-play');
        const pauseIcon = document.getElementById('icon-podcast-pause');
        if (playIcon && pauseIcon) {
            playIcon.style.display = isPlaying ? 'none' : 'block';
            pauseIcon.style.display = isPlaying ? 'block' : 'none';
        }

        const miniPlayIcon = document.getElementById('icon-mini-play');
        const miniPauseIcon = document.getElementById('icon-mini-pause');
        if (miniPlayIcon && miniPauseIcon) {
            miniPlayIcon.style.display = isPlaying ? 'none' : 'block';
            miniPauseIcon.style.display = isPlaying ? 'block' : 'none';
        }
    }

    showMiniPlayer() {
        const mini = document.getElementById('global-mini-player');
        if (mini) mini.style.display = 'block';
    }

    stopPodcast() {
        if (this.audio) {
            this.audio.pause();
            this.audio.currentTime = 0;
        }
        this.isAudioPlaying = false;
        this.currentAudioArticle = null;
        this.updateAudioButtonsUI(false);
        const mini = document.getElementById('global-mini-player');
        if (mini) mini.style.display = 'none';
    }

    formatTimeSeconds(totalSeconds) {
        if (isNaN(totalSeconds) || totalSeconds < 0) return '00:00';
        const h = Math.floor(totalSeconds / 3600);
        const m = Math.floor((totalSeconds % 3600) / 60);
        const s = Math.floor(totalSeconds % 60);
        const sStr = s < 10 ? '0' + s : s;
        if (h > 0) {
            const mStr = m < 10 ? '0' + m : m;
            return `${h}:${mStr}:${sStr}`;
        }
        return `${m}:${sStr}`;
    }

    async openArticleFromNotification(articleId) {
        if (!articleId) return;
        let article = await this.storage.getArticleById(articleId);
        if (!article) {
            await this.syncAllFeeds(true);
            article = await this.storage.getArticleById(articleId);
        }
        if (article) {
            await this.openArticle(article);
        }
    }

    async openArticleById(articleId) {
        await this.openArticleFromNotification(articleId);
    }

    // Handle incoming Share Sheet URL or WhatsApp Channel message from Android
    async handleSharedContent(sharedText, sharedSubject = '') {
        if (!sharedText) return;
        const trimmed = sharedText.trim();
        const urlMatch = trimmed.match(/https?:\/\/[^\s"'<>]+/i);

        // If the user shared a long WhatsApp Channel message text with or without a link, save directly if it has multi-sentence text!
        const nonUrlPart = trimmed.replace(/https?:\/\/[^\s"'<>]+/gi, '').trim();
        if (nonUrlPart.length > 60 && (trimmed.includes('whatsapp.com/channel') || sharedSubject.toLowerCase().includes('whatsapp'))) {
            const waItems = FeedParser.parseWhatsAppTextExport(trimmed, sharedSubject || 'WhatsApp Kanalı');
            if (waItems.length > 0) {
                for (const art of waItems) {
                    await this.storage.saveSingleArticle(art);
                }
                NativeBridge.haptic(1);
                NativeBridge.toast('WhatsApp Kanalı yazısı kütüphaneye kaydedildi');
                await this.refreshAllViews();
                return;
            }
        }

        const extractedUrl = urlMatch ? urlMatch[0] : trimmed;
        this.openAddPage(extractedUrl);
    }

    async loadFeeds() {
        this.feeds = await this.storage.getAllFeeds();
        this.renderManageFeedsPage();
    }

    async refreshAllViews() {
        this.articles = await this.storage.getArticles({
            filter: this.currentFilter,
            feedId: this.currentFeedId,
            category: this.currentCategory,
            searchQuery: this.searchQuery,
            sortBy: this.sortBy
        });

        this.discoverArticles = await this.storage.getArticles({
            filter: 'all',
            feedId: this.currentFeedId,
            category: null,
            searchQuery: this.searchQuery,
            sortBy: 'newest'
        });

        this.updateActiveSourceBanner();
        this.renderLibraryList();
        this.renderDiscoverStream();
    }

    updateActiveSourceBanner() {
        const banner = document.getElementById('active-source-banner');
        const label = document.getElementById('active-source-label');
        if (!banner || !label) return;

        if (this.currentFeedId) {
            const feed = this.feeds.find(f => f.id === this.currentFeedId);
            if (feed) {
                label.textContent = `Kaynak: ${feed.title} (${this.articles.length} yayın)`;
                banner.classList.add('visible');
                return;
            }
        }
        banner.classList.remove('visible');
    }

    // ========================================================
    // TAB 1: DISCOVER / STREAM RENDERING (Fast DocumentFragment)
    // ========================================================
    renderDiscoverStream() {
        const container = document.getElementById('discover-stream-container');
        if (!container) return;
        container.innerHTML = '';

        if (this.discoverArticles.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <div class="empty-state-title">Henüz Yayın Yok</div>
                    <div class="empty-state-desc">Sağ üstteki + düğmesine dokunarak RSS, YouTube kanalı, Reddit, WhatsApp Kanalı veya makale ekleyebilirsiniz.</div>
                    <button class="empty-state-btn" id="btn-empty-discover-add">Yayın Ekle</button>
                </div>
            `;
            const btn = document.getElementById('btn-empty-discover-add');
            if (btn) btn.onclick = () => this.openAddPage();
            return;
        }

        const frag = document.createDocumentFragment();
        const renderList = this.discoverArticles.slice(0, 80);

        for (let i = 0; i < renderList.length; i++) {
            const article = renderList[i];
            const wrapperEl = document.createElement('div');
            wrapperEl.className = 'row-swipe-wrapper stream-item-wrapper';

            const itemEl = document.createElement('div');
            itemEl.className = 'stream-item' + (article.unread ? '' : ' read');

            const sourceName = article.feedTitle || article.domain || 'Kaynak';
            const initial = sourceName.charAt(0).toUpperCase();
            const durationText = article.isPodcast && article.audioDuration
                ? article.audioDuration
                : `${article.readingTimeMin || 1} dk`;
            const categoryText = article.categoryName || 'Genel';

            const coverHtml = article.thumbnail ? `
                <div class="stream-cover-wrap">
                    <img class="stream-cover-img" src="${article.thumbnail}" loading="lazy" decoding="async" onerror="this.parentElement.remove()">
                </div>
            ` : '';

            const badgeImgHtml = article.feedIcon
                ? `<img src="${article.feedIcon}" loading="lazy" decoding="async" onerror="this.parentElement.textContent='${escapeHtml(initial)}'">`
                : escapeHtml(initial);

            wrapperEl.innerHTML = `
                <div class="swipe-action-bg">
                    <span class="swipe-hint-left">Okundu / Okunmadı</span>
                    <span class="swipe-hint-right">Favoriler</span>
                </div>
            `;

            itemEl.innerHTML = `
                ${coverHtml}
                <div class="stream-source-row">
                    <span class="source-badge-box">${badgeImgHtml}</span>
                    <span>${escapeHtml(sourceName)} • ${escapeHtml(durationText)}</span>
                </div>
                <div class="stream-title">${escapeHtml(article.title)}</div>
                ${article.summary ? `<div class="stream-excerpt">${escapeHtml(article.summary)}</div>` : ''}
                <div class="item-bottom-bar">
                    <span class="item-category-label">${escapeHtml(categoryText)}</span>
                    <div class="item-actions-right">
                        <button class="row-action-btn btn-row-star ${article.starred ? 'starred' : ''}" title="Favoriler">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"></path>
                            </svg>
                        </button>
                        <button class="row-action-btn btn-row-more" title="Seçenekler">
                            <svg viewBox="0 0 24 24" fill="currentColor">
                                <circle cx="5" cy="12" r="1.8"></circle>
                                <circle cx="12" cy="12" r="1.8"></circle>
                                <circle cx="19" cy="12" r="1.8"></circle>
                            </svg>
                        </button>
                    </div>
                </div>
            `;

            this.attachRowInteractions(wrapperEl, itemEl, article);
            wrapperEl.appendChild(itemEl);
            frag.appendChild(wrapperEl);
        }

        container.appendChild(frag);
    }

    // ========================================================
    // TAB 2: LIBRARY LIST RENDERING (Fast DocumentFragment)
    // ========================================================
    renderLibraryList() {
        const container = document.getElementById('library-list-container');
        if (!container) return;
        container.innerHTML = '';

        if (this.articles.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <div class="empty-state-title">Kayıtlı İçerik Bulunamadı</div>
                    <div class="empty-state-desc">${this.currentFeedId ? 'Bu kaynakta henüz yayın bulunmuyor.' : 'Sağ üstteki + düğmesine dokunarak yeni bir kaynak veya makale URL\'si ekleyebilirsiniz.'}</div>
                    <button class="empty-state-btn" id="btn-empty-lib-add">${this.currentFeedId ? 'Tüm Kaynakları Göster' : 'URL Ekle'}</button>
                </div>
            `;
            const btn = document.getElementById('btn-empty-lib-add');
            if (btn) {
                btn.onclick = () => {
                    if (this.currentFeedId) {
                        this.currentFeedId = null;
                        this.refreshAllViews();
                    } else {
                        this.openAddPage();
                    }
                };
            }
            return;
        }

        const frag = document.createDocumentFragment();
        const renderList = this.articles.slice(0, 120);

        for (let i = 0; i < renderList.length; i++) {
            const article = renderList[i];
            const wrapperEl = document.createElement('div');
            wrapperEl.className = 'row-swipe-wrapper';

            const rowEl = document.createElement('div');
            rowEl.className = 'library-row' + (article.unread ? '' : ' read');
            rowEl.dataset.articleId = article.id;

            const sourceName = article.feedTitle || article.domain || 'Kaynak';
            const durationText = article.isPodcast && article.audioDuration
                ? article.audioDuration
                : `${article.readingTimeMin || 1} dk`;
            const categoryText = article.categoryName || 'Genel';

            const thumbHtml = article.thumbnail ? `
                <div class="library-row-thumb">
                    <img src="${article.thumbnail}" loading="lazy" decoding="async" onerror="this.parentElement.remove()">
                </div>
            ` : '';

            wrapperEl.innerHTML = `
                <div class="swipe-action-bg">
                    <span class="swipe-hint-left">Okundu / Okunmadı</span>
                    <span class="swipe-hint-right">Favoriler</span>
                </div>
            `;

            rowEl.innerHTML = `
                <div class="library-row-main">
                    <div class="library-row-text">
                        <div class="library-row-title">${escapeHtml(article.title)}</div>
                        <div class="library-row-meta">${escapeHtml(sourceName)} • ${escapeHtml(durationText)}</div>
                    </div>
                    ${thumbHtml}
                </div>
                <div class="item-bottom-bar">
                    <span class="item-category-label">${escapeHtml(categoryText)}</span>
                    <div class="item-actions-right">
                        <button class="row-action-btn btn-row-star ${article.starred ? 'starred' : ''}" title="Favoriler">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"></path>
                            </svg>
                        </button>
                        <button class="row-action-btn btn-row-more" title="Seçenekler">
                            <svg viewBox="0 0 24 24" fill="currentColor">
                                <circle cx="5" cy="12" r="1.8"></circle>
                                <circle cx="12" cy="12" r="1.8"></circle>
                                <circle cx="19" cy="12" r="1.8"></circle>
                            </svg>
                        </button>
                    </div>
                </div>
            `;

            this.attachRowInteractions(wrapperEl, rowEl, article);
            wrapperEl.appendChild(rowEl);
            frag.appendChild(wrapperEl);
        }

        container.appendChild(frag);
    }

    attachRowInteractions(wrapperEl, itemEl, article) {
        const starBtn = itemEl.querySelector('.btn-row-star, .btn-row-plus');
        if (starBtn) {
            starBtn.addEventListener('click', async (e) => {
                e.stopPropagation();
                NativeBridge.haptic(0);
                const isStarred = await this.storage.toggleStar(article.id);
                article.starred = isStarred;
                starBtn.classList.toggle('starred', isStarred);
                NativeBridge.toast(isStarred ? 'Favorilere eklendi' : 'Favorilerden çıkarıldı');
                if (this.currentFilter === 'starred' && !isStarred) {
                    this.refreshAllViews();
                }
            });
        }

        const moreBtn = itemEl.querySelector('.btn-row-more');
        if (moreBtn) {
            moreBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                this.openContextMenu(article);
            });
        }

        let startX = 0;
        let startY = 0;
        let currentX = 0;
        let isDragging = false;
        let isScrollingVert = false;
        let hapticDone = false;

        itemEl.addEventListener('touchstart', (e) => {
            if (e.touches.length !== 1) return;
            startX = e.touches[0].clientX;
            startY = e.touches[0].clientY;
            currentX = 0;
            isDragging = false;
            isScrollingVert = false;
            hapticDone = false;
            itemEl.style.transition = 'none';
        }, { passive: true });

        itemEl.addEventListener('touchmove', (e) => {
            if (isScrollingVert || e.touches.length !== 1) return;
            const dx = e.touches[0].clientX - startX;
            const dy = e.touches[0].clientY - startY;

            if (!isDragging) {
                if (Math.abs(dy) > Math.abs(dx) && Math.abs(dy) > 10) {
                    isScrollingVert = true;
                    return;
                }
                if (Math.abs(dx) > 14 && Math.abs(dx) > Math.abs(dy) * 1.3) {
                    isDragging = true;
                }
            }

            if (isDragging) {
                currentX = Math.max(-120, Math.min(120, dx));
                itemEl.style.transform = `translateX(${currentX}px)`;

                if (currentX > 20) {
                    wrapperEl.classList.add('swiping-right');
                    wrapperEl.classList.remove('swiping-left');
                } else if (currentX < -20) {
                    wrapperEl.classList.add('swiping-left');
                    wrapperEl.classList.remove('swiping-right');
                } else {
                    wrapperEl.classList.remove('swiping-left', 'swiping-right');
                }

                if (Math.abs(currentX) >= 70 && !hapticDone) {
                    hapticDone = true;
                    NativeBridge.haptic(0);
                } else if (Math.abs(currentX) < 62 && hapticDone) {
                    hapticDone = false;
                }
            }
        }, { passive: true });

        const finishSwipe = async () => {
            itemEl.style.transition = 'transform 0.18s ease';
            itemEl.style.transform = 'translateX(0px)';
            wrapperEl.classList.remove('swiping-left', 'swiping-right');

            if (isDragging) {
                if (currentX >= 70) {
                    article.unread = !article.unread;
                    await this.storage.markArticleRead(article.id, !article.unread);
                    itemEl.classList.toggle('read', !article.unread);
                    NativeBridge.toast(article.unread ? 'Okunmadı işaretlendi' : 'Okundu işaretlendi');
                    if (this.currentFilter === 'unread' && !article.unread) {
                        this.refreshAllViews();
                    }
                } else if (currentX <= -70) {
                    const isStarred = await this.storage.toggleStar(article.id);
                    article.starred = isStarred;
                    NativeBridge.toast(isStarred ? 'Favorilere eklendi' : 'Favorilerden çıkarıldı');
                    this.refreshAllViews();
                }
            }
            currentX = 0;
        };

        itemEl.addEventListener('touchend', finishSwipe, { passive: true });
        itemEl.addEventListener('touchcancel', finishSwipe, { passive: true });

        itemEl.addEventListener('click', (e) => {
            if (isDragging) {
                e.preventDefault();
                e.stopPropagation();
                return;
            }
            this.openArticle(article);
        });
    }

    openContextMenu(article) {
        this.contextArticle = article;
        const backdrop = document.getElementById('context-menu-backdrop');
        const saveLabel = document.getElementById('ctx-save-label');
        const readLabel = document.getElementById('ctx-read-label');
        const editFeedItem = document.getElementById('ctx-edit-feed');

        if (saveLabel) saveLabel.textContent = article.starred ? 'Favorilerden Çıkar' : 'Kaydet';
        if (readLabel) readLabel.textContent = article.unread ? 'Okundu İşaretle' : 'Okunmadı İşaretle';

        const feed = this.feeds.find(f => f.id === article.feedId);
        if (editFeedItem) {
            editFeedItem.style.display = feed ? 'flex' : 'none';
        }

        if (backdrop) {
            backdrop.style.display = 'flex';
            this.updateNavState();
        }
    }

    updateSortUI() {
        document.querySelectorAll('.sort-opt').forEach(opt => {
            opt.classList.toggle('active', opt.dataset.sort === this.sortBy);
        });
    }

    // ========================================================
    // SUB-PAGE: KAYNAKLARI YÖNET (Click Row -> Filter by Source; Click "Düzenle" -> Edit Source)
    // ========================================================
    renderManageFeedsPage() {
        const listEl = document.getElementById('manage-feeds-list');
        if (!listEl) return;
        listEl.innerHTML = '';

        if (this.feeds.length === 0) {
            listEl.innerHTML = `
                <div class="empty-state">
                    <div class="empty-state-title">Kayıtlı Kaynak Yok</div>
                    <div class="empty-state-desc">Henüz takip ettiğiniz bir RSS, YouTube, Reddit veya WhatsApp Kanalı kaynağı bulunmuyor.</div>
                    <button class="empty-state-btn" id="btn-empty-feeds-add">Kaynak Ekle</button>
                </div>
            `;
            const btn = document.getElementById('btn-empty-feeds-add');
            if (btn) btn.onclick = () => this.openAddPage();
            return;
        }

        const frag = document.createDocumentFragment();
        this.feeds.forEach(feed => {
            const row = document.createElement('div');
            row.className = 'manage-feed-row';
            const initial = (feed.title || 'K').charAt(0).toUpperCase();
            const crispIcon = feed.icon ? feed.icon.replace(/favicons\?domain=([^&]+)$/, 'favicons?domain=$1&sz=128') : '';
            const badgeHtml = crispIcon
                ? `<img src="${crispIcon}" loading="lazy" onerror="this.parentElement.textContent='${escapeHtml(initial)}'">`
                : escapeHtml(initial);

            row.innerHTML = `
                <div class="manage-feed-left">
                    <span class="manage-feed-badge">${badgeHtml}</span>
                    <div class="manage-feed-info">
                        <div class="manage-feed-title">${escapeHtml(feed.title)}</div>
                        <div class="manage-feed-url">${escapeHtml(feed.url)}</div>
                    </div>
                </div>
                <div class="manage-feed-right">
                    <span class="manage-feed-cat">${escapeHtml(feed.category || 'Genel')}</span>
                    <button class="manage-feed-edit-btn">Düzenle</button>
                </div>
            `;

            // Clicking the edit button opens the inline editor
            const editBtn = row.querySelector('.manage-feed-edit-btn');
            if (editBtn) {
                editBtn.onclick = (e) => {
                    e.stopPropagation();
                    this.openFeedInlineEditor(feed);
                };
            }

            // Clicking the feed row itself filters the Library to show ONLY publications from this source!
            row.onclick = async () => {
                NativeBridge.haptic(0);
                this.currentFeedId = feed.id;
                this.currentCategory = null;
                this.currentFilter = 'all';
                document.querySelectorAll('.filter-pill').forEach(p => {
                    p.classList.toggle('active', p.dataset.filter === 'all');
                });
                this.closeSubPage();
                this.switchTab('library');
                await this.refreshAllViews();
                NativeBridge.toast(`"${feed.title}" yayınları gösteriliyor`);
            };

            frag.appendChild(row);
        });

        listEl.appendChild(frag);
    }

    openFeedInlineEditor(feed) {
        this.editingFeed = feed;
        const panel = document.getElementById('feed-editor-panel');
        document.getElementById('input-edit-title').value = feed.title || '';
        document.getElementById('input-edit-url').value = feed.url || '';
        document.getElementById('input-edit-cat').value = feed.category || 'Genel';
        const notifyEl = document.getElementById('input-edit-notify');
        if (notifyEl) notifyEl.checked = (feed.notificationsEnabled !== false);
        if (panel) panel.style.display = 'block';
    }

    async handleEditFeedSubmit() {
        if (!this.editingFeed) return;
        const newTitle = document.getElementById('input-edit-title').value.trim() || this.editingFeed.title;
        let newUrl = document.getElementById('input-edit-url').value.trim() || this.editingFeed.url;
        const newCategory = document.getElementById('input-edit-cat').value.trim() || 'Genel';
        const notifyEl = document.getElementById('input-edit-notify');
        const newNotify = notifyEl ? notifyEl.checked : true;

        const urlChanged = (newUrl !== this.editingFeed.url);

        if (urlChanged) {
            NativeBridge.toast('Yeni URL çözümleniyor...');
            const resolved = await this.resolveFeedUrl(newUrl);
            if (resolved && resolved.feedUrl) {
                newUrl = resolved.feedUrl;
            }
        }

        this.editingFeed.title = newTitle;
        this.editingFeed.url = newUrl;
        this.editingFeed.category = newCategory;
        this.editingFeed.notificationsEnabled = newNotify;

        await this.storage.saveFeed(this.editingFeed);
        document.getElementById('feed-editor-panel').style.display = 'none';
        NativeBridge.toast('Kaynak güncellendi');

        if (urlChanged) {
            try {
                const res = await NativeBridge.fetchUrl(newUrl);
                if (res.success && res.data) {
                    const parsed = FeedParser.parse(res.data, newUrl);
                    if (parsed.items && parsed.items.length > 0) {
                        await this.storage.saveArticles(parsed.items, this.editingFeed.id);
                    }
                }
            } catch (err) {
                console.error('Fetch error after feed URL edit:', err);
            }
        }

        await this.loadFeeds();
        await this.refreshAllViews();
        await this.syncWithNativeBackgroundService();
    }

    async handleDeleteFeed() {
        if (!this.editingFeed) return;
        if (confirm(`"${this.editingFeed.title}" kaynağını silmek istediğinize emin misiniz?`)) {
            if (this.currentFeedId === this.editingFeed.id) {
                this.currentFeedId = null;
            }
            await this.storage.deleteFeed(this.editingFeed.id);
            document.getElementById('feed-editor-panel').style.display = 'none';
            this.editingFeed = null;
            NativeBridge.toast('Kaynak silindi');
            await this.loadFeeds();
            await this.refreshAllViews();
            await this.syncWithNativeBackgroundService();
        }
    }

    // ========================================================
    // SUB-PAGE: KEVKI'YE EKLE (Smart Resolver: RSS, YouTube, Reddit, WhatsApp Channel, Web Article)
    // ========================================================
    openAddPage(prefillUrl = '') {
        const urlInput = document.getElementById('input-add-url');
        const catInput = document.getElementById('input-add-category');
        const notifyInput = document.getElementById('input-add-notify');

        if (urlInput) urlInput.value = prefillUrl;
        if (catInput) catInput.value = '';
        if (notifyInput) notifyInput.checked = true;

        this.openSubPage('page-add');
        setTimeout(() => {
            if (urlInput) urlInput.focus();
        }, 80);
    }

    async handleAddSubmit() {
        const rawInput = document.getElementById('input-add-url').value.trim();
        let category = document.getElementById('input-add-category').value.trim() || 'Genel';
        const notifyEnabled = document.getElementById('input-add-notify') ? document.getElementById('input-add-notify').checked : true;

        if (!rawInput) {
            NativeBridge.toast('Lütfen bir URL veya kaynak girin');
            return;
        }

        NativeBridge.toast('Bağlantı işleniyor...');

        // 1. Resolve YouTube (@handle, channel), Reddit (r/sub), WhatsApp Channel, or RSS/Atom feed
        const resolved = await this.resolveFeedUrl(rawInput);
        let url = resolved ? resolved.feedUrl : rawInput;

        if (!url.startsWith('http://') && !url.startsWith('https://')) {
            url = 'https://' + url;
        }

        const res = await NativeBridge.fetchUrl(url);
        if (!res.success || !res.data) {
            // Special fallback for WhatsApp Channels if offline or rate-limited: still allow adding the channel!
            if (resolved && resolved.isWhatsApp) {
                const idPart = (url.split('/channel/')[1] || '').split(/[/?#]/)[0];
                const waFeed = {
                    id: 'feed_' + Math.abs(this.hashCode(url)).toString(36),
                    title: `WhatsApp Kanalı (${idPart.substring(0, 8) || 'Resmi'})`,
                    url: url,
                    siteUrl: url,
                    category: category === 'Genel' ? 'WhatsApp' : category,
                    icon: 'https://www.google.com/s2/favicons?domain=whatsapp.com&sz=64',
                    notificationsEnabled: notifyEnabled
                };
                await this.storage.saveFeed(waFeed);
                this.closeSubPage();
                NativeBridge.haptic(1);
                NativeBridge.toast(`"${waFeed.title}" eklendi`);
                await this.loadFeeds();
                await this.refreshAllViews();
                return;
            }
            NativeBridge.toast('Bağlantı indirilemedi: ' + (res.error || 'Ağ hatası'));
            return;
        }

        // Try parsing as RSS/Atom/WhatsApp Channel feed first
        let parsed = null;
        let feedUrl = url;
        const looksLikeFeed =
            (resolved && resolved.isWhatsApp) ||
            res.data.includes('<rss') ||
            res.data.includes('<feed') ||
            res.data.includes('<channel') ||
            res.data.includes('<RDF');

        if (looksLikeFeed) {
            try {
                parsed = FeedParser.parse(res.data, url);
            } catch (e) {
                parsed = null;
            }
        }

        // Auto-discover RSS link on website roots
        let pathLength = 0;
        try {
            const u = new URL(url);
            pathLength = u.pathname.replace(/^\/+|\/+$/g, '').length;
        } catch (ignored) {}

        if ((!parsed || !parsed.items || parsed.items.length === 0) && (pathLength === 0 || (resolved && resolved.isYouTube))) {
            const match = res.data.match(/<link[^>]+type=["']application\/(rss|atom)\+xml["'][^>]+href=["']([^"']+)["']/i) ||
                          res.data.match(/<link[^>]+href=["']([^"']+)["'][^>]+type=["']application\/(rss|atom)\+xml["']/i);
            const rawDiscovered = match ? (match[2] && match[2].includes('/') ? match[2] : match[1]) : null;
            if (rawDiscovered) {
                let discovered = rawDiscovered;
                if (discovered.startsWith('/')) {
                    const u = new URL(url);
                    discovered = u.origin + discovered;
                }
                const res2 = await NativeBridge.fetchUrl(discovered);
                if (res2.success && res2.data) {
                    feedUrl = discovered;
                    parsed = FeedParser.parse(res2.data, discovered);
                }
            }
        }

        // Case A: It is a valid RSS / YouTube / Reddit / WhatsApp / Podcast Feed!
        if (parsed && parsed.title && parsed.items && parsed.items.length > 0) {
            if (category === 'Genel') {
                if ((resolved && resolved.isYouTube) || feedUrl.includes('youtube.com/feeds/videos.xml')) {
                    category = 'YouTube';
                } else if ((resolved && resolved.isReddit) || feedUrl.includes('reddit.com/r/')) {
                    category = 'Reddit';
                } else if ((resolved && resolved.isWhatsApp) || feedUrl.includes('whatsapp.com/channel/')) {
                    category = 'WhatsApp';
                } else if (parsed.items.some(i => i.isPodcast)) {
                    category = 'Podcast';
                }
            }

            let icon = parsed.icon || '';
            if (!icon) {
                try {
                    const domain = new URL(parsed.link || url).hostname;
                    icon = `https://www.google.com/s2/favicons?domain=${domain}`;
                } catch (ignored) {}
            }

            const newFeed = {
                id: 'feed_' + Math.abs(this.hashCode(feedUrl)).toString(36),
                title: parsed.title,
                url: feedUrl,
                siteUrl: parsed.link || url,
                category: category,
                icon: icon,
                notificationsEnabled: notifyEnabled
            };

            await this.storage.saveFeed(newFeed);
            await this.storage.saveArticles(parsed.items, newFeed.id);

            this.closeSubPage();
            NativeBridge.haptic(1);
            NativeBridge.toast(`"${newFeed.title}" eklendi (${parsed.items.length} yayın)`);
            await this.loadFeeds();
            await this.refreshAllViews();
            await this.syncWithNativeBackgroundService();
            return;
        }

        // Case B: Single Article or YouTube Video URL -> Save directly to Library!
        await this.saveSingleWebPageFromHtml(url, res.data, category);
    }

    async saveSingleWebPageFromHtml(url, htmlData, category = '') {
        const videoId = FeedParser.extractYoutubeVideoId(url);
        const domain = FeedParser.extractDomain(url);

        let title = domain || 'Kaydedilen Sayfa';
        let contentHtml = '';
        let summary = '';
        let thumbnail = videoId ? `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg` : '';

        if (htmlData) {
            const titleMatch = htmlData.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
            if (titleMatch && titleMatch[1]) {
                title = FeedParser.stripHtmlFast(titleMatch[1]).replace(/\s*-\s*YouTube$/i, '').trim() || title;
            }
            const ogImg = htmlData.match(/<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']/i) ||
                          htmlData.match(/<meta[^>]+content=["']([^"']+)["'][^>]+property=["']og:image["']/i);
            if (!thumbnail && ogImg && ogImg[1]) {
                thumbnail = ogImg[1];
            }
            const extracted = ReaderExtractor.extractArticle(htmlData, title);
            if (extracted) {
                contentHtml = extracted;
                summary = FeedParser.createSummary(extracted);
            } else {
                const descMatch = htmlData.match(/<meta[^>]+(?:name|property)=["'](?:description|og:description)["'][^>]+content=["']([^"']+)["']/i);
                summary = descMatch && descMatch[1] ? FeedParser.decodeEntities(descMatch[1]) : url;
                contentHtml = `<p>${escapeHtml(summary)}</p>`;
            }
        } else {
            summary = url;
            contentHtml = `<p><a href="${escapeHtml(url)}">${escapeHtml(url)}</a></p>`;
        }

        const article = {
            id: FeedParser.hashString('saved_' + url),
            guid: 'saved_' + url,
            feedId: 'saved_items',
            title: title,
            link: url,
            domain: domain,
            author: '',
            pubDate: new Date().toISOString(),
            timestamp: Date.now(),
            summary: summary,
            content: contentHtml,
            fullContent: contentHtml || null,
            thumbnail: thumbnail,
            readingTimeMin: FeedParser.estimateReadingTime(contentHtml || summary),
            customTag: category && category !== 'Genel' ? category : (videoId ? 'YouTube' : 'Kaydedilenler'),
            unread: true,
            starred: true,
            isVideo: Boolean(videoId),
            videoId: videoId || null,
            isPodcast: false,
            audioUrl: null,
            audioType: null,
            audioDuration: null,
            mediaType: videoId ? 'video' : 'article'
        };

        await this.storage.saveSingleArticle(article);
        this.closeSubPage();
        NativeBridge.haptic(1);
        NativeBridge.toast('Kütüphaneye kaydedildi');
        await this.refreshAllViews();
    }

    async resolveFeedUrl(inputUrl) {
        let url = inputUrl.trim();
        if (!url) return null;

        // 1. Shorthand Reddit: "r/turkey" or "/r/technology"
        if (/^\/?r\/[a-zA-Z0-9_]{2,50}\/?$/i.test(url)) {
            const sub = url.replace(/^\/?r\//i, '').replace(/\/+$/, '');
            return {
                feedUrl: `https://www.reddit.com/r/${sub}/.rss`,
                siteUrl: `https://www.reddit.com/r/${sub}/`,
                isReddit: true
            };
        }

        // 2. Shorthand YouTube handle: "@kanaladi"
        if (url.startsWith('@')) {
            url = 'https://www.youtube.com/' + url;
        }

        if (!url.startsWith('http://') && !url.startsWith('https://')) {
            url = 'https://' + url;
        }

        // 3. WhatsApp Channel URLs
        if (url.includes('whatsapp.com/channel/') || url.includes('wa.me/channel/')) {
            const normalized = url.replace('wa.me/channel/', 'www.whatsapp.com/channel/');
            return {
                feedUrl: normalized,
                siteUrl: normalized,
                isWhatsApp: true
            };
        }

        // 4. Reddit Subreddit URLs
        if (url.includes('reddit.com/r/') && !url.includes('/comments/')) {
            if (url.endsWith('.rss')) {
                return { feedUrl: url, siteUrl: url.replace(/\/?\.rss$/, ''), isReddit: true };
            }
            const m = url.match(/reddit\.com\/r\/([a-zA-Z0-9_]+)/i);
            if (m && m[1]) {
                return {
                    feedUrl: `https://www.reddit.com/r/${m[1]}/.rss`,
                    siteUrl: `https://www.reddit.com/r/${m[1]}/`,
                    isReddit: true
                };
            }
        }

        // 5. YouTube Channel / Playlist URLs
        if (url.includes('youtube.com') || url.includes('youtu.be')) {
            if (url.includes('/feeds/videos.xml')) {
                return { feedUrl: url, siteUrl: url, isYouTube: true };
            }

            const channelMatch = url.match(/\/channel\/(UC[a-zA-Z0-9_-]{22})/i);
            if (channelMatch) {
                return {
                    feedUrl: `https://www.youtube.com/feeds/videos.xml?channel_id=${channelMatch[1]}`,
                    siteUrl: url,
                    isYouTube: true
                };
            }

            const playlistMatch = url.match(/[?&]list=([a-zA-Z0-9_-]+)/i);
            if (playlistMatch && !url.includes('watch?v=')) {
                return {
                    feedUrl: `https://www.youtube.com/feeds/videos.xml?playlist_id=${playlistMatch[1]}`,
                    siteUrl: url,
                    isYouTube: true
                };
            }

            if (!url.includes('watch?v=') && !url.includes('youtu.be/')) {
                try {
                    const res = await NativeBridge.fetchUrl(url);
                    if (res.success && res.data) {
                        const rssMatch = res.data.match(/<link[^>]+type=["']application\/rss\+xml["'][^>]+href=["']([^"']+)["']/i);
                        if (rssMatch && rssMatch[1]) {
                            return { feedUrl: rssMatch[1], siteUrl: url, isYouTube: true };
                        }
                        const idMatch = res.data.match(/"externalId"\s*:\s*"(UC[a-zA-Z0-9_-]{22})"/i) ||
                                        res.data.match(/"channelId"\s*:\s*"(UC[a-zA-Z0-9_-]{22})"/i) ||
                                        res.data.match(/itemprop=["']channelId["']\s+content=["'](UC[a-zA-Z0-9_-]{22})["']/i) ||
                                        res.data.match(/channel_id=(UC[a-zA-Z0-9_-]{22})/i) ||
                                        res.data.match(/\/channel\/(UC[a-zA-Z0-9_-]{22})/i);
                        if (idMatch && idMatch[1]) {
                            return {
                                feedUrl: `https://www.youtube.com/feeds/videos.xml?channel_id=${idMatch[1]}`,
                                siteUrl: url,
                                isYouTube: true
                            };
                        }
                    }
                } catch (err) {
                    console.warn('YouTube channel resolution failed:', err);
                }
            }
        }

        return { feedUrl: url, siteUrl: url, isYouTube: false };
    }

    hashCode(str) {
        let hash = 0;
        for (let i = 0; i < str.length; i++) {
            hash = ((hash << 5) - hash) + str.charCodeAt(i);
            hash |= 0;
        }
        return hash;
    }

    // ========================================================
    // READER VIEW (With Native Direct-Stream YouTube Player)
    // ========================================================
    async openArticle(article) {
        this.currentArticleId = article.id;
        NativeBridge.haptic(0);

        if (article.unread) {
            article.unread = false;
            await this.storage.markArticleRead(article.id, true);
            const rowEl = document.querySelector(`.library-row[data-article-id="${article.id}"]`);
            if (rowEl) rowEl.classList.add('read');
        }

        this.renderReader(article);
        this.openSubPage('page-reader');
    }

    renderReader(article) {
        document.getElementById('reader-feed-name').textContent = article.feedTitle || article.domain || 'Kaynak';
        const feedIconEl = document.getElementById('reader-feed-icon');
        if (feedIconEl) {
            if (article.feedIcon) {
                feedIconEl.src = article.feedIcon;
                feedIconEl.style.display = 'inline-block';
            } else {
                feedIconEl.style.display = 'none';
            }
        }

        const readTimeEl = document.getElementById('reader-reading-time');
        if (readTimeEl) {
            if (article.isPodcast && article.audioDuration) {
                readTimeEl.textContent = article.audioDuration;
            } else {
                readTimeEl.textContent = `${article.readingTimeMin || 1} dk`;
            }
        }

        document.getElementById('reader-title').textContent = article.title;

        const dateStr = new Date(article.timestamp).toLocaleDateString('tr-TR', {
            year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit'
        });
        document.getElementById('reader-date').textContent = dateStr;
        document.getElementById('reader-author').textContent = article.author ? `${article.author} • ` : '';

        // Strictly In-App YouTube Video Player (Never opens externally!)
        const videoWrapper = document.getElementById('reader-video-wrapper');
        const videoPlayer = document.getElementById('reader-video-player');
        const videoIframe = document.getElementById('reader-video-iframe');
        const videoOverlay = document.getElementById('reader-video-overlay');
        const videoStatus = document.getElementById('reader-video-status');
        const videoAudioBtn = document.getElementById('btn-reader-youtube-audio');

        if (article.isVideo && article.videoId) {
            videoWrapper.style.display = 'block';
            const posterUrl = `https://i.ytimg.com/vi/${article.videoId}/hqdefault.jpg`;
            videoPlayer.style.display = 'block';
            videoPlayer.poster = posterUrl;
            videoPlayer.pause();
            videoPlayer.removeAttribute('src');
            if (videoIframe) {
                videoIframe.style.display = 'none';
                videoIframe.src = 'about:blank';
            }
            videoOverlay.style.display = 'flex';
            videoStatus.textContent = 'Uygulama içi video hazırlanıyor...';

            const currentVid = article.videoId;
            let resolvedStream = null;
            let isResolving = true;

            const switchToInAppEmbed = () => {
                if (this.currentArticleId !== article.id) return;
                videoOverlay.style.display = 'none';
                if (videoPlayer) {
                    try {
                        videoPlayer.pause();
                        videoPlayer.style.display = 'none';
                    } catch (ignored) {}
                }
                if (videoIframe) {
                    videoIframe.style.display = 'block';
                    videoIframe.src = `https://www.youtube-nocookie.com/embed/${encodeURIComponent(currentVid)}?autoplay=1&playsinline=1&rel=0&modestbranding=1`;
                }
            };

            const streamPromise = NativeBridge.resolveYoutubeVideo(currentVid).then((streamInfo) => {
                isResolving = false;
                if (this.currentArticleId !== article.id) return streamInfo;
                if (streamInfo && streamInfo.success && streamInfo.videoUrl) {
                    resolvedStream = streamInfo;
                    videoPlayer.src = streamInfo.videoUrl;
                    videoStatus.textContent = `Oynatmak için dokunun (${streamInfo.quality || 'MP4'})`;
                } else {
                    videoStatus.textContent = 'Uygulama içinde oynatmak için dokunun';
                }
                return streamInfo;
            }).catch(() => {
                isResolving = false;
                if (this.currentArticleId === article.id) {
                    videoStatus.textContent = 'Uygulama içinde oynatmak için dokunun';
                }
                return null;
            });

            const startInAppPlayback = async () => {
                if (isResolving && !resolvedStream) {
                    videoStatus.textContent = 'Video akışı hazırlanıyor, lütfen bekleyin...';
                    await streamPromise;
                }
                if (this.currentArticleId !== article.id) return;

                if (resolvedStream && resolvedStream.videoUrl) {
                    videoOverlay.style.display = 'none';
                    if (videoIframe) {
                        videoIframe.style.display = 'none';
                        videoIframe.src = 'about:blank';
                    }
                    videoPlayer.style.display = 'block';
                    if (!videoPlayer.src) {
                        videoPlayer.src = resolvedStream.videoUrl;
                    }
                    videoPlayer.play().catch((err) => {
                        console.warn('Direct MP4 play fallback to in-app embed:', err);
                        switchToInAppEmbed();
                    });
                } else {
                    switchToInAppEmbed();
                }
            };

            videoOverlay.onclick = () => {
                startInAppPlayback();
            };

            videoPlayer.onplay = () => {
                videoOverlay.style.display = 'none';
            };

            videoPlayer.onerror = () => {
                if (videoOverlay.style.display === 'none') {
                    switchToInAppEmbed();
                }
            };

            if (videoAudioBtn) {
                videoAudioBtn.onclick = async () => {
                    if (!resolvedStream) {
                        NativeBridge.toast('Ses akışı hazırlanıyor...');
                        resolvedStream = await streamPromise;
                    }
                    const audioStreamUrl = resolvedStream && (resolvedStream.audioUrl || resolvedStream.videoUrl);
                    if (audioStreamUrl) {
                        videoPlayer.pause();
                        this.playPodcast({
                            ...article,
                            audioUrl: audioStreamUrl,
                            isPodcast: true
                        });
                        NativeBridge.toast('Arka plan ses oynatıcı başlatıldı');
                    } else {
                        NativeBridge.toast('Ses akışı alınamadı');
                    }
                };
            }
        } else {
            videoWrapper.style.display = 'none';
            this.stopReaderVideoPlayer();
        }

        // Podcast Audio Player Handling
        const podcastWrapper = document.getElementById('reader-podcast-wrapper');
        const podcastDuration = document.getElementById('reader-podcast-duration');
        const podcastExtLink = document.getElementById('btn-podcast-ext');

        if (article.isPodcast && article.audioUrl) {
            podcastWrapper.style.display = 'block';
            podcastDuration.textContent = article.audioDuration || '';
            podcastExtLink.href = article.audioUrl;

            const isThisPlaying = (this.currentAudioArticle && this.currentAudioArticle.id === article.id && this.isAudioPlaying);
            this.updateAudioButtonsUI(isThisPlaying);
        } else {
            podcastWrapper.style.display = 'none';
        }

        const starBtn = document.getElementById('btn-reader-star');
        starBtn.classList.toggle('starred', Boolean(article.starred));

        const extractBtn = document.getElementById('btn-reader-extract');
        extractBtn.classList.toggle('active', Boolean(article.fullContent));

        const contentContainer = document.getElementById('reader-content');
        if (article.fullContent) {
            contentContainer.innerHTML = article.fullContent;
        } else {
            contentContainer.innerHTML = article.content || `<p>${escapeHtml(article.summary || '')}</p>`;
        }

        // Intercept any YouTube links inside article content so they play in-app instead of externally
        contentContainer.querySelectorAll('a[href]').forEach(linkEl => {
            const href = linkEl.getAttribute('href') || '';
            const ytVid = FeedParser.extractYoutubeVideoId(href);
            if (ytVid) {
                linkEl.onclick = (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    article.isVideo = true;
                    article.videoId = ytVid;
                    this.renderReader(article);
                    const vo = document.getElementById('reader-video-overlay');
                    if (vo) vo.click();
                };
            }
        });

        const origBtn = document.getElementById('btn-visit-original');
        if (article.isVideo && article.videoId) {
            origBtn.textContent = 'Videoyu Uygulamada Oynat';
            origBtn.onclick = () => {
                document.getElementById('reader-scroll').scrollTop = 0;
                if (videoOverlay && videoOverlay.style.display !== 'none') {
                    videoOverlay.click();
                } else if (videoPlayer && videoPlayer.style.display !== 'none') {
                    videoPlayer.play().catch(() => {});
                }
            };
        } else {
            origBtn.textContent = 'Tarayıcıda Aç';
            origBtn.onclick = () => NativeBridge.openExternal(article.link);
        }

        const listPool = this.activeTab === 'discover' ? this.discoverArticles : this.articles;
        const idx = listPool.findIndex(a => a.id === article.id);
        const prevBtn = document.getElementById('btn-nav-prev');
        const nextBtn = document.getElementById('btn-nav-next');

        prevBtn.disabled = (idx <= 0);
        nextBtn.disabled = (idx < 0 || idx >= listPool.length - 1);

        prevBtn.onclick = () => {
            if (idx > 0) this.openArticle(listPool[idx - 1]);
        };
        nextBtn.onclick = () => {
            if (idx < listPool.length - 1) this.openArticle(listPool[idx + 1]);
        };

        document.getElementById('reader-scroll').scrollTop = 0;
    }

    async toggleCurrentArticleStar() {
        if (!this.currentArticleId) return;
        NativeBridge.haptic(0);
        const isStarred = await this.storage.toggleStar(this.currentArticleId);

        const starBtn = document.getElementById('btn-reader-star');
        starBtn.classList.toggle('starred', isStarred);

        const article = this.articles.find(a => a.id === this.currentArticleId) ||
                        this.discoverArticles.find(a => a.id === this.currentArticleId);
        if (article) article.starred = isStarred;

        NativeBridge.toast(isStarred ? 'Favorilere eklendi' : 'Favorilerden çıkarıldı');
        this.refreshAllViews();
    }

    async toggleMercuryExtraction() {
        if (!this.currentArticleId) return;
        const article = this.articles.find(a => a.id === this.currentArticleId) ||
                        this.discoverArticles.find(a => a.id === this.currentArticleId);
        if (!article) return;

        const extractBtn = document.getElementById('btn-reader-extract');

        if (article.fullContent) {
            article.fullContent = null;
            await this.storage.saveFullContent(article.id, null);
            extractBtn.classList.remove('active');
            this.renderReader(article);
            NativeBridge.toast('Özet görünüme dönüldü');
            return;
        }

        NativeBridge.toast('Tam metin yükleniyor...');
        extractBtn.classList.add('active');

        const res = await NativeBridge.fetchUrl(article.link);
        if (res.success && res.data) {
            const extracted = ReaderExtractor.extractArticle(res.data, article.title);
            if (extracted) {
                article.fullContent = extracted;
                await this.storage.saveFullContent(article.id, extracted);
                this.renderReader(article);
                NativeBridge.toast('Tam metin yüklendi');
            } else {
                extractBtn.classList.remove('active');
                NativeBridge.toast('Tam metin ayrıştırılamadı');
            }
        } else {
            extractBtn.classList.remove('active');
            NativeBridge.toast('Sayfa indirilemedi');
        }
    }

    // Parallel High-Speed Syncing (Only re-renders UI if new articles arrived or manual sync)
    async syncAllFeeds(silent = false) {
        if (this.isSyncing) return;
        if (this.feeds.length === 0) {
            return;
        }

        this.isSyncing = true;
        let successCount = 0;
        let totalNewlyAdded = 0;

        await Promise.allSettled(this.feeds.map(async (feed) => {
            try {
                const res = await NativeBridge.fetchUrl(feed.url);
                if (res.success && res.data) {
                    const parsed = FeedParser.parse(res.data, feed.url);
                    if (parsed.items && parsed.items.length > 0) {
                        const saveRes = await this.storage.saveArticles(parsed.items, feed.id);
                        successCount++;

                        if (saveRes && saveRes.newlyAdded && saveRes.newlyAdded.length > 0) {
                            totalNewlyAdded += saveRes.newlyAdded.length;
                            if (this.notificationsEnabled && feed.notificationsEnabled !== false) {
                                const newCount = saveRes.newlyAdded.length;
                                const firstArt = saveRes.newlyAdded[0];
                                const notifMsg = newCount === 1 ? firstArt.title : `+${newCount} yeni yayın: ${firstArt.title}`;
                                const notifId = Math.abs(this.hashCode(feed.id + '_' + firstArt.id)) % 900000 + 1000;
                                NativeBridge.showNotification(feed.title, notifMsg, firstArt.id, notifId);
                            }
                        }
                    }
                }
            } catch (err) {
                console.error('Sync error for', feed.url, err);
            }
        }));

        this.isSyncing = false;
        if (totalNewlyAdded > 0 || !silent) {
            await this.refreshAllViews();
            await this.syncWithNativeBackgroundService();
        }

        if (!silent) {
            NativeBridge.toast(`Güncellendi (${successCount} kaynak)`);
        }
    }

    async handleExportOpml() {
        const opmlXml = await this.storage.exportOpml();
        const blob = new Blob([opmlXml], { type: 'text/xml' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'kevki_kaynaklar.opml';
        a.click();
        URL.revokeObjectURL(url);
        NativeBridge.toast('OPML dosyası indirildi');
    }

    initSwipeGestures() {
        const readerPage = document.getElementById('page-reader');
        let rStartX = 0;
        let rStartY = 0;

        readerPage.addEventListener('touchstart', (e) => {
            if (e.touches.length !== 1) return;
            rStartX = e.touches[0].clientX;
            rStartY = e.touches[0].clientY;
        }, { passive: true });

        readerPage.addEventListener('touchend', (e) => {
            if (e.changedTouches.length !== 1) return;
            const dx = e.changedTouches[0].clientX - rStartX;
            const dy = e.changedTouches[0].clientY - rStartY;

            if (Math.abs(dx) > 80 && Math.abs(dx) > Math.abs(dy) * 1.8) {
                if (rStartX < 42 && dx > 80) {
                    NativeBridge.haptic(0);
                    this.closeSubPage();
                    return;
                }

                const listPool = this.activeTab === 'discover' ? this.discoverArticles : this.articles;
                const idx = listPool.findIndex(a => a.id === this.currentArticleId);
                if (dx < -90 && idx >= 0 && idx < listPool.length - 1) {
                    NativeBridge.haptic(0);
                    this.openArticle(listPool[idx + 1]);
                } else if (dx > 90 && idx > 0) {
                    NativeBridge.haptic(0);
                    this.openArticle(listPool[idx - 1]);
                }
            }
        }, { passive: true });

        const pullBanner = document.getElementById('pull-refresh-indicator');
        const pullText = document.getElementById('pull-refresh-text');

        ['discover-stream-container', 'library-list-container'].forEach(containerId => {
            const scroller = document.getElementById(containerId);
            if (!scroller) return;
            let pStartX = 0;
            let pStartY = 0;
            let canPull = false;

            scroller.addEventListener('touchstart', (e) => {
                if (e.touches.length !== 1) return;
                pStartX = e.touches[0].clientX;
                pStartY = e.touches[0].clientY;
                canPull = (scroller.scrollTop <= 0);
            }, { passive: true });

            scroller.addEventListener('touchmove', (e) => {
                if (!canPull || e.touches.length !== 1) return;
                const dy = e.touches[0].clientY - pStartY;
                const dx = e.touches[0].clientX - pStartX;
                if (dy > 25 && dy > Math.abs(dx) * 1.5 && scroller.scrollTop <= 0) {
                    const h = Math.min(42, Math.floor((dy - 25) * 0.4));
                    if (pullBanner) pullBanner.style.height = h + 'px';
                    if (pullText) {
                        pullText.textContent = dy > 100 ? 'Yenilemek için bırakın' : 'Yenilemek için aşağı çekin';
                    }
                }
            }, { passive: true });

            scroller.addEventListener('touchend', (e) => {
                if (pullBanner) pullBanner.style.height = '0px';
                if (!canPull || e.changedTouches.length !== 1) return;
                const dy = e.changedTouches[0].clientY - pStartY;
                const dx = e.changedTouches[0].clientX - pStartX;
                if (dy > 100 && Math.abs(dy) > Math.abs(dx) * 1.5 && scroller.scrollTop <= 0) {
                    NativeBridge.haptic(0);
                    this.syncAllFeeds(false);
                }
                canPull = false;
            }, { passive: true });
        });
    }

    async triggerOpmlCsvPhonePicker() {
        this.pendingImportService = 'OPML_CSV';
        if (NativeBridge.isAndroid() && window.Android && window.Android.pickImportFile) {
            const res = await NativeBridge.pickImportFile();
            if (res && res.success && res.content) {
                await this.executeImportText(res.content, res.fileName || 'import.opml');
            } else if (res && !res.cancelled && res.error) {
                NativeBridge.toast(res.error);
            }
            return;
        }
        const importFileInput = document.getElementById('import-file-input');
        if (importFileInput) {
            importFileInput.value = '';
            importFileInput.click();
        }
    }

    async executeImportText(text, fileName = 'import.opml') {
        if (!text || !text.trim()) {
            NativeBridge.toast('Seçilen dosya boş veya okunamadı');
            return;
        }
        try {
            const result = await this.storage.importFromExternalService(text, fileName, 'OPML_CSV');
            await this.loadFeeds();
            await this.refreshAllViews();
            await this.syncWithNativeBackgroundService();
            if (result.feedsCount > 0 && result.articlesCount > 0) {
                NativeBridge.toast(`${result.feedsCount} kaynak ve ${result.articlesCount} yayın içe aktarıldı`);
                this.syncAllFeeds(false);
            } else if (result.feedsCount > 0) {
                NativeBridge.toast(`${result.feedsCount} kaynak eklendi, yayınlar çekiliyor...`);
                this.syncAllFeeds(false);
            } else if (result.articlesCount > 0) {
                NativeBridge.toast(`${result.articlesCount} kayıt kütüphaneye aktarıldı`);
            } else {
                NativeBridge.toast('Dosyada geçerli OPML veya CSV verisi bulunamadı');
                return;
            }
            this.closeSubPage();
            this.switchTab('library');
        } catch (err) {
            NativeBridge.toast('İçe aktarma hatası: ' + err.message);
        }
    }

    bindEvents() {
        // Bottom Navigation View Tabs
        document.querySelectorAll('.bottom-nav-item').forEach(btn => {
            btn.onclick = () => {
                NativeBridge.haptic(0);
                this.switchTab(btn.dataset.tab);
            };
        });

        // Brand click -> refresh
        const brandEl = document.getElementById('brand-logo-click');
        if (brandEl) {
            brandEl.onclick = () => this.syncAllFeeds(false);
        }

        // Top Bar Search & Add
        const searchDrawer = document.getElementById('top-search-drawer');
        const searchInput = document.getElementById('global-search-input');
        document.getElementById('btn-top-search').onclick = () => {
            const isHidden = searchDrawer.style.display === 'none';
            searchDrawer.style.display = isHidden ? 'flex' : 'none';
            if (isHidden) {
                searchInput.focus();
            } else {
                searchInput.value = '';
                this.searchQuery = '';
                this.refreshAllViews();
            }
        };

        document.getElementById('btn-clear-search').onclick = () => {
            searchDrawer.style.display = 'none';
            searchInput.value = '';
            this.searchQuery = '';
            this.refreshAllViews();
        };

        searchInput.oninput = () => {
            this.searchQuery = searchInput.value;
            this.refreshAllViews();
        };

        document.getElementById('btn-top-add').onclick = () => this.openAddPage();

        // Active Source Filter Banner Actions
        const btnBannerClear = document.getElementById('btn-source-banner-clear');
        if (btnBannerClear) {
            btnBannerClear.onclick = () => {
                this.currentFeedId = null;
                this.refreshAllViews();
            };
        }
        const btnBannerEdit = document.getElementById('btn-source-banner-edit');
        if (btnBannerEdit) {
            btnBannerEdit.onclick = () => {
                const feed = this.feeds.find(f => f.id === this.currentFeedId);
                if (feed) {
                    this.renderManageFeedsPage();
                    this.openSubPage('page-feeds');
                    this.openFeedInlineEditor(feed);
                }
            };
        }

        // Library Filter Pills
        document.querySelectorAll('.filter-pill').forEach(pill => {
            pill.onclick = () => {
                this.currentFilter = pill.dataset.filter;
                document.querySelectorAll('.filter-pill').forEach(p => {
                    p.classList.toggle('active', p.dataset.filter === this.currentFilter);
                });
                this.currentCategory = null;
                this.refreshAllViews();
            };
        });

        // Sort Trigger & Sort Menu Popup
        const sortBackdrop = document.getElementById('sort-menu-backdrop');
        document.getElementById('btn-sort-trigger').onclick = () => {
            sortBackdrop.style.display = 'flex';
            this.updateNavState();
        };
        sortBackdrop.onclick = (e) => {
            if (e.target === sortBackdrop) {
                sortBackdrop.style.display = 'none';
                this.updateNavState();
            }
        };
        document.querySelectorAll('.sort-opt').forEach(opt => {
            opt.onclick = async () => {
                this.sortBy = opt.dataset.sort;
                await this.storage.setSetting('sortBy', this.sortBy);
                this.updateSortUI();
                sortBackdrop.style.display = 'none';
                this.updateNavState();
                await this.refreshAllViews();
            };
        });

        // Context Menu ('•••') Actions
        const ctxBackdrop = document.getElementById('context-menu-backdrop');
        ctxBackdrop.onclick = (e) => {
            if (e.target === ctxBackdrop) {
                ctxBackdrop.style.display = 'none';
                this.updateNavState();
            }
        };

        document.getElementById('ctx-share').onclick = () => {
            ctxBackdrop.style.display = 'none';
            this.updateNavState();
            if (this.contextArticle) {
                NativeBridge.share(this.contextArticle.title, this.contextArticle.link);
            }
        };

        document.getElementById('ctx-save').onclick = async () => {
            ctxBackdrop.style.display = 'none';
            this.updateNavState();
            if (this.contextArticle) {
                const isStarred = await this.storage.toggleStar(this.contextArticle.id);
                this.contextArticle.starred = isStarred;
                NativeBridge.toast(isStarred ? 'Favorilere eklendi' : 'Favorilerden çıkarıldı');
                await this.refreshAllViews();
            }
        };

        document.getElementById('ctx-read-toggle').onclick = async () => {
            ctxBackdrop.style.display = 'none';
            this.updateNavState();
            if (this.contextArticle) {
                this.contextArticle.unread = !this.contextArticle.unread;
                await this.storage.markArticleRead(this.contextArticle.id, !this.contextArticle.unread);
                NativeBridge.toast(this.contextArticle.unread ? 'Okunmadı işaretlendi' : 'Okundu işaretlendi');
                await this.refreshAllViews();
            }
        };

        document.getElementById('ctx-open-browser').onclick = () => {
            ctxBackdrop.style.display = 'none';
            this.updateNavState();
            if (this.contextArticle) {
                if (this.contextArticle.isVideo && this.contextArticle.videoId) {
                    this.openArticle(this.contextArticle);
                    return;
                }
                NativeBridge.openExternal(this.contextArticle.link);
            }
        };

        document.getElementById('ctx-edit-feed').onclick = () => {
            ctxBackdrop.style.display = 'none';
            this.updateNavState();
            if (this.contextArticle) {
                const feed = this.feeds.find(f => f.id === this.contextArticle.feedId);
                if (feed) {
                    this.renderManageFeedsPage();
                    this.openSubPage('page-feeds');
                    this.openFeedInlineEditor(feed);
                }
            }
        };

        // Settings Page Rows & Lifetime One-Time In-App Purchase Toggle (Styled like Anlık Bildirimler)
        const iapToggle = document.getElementById('setting-iap-toggle');
        const handleLifetimePurchaseToggle = async (targetChecked) => {
            if (targetChecked) {
                const plan = this.lifetimePlan;
                const res = await NativeBridge.launchPurchaseFlow(plan.sku, plan.title, plan.price);
                if (res && res.success) {
                    this.billingState = res;
                    this.updateBillingUI();
                    this.startFastRealtimeSyncLoop();
                    NativeBridge.toast('Ömür Boyu Premium etkinleştirildi!');
                } else {
                    if (iapToggle) iapToggle.checked = Boolean(this.billingState && this.billingState.isPro);
                    if (res && !res.cancelled && res.error) {
                        NativeBridge.toast(res.error);
                    }
                }
            } else {
                if (this.billingState && this.billingState.isPro) {
                    if (confirm('Ömür Boyu Premium lisansını bu cihazda devre dışı bırakmak istiyor musunuz?')) {
                        await NativeBridge.cancelSubscription();
                        this.billingState = { isPro: false };
                        this.updateBillingUI();
                        NativeBridge.toast('Premium devre dışı bırakıldı');
                    } else {
                        if (iapToggle) iapToggle.checked = true;
                    }
                }
            }
        };

        if (iapToggle) {
            iapToggle.onchange = (e) => {
                e.stopPropagation();
                handleLifetimePurchaseToggle(iapToggle.checked);
            };
        }

        const iapRow = document.getElementById('row-iap-lifetime');
        if (iapRow) {
            iapRow.onclick = (e) => {
                if (e.target.closest('.kevki-switch')) return;
                const currentlyPro = Boolean(this.billingState && this.billingState.isPro);
                handleLifetimePurchaseToggle(!currentlyPro);
            };
        }

        document.getElementById('row-manage-feeds').onclick = () => {
            document.getElementById('feed-editor-panel').style.display = 'none';
            this.renderManageFeedsPage();
            this.openSubPage('page-feeds');
        };

        document.getElementById('row-open-import').onclick = () => {
            this.openSubPage('page-import');
        };

        document.getElementById('row-export-opml').onclick = () => {
            this.handleExportOpml();
        };

        document.getElementById('row-open-appearance').onclick = () => {
            this.openSubPage('page-appearance');
        };

        document.getElementById('row-clear-data').onclick = async () => {
            if (confirm('Tüm kayıtlı yayınları ve kaynakları silmek istediğinize emin misiniz?')) {
                this.currentFeedId = null;
                this.currentCategory = null;
                await this.storage.clearAllData();
                await this.loadFeeds();
                await this.refreshAllViews();
                await this.syncWithNativeBackgroundService();
                NativeBridge.toast('Veriler sıfırlandı');
            }
        };

        // Sub-Page Back / Cancel Buttons
        document.getElementById('btn-add-cancel').onclick = () => this.closeSubPage();
        document.getElementById('btn-submit-add').onclick = () => this.handleAddSubmit();

        document.getElementById('btn-import-back').onclick = () => this.closeSubPage();
        document.getElementById('btn-feeds-back').onclick = () => this.closeSubPage();
        document.getElementById('btn-feeds-add').onclick = () => this.openAddPage();
        document.getElementById('btn-appearance-back').onclick = () => this.closeSubPage();
        document.getElementById('btn-reader-back').onclick = () => this.closeSubPage();

        // Feed Editor Actions
        document.getElementById('btn-cancel-edit-feed').onclick = () => {
            document.getElementById('feed-editor-panel').style.display = 'none';
        };
        document.getElementById('btn-submit-edit-feed').onclick = () => this.handleEditFeedSubmit();
        document.getElementById('btn-delete-feed').onclick = () => this.handleDeleteFeed();

        // Import Page (OPML / CSV Only from Phone)
        const importFileInput = document.getElementById('import-file-input');
        const rowImportOpmlCsv = document.getElementById('row-import-opml-csv');
        if (rowImportOpmlCsv) {
            rowImportOpmlCsv.onclick = () => this.triggerOpmlCsvPhonePicker();
        }
        const btnImportPickPhone = document.getElementById('btn-import-pick-phone-file');
        if (btnImportPickPhone) {
            btnImportPickPhone.onclick = () => this.triggerOpmlCsvPhonePicker();
        }

        if (importFileInput) {
            importFileInput.onchange = (e) => {
                const file = e.target.files[0];
                if (!file) return;
                const reader = new FileReader();
                reader.onload = async (evt) => {
                    await this.executeImportText(evt.target.result, file.name);
                };
                reader.readAsText(file);
            };
        }

        // Reader Toolbar Buttons
        document.getElementById('btn-reader-star').onclick = () => this.toggleCurrentArticleStar();
        document.getElementById('btn-reader-extract').onclick = () => this.toggleMercuryExtraction();
        document.getElementById('btn-reader-appearance').onclick = () => this.openSubPage('page-appearance');
        document.getElementById('btn-reader-share').onclick = () => {
            const article = this.articles.find(a => a.id === this.currentArticleId) ||
                            this.discoverArticles.find(a => a.id === this.currentArticleId);
            if (article) NativeBridge.share(article.title, article.link);
        };
        document.getElementById('btn-reader-open-ext').onclick = () => {
            const article = this.articles.find(a => a.id === this.currentArticleId) ||
                            this.discoverArticles.find(a => a.id === this.currentArticleId);
            if (!article) return;
            if (article.isVideo && article.videoId) {
                document.getElementById('reader-scroll').scrollTop = 0;
                const vo = document.getElementById('reader-video-overlay');
                if (vo && vo.style.display !== 'none') {
                    vo.click();
                }
                return;
            }
            NativeBridge.openExternal(article.link);
        };

        // Appearance Page Controls
        document.querySelectorAll('.appearance-option-btn[data-theme]').forEach(btn => {
            btn.onclick = () => this.applyTheme(btn.dataset.theme);
        });
        document.querySelectorAll('.font-opt-btn').forEach(btn => {
            btn.onclick = () => this.applyFont(btn.dataset.font);
        });
        document.getElementById('btn-font-dec').onclick = () => this.applyFontSize(this.fontSize - 1);
        document.getElementById('btn-font-inc').onclick = () => this.applyFontSize(this.fontSize + 1);
    }
}

function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/[&<>"']/g, m => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[m]));
}

document.addEventListener('DOMContentLoaded', () => {
    window.app = new KevkiApp();
    window.app.init();
});
