// Default pre-seeded feeds removed per user preference
const DEFAULT_FEEDS = [];

// Legacy default feed IDs to clean up automatically on upgrade
const LEGACY_DEFAULT_FEED_IDS = [
    'feed_theverge',
    'feed_hackernews',
    'feed_arstechnica',
    'feed_bbcturkce',
    'feed_webtekno',
    'feed_shiftdelete',
    'feed_smashing',
    'feed_kottke',
    'feed_yt_barisozcan',
    'feed_pod_fularsiz',
    'feed_pod_bbcturkce'
];

if (typeof module !== 'undefined' && module.exports) {
    module.exports = { DEFAULT_FEEDS, LEGACY_DEFAULT_FEED_IDS };
}
