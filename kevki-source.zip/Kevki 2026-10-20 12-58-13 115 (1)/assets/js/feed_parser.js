// Robust RSS 2.0, Atom 1.0, Reddit & WhatsApp Channel Parser for Kevki
class FeedParser {

    static parse(xmlString, feedUrl = '') {
        if (!xmlString) return { title: '', link: feedUrl, description: '', icon: null, items: [] };

        if (feedUrl && (feedUrl.includes('whatsapp.com/channel/') || feedUrl.includes('wa.me/channel/'))) {
            return this.parseWhatsAppChannel(xmlString, feedUrl);
        }

        const parser = new DOMParser();
        let doc = parser.parseFromString(xmlString, 'text/xml');

        const parseError = doc.getElementsByTagName('parsererror')[0];
        if (parseError) {
            doc = parser.parseFromString(xmlString, 'text/html');
            if (xmlString.includes('whatsapp.com/channel/')) {
                return this.parseWhatsAppChannel(xmlString, feedUrl);
            }
        }

        return this.extractFromDocument(doc, feedUrl);
    }

    static parseWhatsAppChannel(htmlString, channelUrl) {
        const cleanUrl = (channelUrl || '').replace(/[?&]_fb_noscript=1/g, '');
        const extractMeta = (prop) => {
            const r1 = new RegExp(`<meta[^>]+(?:property|name)=["']${prop}["'][^>]+content=["']([^"']*)["']`, 'i');
            const r2 = new RegExp(`<meta[^>]+content=["']([^"']*)["'][^>]+(?:property|name)=["']${prop}["']`, 'i');
            const m = htmlString.match(r1) || htmlString.match(r2);
            return m ? this.decodeEntities(m[1].trim()) : '';
        };

        let title = extractMeta('og:title') || extractMeta('twitter:title') || '';
        const h3Match = htmlString.match(/<h3[^>]*>([\s\S]*?)<\/h3>/i);
        if (h3Match && h3Match[1]) {
            const h3Text = this.stripHtmlFast(h3Match[1]).trim();
            if (h3Text && !/invite link|davet bağlantısı|whatsapp installed/i.test(h3Text)) {
                if (!title || /^whatsapp\s*(channel|kanalı)$/i.test(title)) {
                    title = h3Text;
                }
            }
        }
        if (!title || /^whatsapp\s*(channel|kanalı)$/i.test(title)) {
            const idPart = cleanUrl.split('/channel/')[1] ? cleanUrl.split('/channel/')[1].split(/[/?#]/)[0] : '';
            title = idPart ? `WhatsApp Kanalı (${idPart.substring(0, 8)})` : 'WhatsApp Kanalı';
        }

        const icon = extractMeta('og:image') || 'https://www.google.com/s2/favicons?domain=whatsapp.com&sz=128';
        const ogDesc = extractMeta('og:description') || extractMeta('description') || '';

        const items = [];
        const now = Date.now();

        // 1. Check for individual post links or message blocks in HTML
        const postBlockRegex = /<(?:div|p|span)[^>]+class=["'][^"']*(?:_9vd5|_9vd6|channel-post|message-text|copyable-text)[^"']*["'][^>]*>([\s\S]*?)<\/(?:div|p|span)>/gi;
        let match;
        let idx = 0;
        const seenTexts = new Set();

        while ((match = postBlockRegex.exec(htmlString)) !== null) {
            const text = this.stripHtmlFast(match[1]).trim();
            if (text && text.length > 20 && !/whatsapp|follow this|bu whatsapp kanalını|davet bağlantısı|invite link|download|indir/i.test(text)) {
                if (!seenTexts.has(text)) {
                    seenTexts.add(text);
                    const postTitle = text.length > 85 ? text.substring(0, 82) + '...' : text;
                    const guid = `${cleanUrl}#post_${this.hashString(text)}`;
                    items.push({
                        id: this.hashString(guid),
                        guid: guid,
                        title: postTitle,
                        link: cleanUrl,
                        domain: 'whatsapp.com',
                        author: title,
                        pubDate: new Date(now - idx * 60000).toISOString(),
                        timestamp: now - idx * 60000,
                        summary: text.substring(0, 180),
                        content: this.formatPlainTextAsHtml(text),
                        thumbnail: icon,
                        readingTimeMin: this.estimateReadingTime(text),
                        unread: true,
                        starred: false,
                        isVideo: false,
                        videoId: null,
                        isPodcast: false,
                        audioUrl: null,
                        audioType: null,
                        audioDuration: null,
                        mediaType: 'article'
                    });
                    idx++;
                }
            }
        }

        // 2. Also include the channel's latest description / update post if valid
        if (ogDesc && ogDesc.length > 10) {
            const isGenericBoilerplate = /follow this whatsapp channel|en yeni güncellemeleri doğrudan whatsapp/i.test(ogDesc);
            const bodyText = isGenericBoilerplate
                ? `${title} resmi WhatsApp kanalı Kevki kütüphanenize bağlandı. Kanaldaki yeni paylaşımlar ve güncellemeler otomatik olarak bu akışa düşer; ayrıca WhatsApp içinden herhangi bir kanal yazısını "Paylaş -> Kevki'ye Kaydet" ile anında buraya aktarabilirsiniz.`
                : ogDesc;

            const postTitle = isGenericBoilerplate
                ? `${title} — Kanal Akışı Aktif`
                : (ogDesc.length > 85 ? ogDesc.substring(0, 82) + '...' : ogDesc);

            const guid = `${cleanUrl}#desc_${this.hashString(bodyText)}`;
            if (!seenTexts.has(bodyText)) {
                items.unshift({
                    id: this.hashString(guid),
                    guid: guid,
                    title: postTitle,
                    link: cleanUrl,
                    domain: 'whatsapp.com',
                    author: title,
                    pubDate: new Date(now).toISOString(),
                    timestamp: now,
                    summary: bodyText.substring(0, 180),
                    content: `<p>${bodyText.replace(/\n/g, '<br>')}</p>`,
                    thumbnail: icon,
                    readingTimeMin: this.estimateReadingTime(bodyText),
                    unread: true,
                    starred: false,
                    isVideo: false,
                    videoId: null,
                    isPodcast: false,
                    audioUrl: null,
                    audioType: null,
                    audioDuration: null,
                    mediaType: 'article'
                });
            }
        }

        return {
            title: title,
            link: cleanUrl,
            description: ogDesc,
            icon: icon,
            items: items
        };
    }

    /**
     * Parses exported or pasted WhatsApp Channel messages/logs into structured articles
     */
    static parseWhatsAppTextExport(rawText, channelName = 'WhatsApp Kanalı') {
        if (!rawText || !rawText.trim()) return [];
        const lines = rawText.split(/\r?\n/);
        const articles = [];
        const now = Date.now();

        // Pattern 1: Standard WhatsApp export format: [12.05.2025 14:30] Channel: Message OR 12.05.2025 14:30 - Channel: Message
        const waLineRegex = /^(?:\[?(\d{1,2}[./-]\d{1,2}[./-]\d{2,4})[,\s]+(\d{1,2}:\d{2}(?::\d{2})?)\]?(?:\s*-\s*|\s+))([^:]+):\s*([\s\S]*)$/;
        let currentMsg = null;

        for (const line of lines) {
            const m = line.match(waLineRegex);
            if (m) {
                if (currentMsg && currentMsg.text.trim().length > 5) {
                    articles.push(currentMsg);
                }
                currentMsg = {
                    author: m[3].trim() || channelName,
                    dateStr: `${m[1]} ${m[2]}`,
                    text: m[4]
                };
            } else if (currentMsg) {
                currentMsg.text += '\n' + line;
            }
        }
        if (currentMsg && currentMsg.text.trim().length > 5) {
            articles.push(currentMsg);
        }

        // Pattern 2: If not timestamped log, split by double-newlines or "---" blocks
        if (articles.length === 0) {
            const blocks = rawText.split(/\n\s*(?:---+|\n\s*\n)\s*\n/).map(b => b.trim()).filter(b => b.length > 10);
            if (blocks.length === 0 && rawText.trim().length > 0) {
                blocks.push(rawText.trim());
            }
            blocks.forEach((b, i) => {
                articles.push({
                    author: channelName,
                    dateStr: '',
                    text: b
                });
            });
        }

        return articles.map((item, idx) => {
            const cleanText = item.text.trim();
            const firstLine = cleanText.split('\n')[0].trim();
            const title = firstLine.length > 85 ? firstLine.substring(0, 82) + '...' : (firstLine || `${item.author} Paylaşımı`);
            const urlMatch = cleanText.match(/https?:\/\/[^\s)]+/i);
            const link = urlMatch ? urlMatch[0] : `https://www.whatsapp.com/channels`;
            const guid = `wa_export_${this.hashString(cleanText)}_${idx}`;

            return {
                id: this.hashString(guid),
                guid: guid,
                feedId: 'saved_items',
                title: title,
                link: link,
                domain: 'whatsapp.com',
                author: item.author || channelName,
                pubDate: new Date(now - idx * 30000).toISOString(),
                timestamp: now - idx * 30000,
                summary: this.createSummary(cleanText),
                content: this.formatPlainTextAsHtml(cleanText),
                fullContent: this.formatPlainTextAsHtml(cleanText),
                thumbnail: '',
                readingTimeMin: this.estimateReadingTime(cleanText),
                customTag: 'WhatsApp',
                unread: true,
                starred: true,
                isVideo: false,
                videoId: null,
                isPodcast: false,
                audioUrl: null,
                audioType: null,
                audioDuration: null,
                mediaType: 'article'
            };
        });
    }

    static extractFromDocument(doc, feedUrl) {
        const entries = doc.getElementsByTagName('entry');
        const items = doc.getElementsByTagName('item');

        if (entries.length > 0) {
            return this.parseAtom(doc, feedUrl, entries);
        } else if (items.length > 0) {
            return this.parseRss(doc, feedUrl, items);
        } else {
            const feedTag = doc.getElementsByTagName('feed')[0];
            if (feedTag) {
                return this.parseAtom(doc, feedUrl, entries);
            }
            return this.parseRss(doc, feedUrl, items);
        }
    }

    static parseRss(doc, feedUrl, itemNodes) {
        const channels = doc.getElementsByTagName('channel');
        const channel = channels.length > 0 ? channels[0] : doc;

        const feedTitle = this.getNodeText(channel, 'title') || 'İsimsiz Kaynak';
        const feedLink = this.getNodeText(channel, 'link') || feedUrl;
        const feedDesc = this.getNodeText(channel, 'description') || '';

        let feedIcon = '';
        const chItunesImg = this.getFirstElement(channel, 'itunes:image');
        if (chItunesImg && chItunesImg.getAttribute('href')) {
            feedIcon = chItunesImg.getAttribute('href');
        } else {
            const chImg = this.getFirstElement(channel, 'image');
            if (chImg) {
                feedIcon = this.getNodeText(chImg, 'url') || '';
            }
        }

        const articles = [];
        const count = itemNodes.length;

        for (let i = 0; i < count; i++) {
            const node = itemNodes[i];
            const title = this.getNodeText(node, 'title') || 'Başlıksız';
            const link = this.getNodeText(node, 'link') || '';
            const guid = this.getNodeText(node, 'guid') || link || `${feedUrl}_${i}`;
            const author = this.getNodeText(node, 'author', 'dc:creator', 'creator', 'itunes:author') || '';

            const pubDateStr = this.getNodeText(node, 'pubDate', 'dc:date', 'date', 'pubdate') || '';
            const pubDate = this.parseDate(pubDateStr);

            const encoded = this.getNodeText(node, 'content:encoded', 'encoded');
            const description = this.getNodeText(node, 'description', 'itunes:summary') || '';
            const rawContent = encoded || description;

            let audioUrl = '';
            let audioType = '';
            const enclosures = node.getElementsByTagName('enclosure');
            for (let j = 0; j < enclosures.length; j++) {
                const enc = enclosures[j];
                const type = (enc.getAttribute('type') || '').toLowerCase();
                const url = enc.getAttribute('url') || '';
                if (type.startsWith('audio/') || url.match(/\.(mp3|m4a|aac|ogg|wav|opus)(\?.*)?$/i)) {
                    audioUrl = url;
                    audioType = type || 'audio/mpeg';
                    break;
                }
            }

            if (!audioUrl) {
                const mediaContents = node.getElementsByTagName('media:content');
                for (let j = 0; j < mediaContents.length; j++) {
                    const mc = mediaContents[j];
                    const type = (mc.getAttribute('type') || '').toLowerCase();
                    const url = mc.getAttribute('url') || '';
                    if (type.startsWith('audio/') || url.match(/\.(mp3|m4a|aac|ogg|wav|opus)(\?.*)?$/i)) {
                        audioUrl = url;
                        audioType = type || 'audio/mpeg';
                        break;
                    }
                }
            }

            let audioDuration = this.getNodeText(node, 'itunes:duration', 'duration') || '';
            audioDuration = this.formatDuration(audioDuration);

            let videoId = this.getNodeText(node, 'yt:videoId', 'videoId');
            if (!videoId && link) {
                videoId = this.extractYoutubeVideoId(link);
            }
            if (!videoId && rawContent) {
                videoId = this.extractYoutubeVideoId(rawContent);
            }

            let thumbnail = this.extractBestMediaImage(node);

            if (!thumbnail) {
                const itunesImg = this.getFirstElement(node, 'itunes:image');
                if (itunesImg && itunesImg.getAttribute('href')) {
                    thumbnail = itunesImg.getAttribute('href');
                }
            }

            if (!thumbnail && enclosures.length > 0) {
                for (let j = 0; j < enclosures.length; j++) {
                    const enc = enclosures[j];
                    const type = (enc.getAttribute('type') || '').toLowerCase();
                    if (type.startsWith('image/')) {
                        thumbnail = enc.getAttribute('url');
                        break;
                    }
                }
            }

            if (videoId) {
                thumbnail = `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`;
            }

            if (!thumbnail && rawContent) {
                thumbnail = this.extractFirstImage(rawContent);
            }

            if (!thumbnail && feedIcon) {
                thumbnail = feedIcon;
            }

            thumbnail = this.upgradeImageResolution(thumbnail);

            const cleanContent = this.sanitizeHtml(rawContent);
            const summary = this.createSummary(description || encoded || title);
            const readingTimeMin = this.estimateReadingTime(cleanContent || summary);
            const domain = this.extractDomain(link || feedLink);

            articles.push({
                id: this.hashString(guid),
                guid: guid,
                title: title.trim(),
                link: link.trim(),
                domain: domain,
                author: author.trim(),
                pubDate: pubDate.toISOString(),
                timestamp: pubDate.getTime(),
                summary: summary,
                content: cleanContent,
                thumbnail: thumbnail,
                readingTimeMin: readingTimeMin,
                unread: true,
                starred: false,
                isVideo: Boolean(videoId),
                videoId: videoId || null,
                isPodcast: Boolean(audioUrl),
                audioUrl: audioUrl || null,
                audioType: audioType || null,
                audioDuration: audioDuration || null,
                mediaType: videoId ? 'video' : (audioUrl ? 'podcast' : 'article')
            });
        }

        return {
            title: feedTitle.trim(),
            link: feedLink.trim(),
            description: feedDesc.trim(),
            icon: feedIcon || null,
            items: articles
        };
    }

    static parseAtom(doc, feedUrl, entryNodes) {
        const feedNode = doc.getElementsByTagName('feed')[0] || doc;
        const feedTitle = this.getNodeText(feedNode, 'title') || 'İsimsiz Kaynak';

        let feedLink = feedUrl;
        const links = feedNode.getElementsByTagName('link');
        for (let i = 0; i < links.length; i++) {
            const rel = links[i].getAttribute('rel');
            if (rel === 'alternate' || !rel) {
                feedLink = links[i].getAttribute('href') || feedLink;
                break;
            }
        }

        let feedIcon = this.getNodeText(feedNode, 'icon', 'logo') || '';

        const articles = [];
        const count = entryNodes.length;

        for (let i = 0; i < count; i++) {
            const node = entryNodes[i];
            const title = this.getNodeText(node, 'title') || 'Başlıksız';

            let link = '';
            let audioUrl = '';
            let audioType = '';
            const itemLinks = node.getElementsByTagName('link');
            for (let j = 0; j < itemLinks.length; j++) {
                const rel = itemLinks[j].getAttribute('rel');
                const href = itemLinks[j].getAttribute('href') || '';
                const type = (itemLinks[j].getAttribute('type') || '').toLowerCase();

                if (rel === 'alternate' || (!rel && !link)) {
                    link = href || link;
                }
                if (rel === 'enclosure' && (type.startsWith('audio/') || href.match(/\.(mp3|m4a|aac|ogg|wav|opus)(\?.*)?$/i))) {
                    audioUrl = href;
                    audioType = type || 'audio/mpeg';
                }
            }

            const guid = this.getNodeText(node, 'id') || link || `${feedUrl}_${i}`;
            const author = this.getNodeText(node, 'name', 'author', 'itunes:author') || '';

            const pubDateStr = this.getNodeText(node, 'published', 'updated') || '';
            const pubDate = this.parseDate(pubDateStr);

            const mediaDesc = this.getNodeText(node, 'media:description', 'description');
            const content = this.getNodeText(node, 'content') || '';
            const summaryNode = this.getNodeText(node, 'summary', 'itunes:summary') || '';
            const rawContent = content || this.formatPlainTextAsHtml(mediaDesc) || summaryNode;

            let videoId = this.getNodeText(node, 'yt:videoId', 'videoId');
            if (!videoId && guid && guid.includes('yt:video:')) {
                videoId = guid.split('yt:video:')[1].trim();
            }
            if (!videoId && link) {
                videoId = this.extractYoutubeVideoId(link);
            }

            if (videoId && !link) {
                link = `https://www.youtube.com/watch?v=${videoId}`;
            }

            let audioDuration = this.getNodeText(node, 'itunes:duration', 'duration') || '';
            audioDuration = this.formatDuration(audioDuration);

            let thumbnail = '';
            if (videoId) {
                thumbnail = `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`;
            }
            if (!thumbnail) {
                thumbnail = this.extractBestMediaImage(node);
            }
            if (!thumbnail && rawContent) {
                thumbnail = this.extractFirstImage(rawContent);
            }
            if (!thumbnail && feedIcon) {
                thumbnail = feedIcon;
            }
            thumbnail = this.upgradeImageResolution(thumbnail);

            const cleanContent = this.sanitizeHtml(rawContent);
            const summary = this.createSummary(mediaDesc || summaryNode || content || title);
            const readingTimeMin = this.estimateReadingTime(cleanContent || summary);
            const domain = this.extractDomain(link || feedLink);

            articles.push({
                id: this.hashString(guid),
                guid: guid,
                title: title.trim(),
                link: link.trim(),
                domain: domain,
                author: author.trim(),
                pubDate: pubDate.toISOString(),
                timestamp: pubDate.getTime(),
                summary: summary,
                content: cleanContent,
                thumbnail: thumbnail,
                readingTimeMin: readingTimeMin,
                unread: true,
                starred: false,
                isVideo: Boolean(videoId),
                videoId: videoId || null,
                isPodcast: Boolean(audioUrl),
                audioUrl: audioUrl || null,
                audioType: audioType || null,
                audioDuration: audioDuration || null,
                mediaType: videoId ? 'video' : (audioUrl ? 'podcast' : 'article')
            });
        }

        return {
            title: feedTitle.trim(),
            link: feedLink.trim(),
            description: '',
            icon: feedIcon || null,
            items: articles
        };
    }

    static extractYoutubeVideoId(str) {
        if (!str) return null;
        const m = str.match(/(?:youtube\.com\/(?:watch\?.*v=|embed\/|shorts\/|v\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/i);
        return m ? m[1] : null;
    }

    static formatPlainTextAsHtml(text) {
        if (!text) return '';
        if (/<[a-z][\s\S]*>/i.test(text)) return text;
        return text
            .split(/\n\s*\n/)
            .map(p => `<p>${p.trim().replace(/\n/g, '<br>')}</p>`)
            .join('');
    }

    static stripHtmlFast(htmlOrText) {
        if (!htmlOrText) return '';
        return this.decodeEntities(htmlOrText.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim());
    }

    static decodeEntities(str) {
        if (!str || !str.includes('&')) return str || '';
        return str
            .replace(/&amp;/gi, '&')
            .replace(/&lt;/gi, '<')
            .replace(/&gt;/gi, '>')
            .replace(/&quot;/gi, '"')
            .replace(/&#0*39;|&apos;/gi, "'")
            .replace(/&nbsp;/gi, ' ')
            .replace(/&#x([0-9a-f]+);/gi, (_, hex) => String.fromCharCode(parseInt(hex, 16)))
            .replace(/&#(\d+);/g, (_, dec) => String.fromCharCode(parseInt(dec, 10)));
    }

    static estimateReadingTime(htmlOrText) {
        if (!htmlOrText) return 1;
        const text = this.stripHtmlFast(htmlOrText);
        const words = text ? text.split(/\s+/).length : 0;
        return Math.max(1, Math.round(words / 200));
    }

    static extractDomain(urlStr) {
        if (!urlStr) return '';
        try {
            const u = new URL(urlStr);
            return u.hostname.replace(/^www\./i, '');
        } catch (e) {
            return '';
        }
    }

    static getNodeText(parent, ...tagNames) {
        if (!parent) return '';
        for (const tag of tagNames) {
            let els = parent.getElementsByTagName(tag);
            if (els && els.length > 0 && els[0].textContent) {
                return els[0].textContent;
            }
            if (tag.includes(':')) {
                const local = tag.split(':')[1];
                els = parent.getElementsByTagName(local);
                if (els && els.length > 0 && els[0].textContent) {
                    return els[0].textContent;
                }
            }
        }
        return '';
    }

    static getFirstElement(parent, ...tagNames) {
        if (!parent) return null;
        for (const tag of tagNames) {
            let els = parent.getElementsByTagName(tag);
            if (els && els.length > 0) return els[0];
            if (tag.includes(':')) {
                const local = tag.split(':')[1];
                els = parent.getElementsByTagName(local);
                if (els && els.length > 0) return els[0];
            }
        }
        return null;
    }

    static extractBestMediaImage(node) {
        if (!node) return '';
        let bestUrl = '';
        let bestWidth = -1;

        const candidates = [];
        const tags = ['media:content', 'content', 'media:thumbnail', 'thumbnail'];
        for (const t of tags) {
            const list = node.getElementsByTagName(t);
            for (let i = 0; i < list.length; i++) {
                candidates.push(list[i]);
            }
        }

        for (const el of candidates) {
            const url = el.getAttribute('url') || '';
            if (!url) continue;
            const type = (el.getAttribute('type') || '').toLowerCase();
            const medium = (el.getAttribute('medium') || '').toLowerCase();
            if (type.startsWith('audio/') || type.startsWith('video/') || medium === 'video' || medium === 'audio') {
                continue;
            }
            const w = parseInt(el.getAttribute('width') || '0', 10) || 0;
            if (w > bestWidth) {
                bestWidth = w;
                bestUrl = url;
            } else if (!bestUrl) {
                bestUrl = url;
            }
        }
        return bestUrl;
    }

    static upgradeImageResolution(url) {
        if (!url) return '';
        let res = this.decodeEntities(url.trim());
        // Upgrade tiny WordPress / Gravatar / CDN resize parameters (?w=150 -> ?w=800)
        res = res.replace(/([?&](?:w|width)=)(?:[1-9]\d|[1-3]\d\d)\b/gi, '$1800');
        res = res.replace(/([?&](?:h|height)=)(?:[1-9]\d|[1-3]\d\d)\b/gi, '$1600');
        res = res.replace(/-150x150\.(jpg|jpeg|png|webp)/i, '.$1');
        return res;
    }

    static extractFirstImage(html) {
        if (!html) return '';
        const match = html.match(/<img[^>]+src=["']([^"']+)["']/i);
        if (match && match[1]) {
            const url = match[1];
            if (!url.includes('spacer') && !url.includes('feedburner') && !url.includes('beacon') && !url.endsWith('.gif')) {
                return url;
            }
        }
        return '';
    }

    static sanitizeHtml(html) {
        if (!html) return '';
        let clean = html.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '');
        clean = clean.replace(/<object\b[^<]*(?:(?!<\/object>)<[^<]*)*<\/object>/gi, '');
        clean = clean.replace(/\son\w+="[^"]*"/gi, '');
        clean = clean.replace(/\son\w+='[^']*'/gi, '');
        clean = clean.replace(/javascript:/gi, '#');
        return clean;
    }

    static createSummary(htmlOrText) {
        if (!htmlOrText) return '';
        const text = this.stripHtmlFast(htmlOrText);
        return text.substring(0, 180);
    }

    static parseDate(dateStr) {
        if (!dateStr) return new Date();
        const d = new Date(dateStr);
        return isNaN(d.getTime()) ? new Date() : d;
    }

    static formatDuration(durationStr) {
        if (!durationStr) return '';
        durationStr = durationStr.trim();
        if (/^\d+$/.test(durationStr)) {
            const sec = parseInt(durationStr, 10);
            const h = Math.floor(sec / 3600);
            const m = Math.floor((sec % 3600) / 60);
            const s = sec % 60;
            return (h > 0 ? h + ':' : '') + (m < 10 && h > 0 ? '0' : '') + m + ':' + (s < 10 ? '0' : '') + s;
        }
        return durationStr;
    }

    static formatRelativeTime(timestamp) {
        const now = Date.now();
        const diffMs = now - timestamp;
        const diffSec = Math.floor(diffMs / 1000);
        const diffMin = Math.floor(diffSec / 60);
        const diffHour = Math.floor(diffMin / 60);
        const diffDay = Math.floor(diffHour / 24);

        if (diffSec < 60) return 'şimdi';
        if (diffMin < 60) return `${diffMin}d`;
        if (diffHour < 24) return `${diffHour}s`;
        if (diffDay === 1) return 'dün';
        if (diffDay < 7) return `${diffDay}g`;

        const d = new Date(timestamp);
        return `${d.getDate()} ${this.getMonthName(d.getMonth())}`;
    }

    static getMonthName(m) {
        const months = ['Oca', 'Şub', 'Mar', 'Nis', 'May', 'Haz', 'Tem', 'Ağu', 'Eyl', 'Eki', 'Kas', 'Ara'];
        return months[m] || '';
    }

    static hashString(str) {
        let hash = 0;
        for (let i = 0; i < str.length; i++) {
            const char = str.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash |= 0;
        }
        return 'art_' + Math.abs(hash).toString(36);
    }
}
