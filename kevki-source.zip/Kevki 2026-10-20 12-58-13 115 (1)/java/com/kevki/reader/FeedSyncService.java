package com.kevki.reader;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.util.Xml;
import com.kevki.reader.NetworkHelper;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONArray;
import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParser;

public class FeedSyncService extends Service {
    public static final String CHANNEL_HIGH_ID = "kevki_instant_push_v3";
    public static final String CHANNEL_SILENT_ID = "kevki_bg_engine_silent";
    private static final long FAST_POLL_INTERVAL_MS = 12000;
    private static final int FOREGROUND_SERVICE_ID = 9901;
    public static final String PREFS_NAME = "kevki_bg_sync";
    private Handler handler;
    private Runnable pollRunnable;
    private static final ExecutorService pollExecutor = Executors.newFixedThreadPool(8);
    private static final AtomicBoolean isPolling = new AtomicBoolean(false);

    static Handler -$$Nest$fgethandler(FeedSyncService feedSyncService) {
        return feedSyncService.handler;
    }

    static AtomicBoolean -$$Nest$sfgetisPolling() {
        return isPolling;
    }

    static List -$$Nest$smparseQuickItems(String str, String str2) {
        return parseQuickItems(str, str2);
    }

    static void -$$Nest$smpollAllFeedsInternal(Context context) {
        pollAllFeedsInternal(context);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        ensureNotificationChannel(this);
        startSilentForeground();
        this.handler = new Handler(Looper.getMainLooper());
        1 r0 = new 1();
        this.pollRunnable = r0;
        this.handler.post(r0);
    }

    class 1 implements Runnable {
        1() {
        }

        @Override
        public void run() {
            FeedSyncService.triggerImmediatePoll(FeedSyncService.this.getApplicationContext());
            FeedSyncService.scheduleRestartAlarm(FeedSyncService.this.getApplicationContext(), FeedSyncService.FAST_POLL_INTERVAL_MS);
            if (FeedSyncService.-$$Nest$fgethandler(FeedSyncService.this) != null) {
                FeedSyncService.-$$Nest$fgethandler(FeedSyncService.this).postDelayed(this, FeedSyncService.FAST_POLL_INTERVAL_MS);
            }
        }
    }

    private void startSilentForeground() {
        Notification.Builder builder;
        int r2;
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                builder = new Notification.Builder(this, CHANNEL_SILENT_ID);
            } else {
                builder = new Notification.Builder(this);
                builder.setPriority(-2);
            }
            Intent intent = new Intent(this, (Class<?>) MainActivity.class);
            if (Build.VERSION.SDK_INT < 23) {
                r2 = 134217728;
            } else {
                r2 = 201326592;
            }
            builder.setContentTitle("Kevki").setContentText("Anlık bildirim senkronizasyonu aktif").setSmallIcon(R.mipmap.ic_launcher).setContentIntent(PendingIntent.getActivity(this, 0, intent, r2)).setOngoing(true);
            if (Build.VERSION.SDK_INT >= 21) {
                builder.setVisibility(-1);
            }
            startForeground(FOREGROUND_SERVICE_ID, builder.build());
        } catch (Exception e) {
        }
    }

    @Override
    public int onStartCommand(Intent intent, int r2, int r3) {
        startSilentForeground();
        triggerImmediatePoll(getApplicationContext());
        scheduleRestartAlarm(getApplicationContext(), FAST_POLL_INTERVAL_MS);
        return 1;
    }

    @Override
    public void onTaskRemoved(Intent intent) {
        scheduleRestartAlarm(getApplicationContext(), 2500L);
        super.onTaskRemoved(intent);
    }

    @Override
    public void onDestroy() {
        Runnable runnable;
        Handler handler = this.handler;
        if (handler != null && (runnable = this.pollRunnable) != null) {
            handler.removeCallbacks(runnable);
        }
        scheduleRestartAlarm(getApplicationContext(), 3000L);
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    public static void scheduleAlarmBackup(Context context) {
        scheduleRestartAlarm(context, FAST_POLL_INTERVAL_MS);
    }

    public static void scheduleRestartAlarm(Context context, long j) {
        int r2;
        try {
            AlarmManager alarmManager = (AlarmManager) context.getSystemService("alarm");
            if (alarmManager == null) {
                return;
            }
            Intent intent = new Intent(context, (Class<?>) BootReceiver.class);
            intent.setAction("com.kevki.reader.ACTION_POLL_FEEDS");
            if (Build.VERSION.SDK_INT < 23) {
                r2 = 134217728;
            } else {
                r2 = 201326592;
            }
            PendingIntent broadcast = PendingIntent.getBroadcast(context, 7701, intent, r2);
            long jElapsedRealtime = SystemClock.elapsedRealtime() + j;
            if (Build.VERSION.SDK_INT >= 23) {
                try {
                    alarmManager.setExactAndAllowWhileIdle(2, jElapsedRealtime, broadcast);
                } catch (Exception e) {
                    alarmManager.setAndAllowWhileIdle(2, jElapsedRealtime, broadcast);
                }
            } else {
                alarmManager.set(2, jElapsedRealtime, broadcast);
            }
        } catch (Exception e2) {
        }
    }

    public static void triggerImmediatePoll(Context context) {
        triggerImmediatePollWithFinish(context, null);
    }

    public static void triggerImmediatePollWithFinish(Context context, BroadcastReceiver.PendingResult pendingResult) {
        if (!isPolling.compareAndSet(false, true)) {
            if (pendingResult != null) {
                try {
                    pendingResult.finish();
                    return;
                } catch (Exception e) {
                    return;
                }
            }
            return;
        }
        pollExecutor.execute(new 2(context, pendingResult));
    }

    class 2 implements Runnable {
        final Context val$context;
        final BroadcastReceiver.PendingResult val$pendingResult;

        2(Context context, BroadcastReceiver.PendingResult pendingResult) {
            this.val$context = context;
            this.val$pendingResult = pendingResult;
        }

        @Override
        public void run() {
            PowerManager.WakeLock wakeLockNewWakeLock = null;
            try {
                PowerManager powerManager = (PowerManager) this.val$context.getSystemService("power");
                if (powerManager != null) {
                    wakeLockNewWakeLock = powerManager.newWakeLock(1, "kevki:bg_poll_lock");
                    wakeLockNewWakeLock.acquire(FeedSyncService.FAST_POLL_INTERVAL_MS);
                }
            } catch (Exception e) {
            }
            try {
                FeedSyncService.-$$Nest$smpollAllFeedsInternal(this.val$context);
            } finally {
                FeedSyncService.-$$Nest$sfgetisPolling().set(false);
                if (wakeLockNewWakeLock != null) {
                    try {
                        if (wakeLockNewWakeLock.isHeld()) {
                            wakeLockNewWakeLock.release();
                        }
                    } catch (Exception e2) {
                    }
                }
                BroadcastReceiver.PendingResult pendingResult = this.val$pendingResult;
                if (pendingResult != null) {
                    try {
                        pendingResult.finish();
                    } catch (Exception e3) {
                    }
                }
            }
        }
    }

    private static void pollAllFeedsInternal(Context context) {
        int r18;
        ArrayList arrayList;
        boolean[] zArr;
        boolean[] zArr2;
        try {
            SharedPreferences sharedPreferences = context.getSharedPreferences(PREFS_NAME, 0);
            boolean z = true;
            if (sharedPreferences.getBoolean("global_notify_enabled", true)) {
                JSONArray jSONArray = new JSONArray(sharedPreferences.getString("feeds_json", "[]"));
                if (jSONArray.length() == 0) {
                    return;
                }
                HashSet hashSet = new HashSet(sharedPreferences.getStringSet("seen_ids", new HashSet()));
                boolean[] zArr3 = {false};
                boolean[] zArr4 = {false};
                ArrayList arrayList2 = new ArrayList();
                int r8 = 0;
                while (r8 < jSONArray.length()) {
                    JSONObject jSONObjectOptJSONObject = jSONArray.optJSONObject(r8);
                    if (jSONObjectOptJSONObject == null) {
                        r18 = r8;
                        arrayList = arrayList2;
                        zArr = zArr4;
                        zArr2 = zArr3;
                    } else {
                        String strOptString = jSONObjectOptJSONObject.optString("id", "");
                        String strOptString2 = jSONObjectOptJSONObject.optString("title", "Kevki");
                        String strOptString3 = jSONObjectOptJSONObject.optString("url", "");
                        boolean zOptBoolean = jSONObjectOptJSONObject.optBoolean("notificationsEnabled", z);
                        if (strOptString.isEmpty() || strOptString3.isEmpty()) {
                            r18 = r8;
                            arrayList = arrayList2;
                            zArr = zArr4;
                            zArr2 = zArr3;
                        } else if (zOptBoolean) {
                            FutureTaskHolder futureTaskHolder = new FutureTaskHolder(null);
                            arrayList2.add(futureTaskHolder);
                            r18 = r8;
                            arrayList = arrayList2;
                            zArr = zArr4;
                            zArr2 = zArr3;
                            pollExecutor.execute(new 3(strOptString, sharedPreferences, strOptString3, hashSet, zArr3, zArr4, context, strOptString2, futureTaskHolder));
                        } else {
                            r18 = r8;
                            arrayList = arrayList2;
                            zArr = zArr4;
                            zArr2 = zArr3;
                        }
                    }
                    r8 = r18 + 1;
                    zArr3 = zArr2;
                    arrayList2 = arrayList;
                    zArr4 = zArr;
                    z = true;
                }
                boolean[] zArr5 = zArr4;
                boolean[] zArr6 = zArr3;
                Iterator it = arrayList2.iterator();
                while (it.hasNext()) {
                    ((FutureTaskHolder) it.next()).await(9000L);
                }
                if (zArr6[0]) {
                    synchronized (hashSet) {
                        if (hashSet.size() > 4000) {
                            ArrayList arrayList3 = new ArrayList(hashSet);
                            sharedPreferences.edit().putStringSet("seen_ids", new HashSet(arrayList3.subList(arrayList3.size() - 3000, arrayList3.size()))).apply();
                        } else {
                            sharedPreferences.edit().putStringSet("seen_ids", new HashSet(hashSet)).apply();
                        }
                    }
                }
                if (zArr5[0] && MainActivity.activeInstance != null) {
                    MainActivity.activeInstance.notifyWebViewNewItems();
                }
            }
        } catch (Exception e) {
        }
    }

    class 3 implements Runnable {
        final boolean[] val$anyNewFound;
        final Context val$context;
        final String val$feedId;
        final String val$feedTitle;
        final String val$feedUrl;
        final FutureTaskHolder val$holder;
        final SharedPreferences val$prefs;
        final boolean[] val$seenModified;
        final Set val$seenSet;

        3(String str, SharedPreferences sharedPreferences, String str2, Set set, boolean[] zArr, boolean[] zArr2, Context context, String str3, FutureTaskHolder futureTaskHolder) {
            this.val$feedId = str;
            this.val$prefs = sharedPreferences;
            this.val$feedUrl = str2;
            this.val$seenSet = set;
            this.val$seenModified = zArr;
            this.val$anyNewFound = zArr2;
            this.val$context = context;
            this.val$feedTitle = str3;
            this.val$holder = futureTaskHolder;
        }

        @Override
        public void run() {
            String str;
            try {
                String str2 = "etag_" + this.val$feedId;
                String str3 = "lastmod_" + this.val$feedId;
                String str4 = "init_" + this.val$feedId;
                String string = this.val$prefs.getString(str2, null);
                String string2 = this.val$prefs.getString(str3, null);
                boolean z = this.val$prefs.getBoolean(str4, false);
                NetworkHelper.FetchResult fetchResultFetchConditional = NetworkHelper.fetchConditional(this.val$feedUrl, string, string2, 6000, 8000);
                if (fetchResultFetchConditional.statusCode != 304) {
                    if (fetchResultFetchConditional.success && fetchResultFetchConditional.data != null && !fetchResultFetchConditional.data.isEmpty()) {
                        List<ParsedItem> list = FeedSyncService.-$$Nest$smparseQuickItems(fetchResultFetchConditional.data, this.val$feedUrl);
                        if (!list.isEmpty()) {
                            ArrayList arrayList = new ArrayList();
                            synchronized (this.val$seenSet) {
                                for (ParsedItem parsedItem : list) {
                                    if (!this.val$seenSet.contains(parsedItem.articleId)) {
                                        this.val$seenSet.add(parsedItem.articleId);
                                        this.val$seenModified[0] = true;
                                        if (z) {
                                            arrayList.add(parsedItem);
                                        }
                                    }
                                }
                            }
                            SharedPreferences.Editor editorEdit = this.val$prefs.edit();
                            if (fetchResultFetchConditional.etag != null) {
                                editorEdit.putString(str2, fetchResultFetchConditional.etag);
                            }
                            if (fetchResultFetchConditional.lastModified != null) {
                                editorEdit.putString(str3, fetchResultFetchConditional.lastModified);
                            }
                            if (!z) {
                                editorEdit.putBoolean(str4, true);
                            }
                            editorEdit.apply();
                            if (z && !arrayList.isEmpty()) {
                                this.val$anyNewFound[0] = true;
                                ParsedItem parsedItem2 = (ParsedItem) arrayList.get(0);
                                if (arrayList.size() == 1) {
                                    str = parsedItem2.title;
                                } else {
                                    str = "+" + arrayList.size() + " yeni yayın: " + parsedItem2.title;
                                }
                                FeedSyncService.sendInstantNotification(this.val$context, this.val$feedTitle, str, parsedItem2.articleId, Math.abs((this.val$feedId + "_" + parsedItem2.articleId).hashCode() % 900000) + 1000);
                            }
                        }
                    }
                } else {
                    this.val$holder.markDone();
                    return;
                }
            } catch (Exception e) {
            } catch (Throwable th) {
                this.val$holder.markDone();
                throw th;
            }
            this.val$holder.markDone();
        }
    }

    private static class FutureTaskHolder {
        private boolean done;

        FutureTaskHolder(FutureTaskHolder-IA r1) {
            this();
        }

        private FutureTaskHolder() {
            this.done = false;
        }

        synchronized void markDone() {
            this.done = true;
            notifyAll();
        }

        synchronized void await(long j) {
            if (!this.done) {
                try {
                    wait(j);
                } catch (InterruptedException e) {
                }
            }
        }
    }

    private static class ParsedItem {
        String articleId;
        String title;

        ParsedItem(String str, String str2) {
            this.articleId = str;
            this.title = str2;
        }
    }

    private static List parseQuickItems(String str, String str2) {
        String str3;
        String strTrim;
        ArrayList arrayList = new ArrayList();
        try {
            XmlPullParser xmlPullParserNewPullParser = Xml.newPullParser();
            xmlPullParserNewPullParser.setFeature("http://xmlpull.org/v1/doc/features.html#process-namespaces", false);
            xmlPullParserNewPullParser.setInput(new StringReader(str));
            String strSafeNextText = null;
            String str4 = null;
            String strSafeNextText2 = null;
            boolean z = false;
            int r7 = 0;
            for (int eventType = xmlPullParserNewPullParser.getEventType(); eventType != 1 && arrayList.size() < 25; eventType = xmlPullParserNewPullParser.next()) {
                if (eventType == 2) {
                    String name = xmlPullParserNewPullParser.getName();
                    if ("item".equalsIgnoreCase(name) || "entry".equalsIgnoreCase(name)) {
                        strSafeNextText = "";
                        str4 = strSafeNextText;
                        strSafeNextText2 = str4;
                        z = true;
                    } else if (z) {
                        if ("title".equalsIgnoreCase(name)) {
                            strSafeNextText2 = safeNextText(xmlPullParserNewPullParser);
                        } else if ("guid".equalsIgnoreCase(name) || "id".equalsIgnoreCase(name)) {
                            strSafeNextText = safeNextText(xmlPullParserNewPullParser);
                        } else if ("link".equalsIgnoreCase(name)) {
                            String attributeValue = xmlPullParserNewPullParser.getAttributeValue(null, "href");
                            String attributeValue2 = xmlPullParserNewPullParser.getAttributeValue(null, "rel");
                            if (attributeValue != null && !attributeValue.isEmpty()) {
                                if (str4.isEmpty() || "alternate".equalsIgnoreCase(attributeValue2)) {
                                    str4 = attributeValue;
                                }
                            } else {
                                String strSafeNextText3 = safeNextText(xmlPullParserNewPullParser);
                                if (!strSafeNextText3.isEmpty()) {
                                    str4 = strSafeNextText3;
                                }
                            }
                        }
                    }
                } else if (eventType == 3) {
                    String name2 = xmlPullParserNewPullParser.getName();
                    if (z && ("item".equalsIgnoreCase(name2) || "entry".equalsIgnoreCase(name2))) {
                        if (strSafeNextText != null && !strSafeNextText.isEmpty()) {
                            str3 = strSafeNextText;
                        } else {
                            str3 = (str4 == null || str4.isEmpty()) ? str2 + "_" + r7 : str4;
                        }
                        String strHashArticleId = hashArticleId(str3);
                        if (strSafeNextText2 != null && !strSafeNextText2.trim().isEmpty()) {
                            strTrim = strSafeNextText2.trim();
                        } else {
                            strTrim = "Yeni Yayın";
                        }
                        arrayList.add(new ParsedItem(strHashArticleId, strTrim));
                        r7++;
                        z = false;
                    }
                }
            }
        } catch (Exception e) {
        }
        return arrayList;
    }

    private static String safeNextText(XmlPullParser xmlPullParser) {
        try {
            String strNextText = xmlPullParser.nextText();
            return strNextText != null ? strNextText.trim() : "";
        } catch (Exception e) {
            return "";
        }
    }

    public static String hashArticleId(String str) {
        if (str == null) {
            str = "";
        }
        int r1 = 0;
        for (int r0 = 0; r0 < str.length(); r0++) {
            r1 = ((r1 << 5) - r1) + str.charAt(r0);
        }
        return "art_" + Long.toString(Math.abs(r1), 36);
    }

    public static void ensureNotificationChannel(Context context) {
        NotificationManager notificationManager;
        if (Build.VERSION.SDK_INT < 26 || (notificationManager = (NotificationManager) context.getSystemService("notification")) == null) {
            return;
        }
        NotificationChannel notificationChannel = new NotificationChannel(CHANNEL_HIGH_ID, "Kevki Anlık Bildirimler", 4);
        notificationChannel.setDescription("Twitter/Instagram hızında anlık yeni yayın bildirimleri");
        notificationChannel.enableVibration(true);
        notificationChannel.enableLights(true);
        notificationChannel.setShowBadge(true);
        notificationManager.createNotificationChannel(notificationChannel);
        NotificationChannel notificationChannel2 = new NotificationChannel(CHANNEL_SILENT_ID, "Kevki Arka Plan Senkronizasyonu", 1);
        notificationChannel2.setDescription("Arka plan bildirim dinleyicisi");
        notificationChannel2.enableVibration(false);
        notificationChannel2.enableLights(false);
        notificationChannel2.setShowBadge(false);
        notificationManager.createNotificationChannel(notificationChannel2);
    }

    public static void sendInstantNotification(Context context, String str, String str2, String str3, int r9) {
        Notification.Builder builder;
        int r8;
        try {
            NotificationManager notificationManager = (NotificationManager) context.getSystemService("notification");
            if (notificationManager == null) {
                return;
            }
            ensureNotificationChannel(context);
            if (Build.VERSION.SDK_INT >= 26) {
                builder = new Notification.Builder(context, CHANNEL_HIGH_ID);
            } else {
                builder = new Notification.Builder(context);
                builder.setPriority(1);
                builder.setDefaults(-1);
            }
            Intent intent = new Intent(context, (Class<?>) MainActivity.class);
            intent.setFlags(872415232);
            if (str3 != null && !str3.isEmpty()) {
                intent.putExtra("articleId", str3);
            }
            if (Build.VERSION.SDK_INT < 23) {
                r8 = 134217728;
            } else {
                r8 = 201326592;
            }
            builder.setContentTitle(str).setContentText(str2).setStyle(new Notification.BigTextStyle().bigText(str2)).setSmallIcon(R.mipmap.ic_launcher).setContentIntent(PendingIntent.getActivity(context, r9, intent, r8)).setAutoCancel(true);
            if (Build.VERSION.SDK_INT >= 21) {
                builder.setCategory("social");
                builder.setVisibility(1);
                builder.setColor(-3364255);
            }
            notificationManager.notify(r9, builder.build());
        } catch (Exception e) {
        }
    }
}
