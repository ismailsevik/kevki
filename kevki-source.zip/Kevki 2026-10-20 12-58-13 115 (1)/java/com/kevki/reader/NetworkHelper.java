package com.kevki.reader;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.zip.GZIPInputStream;
import org.json.JSONArray;
import org.json.JSONObject;

public class NetworkHelper {
    static {
        System.setProperty("http.keepAlive", "true");
        System.setProperty("http.maxConnections", "16");
    }

    public static class FetchResult {
        public String data;
        public String errorMessage;
        public String etag;
        public String lastModified;
        public int statusCode;
        public boolean success;

        public FetchResult(boolean z, int r9, String str, String str2) {
            this(z, r9, str, str2, null, null);
        }

        public FetchResult(boolean z, int r2, String str, String str2, String str3, String str4) {
            this.success = z;
            this.statusCode = r2;
            this.data = str;
            this.errorMessage = str2;
            this.etag = str3;
            this.lastModified = str4;
        }
    }

    public static FetchResult fetch(String str) {
        return fetchConditional(str, null, null, 9000, 12000);
    }

    public static FetchResult fetchConditional(String str, String str2, String str3, int r27, int r28) throws Throwable {
        Throwable th;
        HttpURLConnection httpURLConnection;
        HttpURLConnection httpURLConnection2;
        HttpURLConnection httpURLConnection3;
        boolean z;
        boolean z2;
        boolean z3;
        String str4;
        String str5;
        String str6;
        int responseCode;
        URL url;
        int r11;
        String headerField;
        HttpURLConnection httpURLConnection4;
        String str7;
        String str8;
        String headerField2;
        String headerField3;
        InputStream errorStream;
        String contentType;
        String strReplace;
        BufferedReader bufferedReader;
        StringBuilder sb;
        char[] cArr;
        int r5;
        String str9 = str;
        try {
            try {
                if (str9 != null) {
                    try {
                        z = str9.contains("whatsapp.com/channel/") || str9.contains("wa.me/channel/");
                        if (z && !str9.contains("_fb_noscript=1")) {
                            str9 = str9 + (str9.contains("?") ? "&_fb_noscript=1" : "?_fb_noscript=1");
                        }
                        URL url2 = new URL(str9);
                        httpURLConnection3 = (HttpURLConnection) url2.openConnection();
                        httpURLConnection3.setRequestMethod("GET");
                        httpURLConnection3.setConnectTimeout(r27);
                        httpURLConnection3.setReadTimeout(r28);
                        httpURLConnection3.setInstanceFollowRedirects(true);
                        z2 = !str9.contains("youtube.com") || str9.contains("youtu.be");
                        z3 = !str9.contains("reddit.com") || str9.contains("redd.it");
                        str4 = "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36 Kevki/4.0";
                        str5 = "facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)";
                        str6 = "GET";
                        if (z) {
                            httpURLConnection3.setRequestProperty("User-Agent", "facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)");
                            httpURLConnection3.setRequestProperty("Accept-Language", "tr-TR,tr;q=0.9,en-US;q=0.8");
                        } else if (z3) {
                            httpURLConnection3.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36 KevkiReader/4.0");
                            httpURLConnection3.setRequestProperty("Accept-Language", "tr-TR,tr;q=0.9,en-US;q=0.8");
                        } else if (z2 || str9.contains("/feeds/videos.xml")) {
                            httpURLConnection3.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36 Kevki/4.0");
                        } else {
                            httpURLConnection3.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36");
                            httpURLConnection3.setRequestProperty("Cookie", "CONSENT=YES+cb.20210328-17-p0.en+FX+410; SOCS=CAISHAgBEhJnd3NfMjAyMzA4MTAtMF9SQzIaAmVuIAEaBgiAo_CmBg");
                            httpURLConnection3.setRequestProperty("Accept-Language", "tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7");
                        }
                        httpURLConnection3.setRequestProperty("Accept", "application/rss+xml, application/atom+xml, application/xml, text/xml, text/html, application/json, */*");
                        httpURLConnection3.setRequestProperty("Accept-Encoding", "gzip, deflate");
                        if (str2 != null && !str2.isEmpty()) {
                            httpURLConnection3.setRequestProperty("If-None-Match", str2);
                        }
                        if (str3 != null && !str3.isEmpty()) {
                            httpURLConnection3.setRequestProperty("If-Modified-Since", str3);
                        }
                        responseCode = httpURLConnection3.getResponseCode();
                        url = url2;
                        r11 = 0;
                        while (true) {
                            if ((responseCode == 301 && responseCode != 302 && responseCode != 303 && responseCode != 307 && responseCode != 308) || r11 >= 5 || (headerField = httpURLConnection3.getHeaderField("Location")) == null) {
                                break;
                                break;
                                break;
                            }
                            httpURLConnection3.disconnect();
                            URL url3 = new URL(url, headerField);
                            httpURLConnection4 = (HttpURLConnection) url3.openConnection();
                            String str10 = str6;
                            try {
                                httpURLConnection4.setRequestMethod(str10);
                                str7 = str5;
                                httpURLConnection4.setConnectTimeout(r27);
                                str6 = str10;
                                str8 = str4;
                                httpURLConnection4.setReadTimeout(r28);
                                if (z) {
                                    httpURLConnection4.setRequestProperty("User-Agent", str7);
                                } else {
                                    httpURLConnection4.setRequestProperty("User-Agent", str8);
                                }
                                httpURLConnection4.setRequestProperty("Accept", "application/rss+xml, application/atom+xml, application/xml, text/xml, text/html, */*");
                                httpURLConnection4.setRequestProperty("Accept-Encoding", "gzip, deflate");
                                if (z2) {
                                    httpURLConnection4.setRequestProperty("Cookie", "CONSENT=YES+cb.20210328-17-p0.en+FX+410; SOCS=CAISHAgBEhJnd3NfMjAyMzA4MTAtMF9SQzIaAmVuIAEaBgiAo_CmBg");
                                }
                                int responseCode2 = httpURLConnection4.getResponseCode();
                                r11++;
                                str5 = str7;
                                str4 = str8;
                                httpURLConnection3 = httpURLConnection4;
                                url = url3;
                                responseCode = responseCode2;
                            } catch (Exception e) {
                                e = e;
                                httpURLConnection3 = httpURLConnection4;
                                FetchResult fetchResult = new FetchResult(false, 0, null, e.getMessage() != null ? e.getMessage() : e.toString());
                                if (httpURLConnection3 != null) {
                                    try {
                                        httpURLConnection3.disconnect();
                                    } catch (Exception e2) {
                                    }
                                }
                                return fetchResult;
                            } catch (Throwable th2) {
                                th = th2;
                                httpURLConnection2 = httpURLConnection4;
                                if (httpURLConnection2 != null) {
                                    throw th;
                                }
                                try {
                                    httpURLConnection2.disconnect();
                                    throw th;
                                } catch (Exception e3) {
                                    throw th;
                                }
                            }
                        }
                        headerField2 = httpURLConnection3.getHeaderField("ETag");
                        headerField3 = httpURLConnection3.getHeaderField("Last-Modified");
                        if (responseCode == 304) {
                            FetchResult fetchResult2 = new FetchResult(true, 304, "", null, headerField2 != null ? headerField2 : str2, headerField3 != null ? headerField3 : str3);
                            if (httpURLConnection3 != null) {
                                try {
                                    httpURLConnection3.disconnect();
                                } catch (Exception e4) {
                                }
                            }
                            return fetchResult2;
                        }
                        if (responseCode >= 200 || responseCode >= 300) {
                            errorStream = httpURLConnection3.getErrorStream();
                            if (errorStream == null) {
                                FetchResult fetchResult3 = new FetchResult(false, responseCode, "", "HTTP Error: " + responseCode);
                                if (httpURLConnection3 != null) {
                                    try {
                                        httpURLConnection3.disconnect();
                                    } catch (Exception e5) {
                                    }
                                }
                                return fetchResult3;
                            }
                        } else {
                            errorStream = httpURLConnection3.getInputStream();
                        }
                        if ("gzip".equalsIgnoreCase(httpURLConnection3.getContentEncoding())) {
                            errorStream = new GZIPInputStream(errorStream);
                        }
                        contentType = httpURLConnection3.getContentType();
                        strReplace = "UTF-8";
                        if (contentType == null && contentType.toLowerCase().contains("charset=")) {
                            String[] strArrSplit = contentType.split("(?i)charset=");
                            if (strArrSplit.length > 1) {
                                strReplace = strArrSplit[1].split(";")[0].trim().replace("\"", "").replace("'", "");
                            }
                        }
                        try {
                            bufferedReader = new BufferedReader(new InputStreamReader(errorStream, strReplace), 16384);
                        } catch (Exception e6) {
                            bufferedReader = new BufferedReader(new InputStreamReader(errorStream, StandardCharsets.UTF_8), 16384);
                        }
                        sb = new StringBuilder(16384);
                        cArr = new char[8192];
                        while (true) {
                            r5 = bufferedReader.read(cArr);
                            if (r5 != -1) {
                                break;
                            }
                            sb.append(cArr, 0, r5);
                        }
                        bufferedReader.close();
                        boolean z4 = responseCode < 200 && responseCode < 300;
                        FetchResult fetchResult4 = new FetchResult(z4, responseCode, sb.toString(), z4 ? null : "HTTP Error " + responseCode, headerField2, headerField3);
                        if (httpURLConnection3 != null) {
                            try {
                                httpURLConnection3.disconnect();
                            } catch (Exception e7) {
                            }
                        }
                        return fetchResult4;
                    } catch (Exception e8) {
                        e = e8;
                        httpURLConnection3 = null;
                        FetchResult fetchResult5 = new FetchResult(false, 0, null, e.getMessage() != null ? e.getMessage() : e.toString());
                        if (httpURLConnection3 != null) {
                            httpURLConnection3.disconnect();
                        }
                        return fetchResult5;
                    } catch (Throwable th3) {
                        th = th3;
                        httpURLConnection2 = null;
                        if (httpURLConnection2 != null) {
                            throw th;
                        }
                        httpURLConnection2.disconnect();
                        throw th;
                    }
                }
                httpURLConnection3.setRequestMethod("GET");
                httpURLConnection3.setConnectTimeout(r27);
                httpURLConnection3.setReadTimeout(r28);
                httpURLConnection3.setInstanceFollowRedirects(true);
                if (str9.contains("youtube.com")) {
                }
                if (str9.contains("reddit.com")) {
                }
                str4 = "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36 Kevki/4.0";
                str5 = "facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)";
                str6 = "GET";
                if (z) {
                    httpURLConnection3.setRequestProperty("User-Agent", "facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)");
                    httpURLConnection3.setRequestProperty("Accept-Language", "tr-TR,tr;q=0.9,en-US;q=0.8");
                } else if (z3) {
                    httpURLConnection3.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36 KevkiReader/4.0");
                    httpURLConnection3.setRequestProperty("Accept-Language", "tr-TR,tr;q=0.9,en-US;q=0.8");
                } else if (z2) {
                    httpURLConnection3.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36 Kevki/4.0");
                } else {
                    httpURLConnection3.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36 Kevki/4.0");
                }
                httpURLConnection3.setRequestProperty("Accept", "application/rss+xml, application/atom+xml, application/xml, text/xml, text/html, application/json, */*");
                httpURLConnection3.setRequestProperty("Accept-Encoding", "gzip, deflate");
                if (str2 != null) {
                    httpURLConnection3.setRequestProperty("If-None-Match", str2);
                }
                if (str3 != null) {
                    httpURLConnection3.setRequestProperty("If-Modified-Since", str3);
                }
                responseCode = httpURLConnection3.getResponseCode();
                url = url2;
                r11 = 0;
                while (true) {
                    if (responseCode == 301) {
                        httpURLConnection3.disconnect();
                        URL url32 = new URL(url, headerField);
                        httpURLConnection4 = (HttpURLConnection) url32.openConnection();
                        String str102 = str6;
                        httpURLConnection4.setRequestMethod(str102);
                        str7 = str5;
                        httpURLConnection4.setConnectTimeout(r27);
                        str6 = str102;
                        str8 = str4;
                        httpURLConnection4.setReadTimeout(r28);
                        if (z) {
                            httpURLConnection4.setRequestProperty("User-Agent", str7);
                        } else {
                            httpURLConnection4.setRequestProperty("User-Agent", str8);
                        }
                        httpURLConnection4.setRequestProperty("Accept", "application/rss+xml, application/atom+xml, application/xml, text/xml, text/html, */*");
                        httpURLConnection4.setRequestProperty("Accept-Encoding", "gzip, deflate");
                        if (z2) {
                            httpURLConnection4.setRequestProperty("Cookie", "CONSENT=YES+cb.20210328-17-p0.en+FX+410; SOCS=CAISHAgBEhJnd3NfMjAyMzA4MTAtMF9SQzIaAmVuIAEaBgiAo_CmBg");
                        }
                        int responseCode22 = httpURLConnection4.getResponseCode();
                        r11++;
                        str5 = str7;
                        str4 = str8;
                        httpURLConnection3 = httpURLConnection4;
                        url = url32;
                        responseCode = responseCode22;
                    } else {
                        httpURLConnection3.disconnect();
                        URL url322 = new URL(url, headerField);
                        httpURLConnection4 = (HttpURLConnection) url322.openConnection();
                        String str1022 = str6;
                        httpURLConnection4.setRequestMethod(str1022);
                        str7 = str5;
                        httpURLConnection4.setConnectTimeout(r27);
                        str6 = str1022;
                        str8 = str4;
                        httpURLConnection4.setReadTimeout(r28);
                        if (z) {
                            httpURLConnection4.setRequestProperty("User-Agent", str7);
                        } else {
                            httpURLConnection4.setRequestProperty("User-Agent", str8);
                        }
                        httpURLConnection4.setRequestProperty("Accept", "application/rss+xml, application/atom+xml, application/xml, text/xml, text/html, */*");
                        httpURLConnection4.setRequestProperty("Accept-Encoding", "gzip, deflate");
                        if (z2) {
                            httpURLConnection4.setRequestProperty("Cookie", "CONSENT=YES+cb.20210328-17-p0.en+FX+410; SOCS=CAISHAgBEhJnd3NfMjAyMzA4MTAtMF9SQzIaAmVuIAEaBgiAo_CmBg");
                        }
                        int responseCode222 = httpURLConnection4.getResponseCode();
                        r11++;
                        str5 = str7;
                        str4 = str8;
                        httpURLConnection3 = httpURLConnection4;
                        url = url322;
                        responseCode = responseCode222;
                    }
                }
                headerField2 = httpURLConnection3.getHeaderField("ETag");
                headerField3 = httpURLConnection3.getHeaderField("Last-Modified");
                if (responseCode == 304) {
                    FetchResult fetchResult22 = new FetchResult(true, 304, "", null, headerField2 != null ? headerField2 : str2, headerField3 != null ? headerField3 : str3);
                    if (httpURLConnection3 != null) {
                        httpURLConnection3.disconnect();
                    }
                    return fetchResult22;
                }
                if (responseCode >= 200) {
                    errorStream = httpURLConnection3.getErrorStream();
                    if (errorStream == null) {
                        FetchResult fetchResult32 = new FetchResult(false, responseCode, "", "HTTP Error: " + responseCode);
                        if (httpURLConnection3 != null) {
                            httpURLConnection3.disconnect();
                        }
                        return fetchResult32;
                    }
                } else {
                    errorStream = httpURLConnection3.getErrorStream();
                    if (errorStream == null) {
                        FetchResult fetchResult322 = new FetchResult(false, responseCode, "", "HTTP Error: " + responseCode);
                        if (httpURLConnection3 != null) {
                            httpURLConnection3.disconnect();
                        }
                        return fetchResult322;
                    }
                }
                if ("gzip".equalsIgnoreCase(httpURLConnection3.getContentEncoding())) {
                    errorStream = new GZIPInputStream(errorStream);
                }
                contentType = httpURLConnection3.getContentType();
                strReplace = "UTF-8";
                if (contentType == null) {
                }
                bufferedReader = new BufferedReader(new InputStreamReader(errorStream, strReplace), 16384);
                sb = new StringBuilder(16384);
                cArr = new char[8192];
                while (true) {
                    r5 = bufferedReader.read(cArr);
                    if (r5 != -1) {
                        break;
                        break;
                    }
                    sb.append(cArr, 0, r5);
                }
                bufferedReader.close();
                if (responseCode < 200) {
                }
                FetchResult fetchResult42 = new FetchResult(z4, responseCode, sb.toString(), z4 ? null : "HTTP Error " + responseCode, headerField2, headerField3);
                if (httpURLConnection3 != null) {
                    httpURLConnection3.disconnect();
                }
                return fetchResult42;
            } catch (Exception e9) {
                e = e9;
            }
            if (z) {
                str9 = str9 + (str9.contains("?") ? "&_fb_noscript=1" : "?_fb_noscript=1");
            }
            URL url22 = new URL(str9);
            httpURLConnection3 = (HttpURLConnection) url22.openConnection();
        } catch (Throwable th4) {
            th = th4;
            httpURLConnection2 = httpURLConnection;
        }
    }

    public static String resolveYoutubeStreamJson(String str) throws Throwable {
        Throwable th;
        HttpURLConnection httpURLConnection;
        String str2;
        String str3;
        String str4;
        String str5;
        String str6;
        String strOptString;
        JSONArray jSONArray;
        String str7;
        JSONArray jSONArray2;
        String str8;
        String str9 = "videoId";
        String strReplaceAll = str != null ? str.replaceAll("[^a-zA-Z0-9_-]", "") : "";
        if (strReplaceAll.isEmpty()) {
            return "{\"success\":false,\"error\":\"Geçersiz video kimliği\"}";
        }
        HttpURLConnection httpURLConnection2 = null;
        try {
            try {
                httpURLConnection = (HttpURLConnection) new URL("https://www.youtube.com/youtubei/v1/player?prettyPrint=false").openConnection();
            } catch (Throwable th2) {
                th = th2;
            }
        } catch (Exception e) {
            e = e;
        }
        try {
            httpURLConnection.setRequestMethod("POST");
            httpURLConnection.setConnectTimeout(8000);
            httpURLConnection.setReadTimeout(10000);
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setRequestProperty("User-Agent", "com.google.android.apps.youtube.vr.oculus/1.60.19 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip");
            httpURLConnection.setRequestProperty("Content-Type", "application/json");
            httpURLConnection.setRequestProperty("Accept-Encoding", "gzip");
            httpURLConnection.setRequestProperty("X-YouTube-Client-Name", "28");
            httpURLConnection.setRequestProperty("X-YouTube-Client-Version", "1.60.19");
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("clientName", "ANDROID_VR");
            jSONObject.put("clientVersion", "1.60.19");
            jSONObject.put("deviceMake", "Oculus");
            jSONObject.put("deviceModel", "Quest 3");
            jSONObject.put("osName", "Android");
            jSONObject.put("osVersion", "12L");
            jSONObject.put("androidSdkVersion", 32);
            jSONObject.put("hl", "tr");
            jSONObject.put("gl", "TR");
            JSONObject jSONObject2 = new JSONObject();
            jSONObject2.put("client", jSONObject);
            JSONObject jSONObject3 = new JSONObject();
            jSONObject3.put("videoId", strReplaceAll);
            jSONObject3.put("context", jSONObject2);
            jSONObject3.put("contentCheckOk", true);
            jSONObject3.put("racyCheckOk", true);
            byte[] bytes = jSONObject3.toString().getBytes(StandardCharsets.UTF_8);
            OutputStream outputStream = httpURLConnection.getOutputStream();
            outputStream.write(bytes);
            outputStream.flush();
            outputStream.close();
            int responseCode = httpURLConnection.getResponseCode();
            InputStream errorStream = (responseCode < 200 || responseCode >= 300) ? httpURLConnection.getErrorStream() : httpURLConnection.getInputStream();
            if (errorStream == null) {
                String str10 = "{\"success\":false,\"error\":\"HTTP " + responseCode + "\"}";
                if (httpURLConnection != null) {
                    try {
                        httpURLConnection.disconnect();
                    } catch (Exception e2) {
                    }
                }
                return str10;
            }
            if ("gzip".equalsIgnoreCase(httpURLConnection.getContentEncoding())) {
                errorStream = new GZIPInputStream(errorStream);
            }
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(errorStream, StandardCharsets.UTF_8), 16384);
            StringBuilder sb = new StringBuilder(16384);
            char[] cArr = new char[8192];
            while (true) {
                int r11 = bufferedReader.read(cArr);
                if (r11 == -1) {
                    break;
                }
                sb.append(cArr, 0, r11);
            }
            bufferedReader.close();
            JSONObject jSONObject4 = new JSONObject(sb.toString());
            JSONObject jSONObjectOptJSONObject = jSONObject4.optJSONObject("playabilityStatus");
            String strOptString2 = jSONObjectOptJSONObject != null ? jSONObjectOptJSONObject.optString("status", "") : "";
            String strOptString3 = jSONObjectOptJSONObject != null ? jSONObjectOptJSONObject.optString("reason", "") : "";
            JSONObject jSONObjectOptJSONObject2 = jSONObject4.optJSONObject("streamingData");
            String strOptString4 = jSONObjectOptJSONObject2 != null ? jSONObjectOptJSONObject2.optString("hlsManifestUrl", "") : "";
            if (jSONObjectOptJSONObject2 != null) {
                JSONArray jSONArrayOptJSONArray = jSONObjectOptJSONObject2.optJSONArray("formats");
                String str11 = "url";
                if (jSONArrayOptJSONArray != null) {
                    str6 = "";
                    strOptString = str6;
                    int r7 = -1;
                    int r8 = 0;
                    while (true) {
                        str2 = strReplaceAll;
                        if (r8 >= jSONArrayOptJSONArray.length()) {
                            break;
                        }
                        JSONObject jSONObjectOptJSONObject3 = jSONArrayOptJSONArray.optJSONObject(r8);
                        if (jSONObjectOptJSONObject3 == null) {
                            str8 = str9;
                            jSONArray2 = jSONArrayOptJSONArray;
                        } else {
                            String strOptString5 = jSONObjectOptJSONObject3.optString("url", "");
                            if (strOptString5.isEmpty()) {
                                str8 = str9;
                                jSONArray2 = jSONArrayOptJSONArray;
                            } else {
                                jSONArray2 = jSONArrayOptJSONArray;
                                str8 = str9;
                                int r1 = jSONObjectOptJSONObject3.optInt("height", 360);
                                if (r1 >= r7) {
                                    strOptString = jSONObjectOptJSONObject3.optString("qualityLabel", r1 + "p");
                                    str6 = strOptString5;
                                    r7 = r1;
                                }
                            }
                        }
                        r8++;
                        strReplaceAll = str2;
                        jSONArrayOptJSONArray = jSONArray2;
                        str9 = str8;
                    }
                    str3 = str9;
                } else {
                    str2 = strReplaceAll;
                    str3 = "videoId";
                    str6 = "";
                    strOptString = str6;
                }
                JSONArray jSONArrayOptJSONArray2 = jSONObjectOptJSONObject2.optJSONArray("adaptiveFormats");
                if (jSONArrayOptJSONArray2 != null) {
                    str5 = "";
                    int r12 = -1;
                    int r72 = 0;
                    while (r72 < jSONArrayOptJSONArray2.length()) {
                        JSONObject jSONObjectOptJSONObject4 = jSONArrayOptJSONArray2.optJSONObject(r72);
                        if (jSONObjectOptJSONObject4 == null) {
                            jSONArray = jSONArrayOptJSONArray2;
                            str7 = str11;
                        } else {
                            String strOptString6 = jSONObjectOptJSONObject4.optString("mimeType", "");
                            String strOptString7 = jSONObjectOptJSONObject4.optString(str11, "");
                            if (strOptString7.isEmpty()) {
                                jSONArray = jSONArrayOptJSONArray2;
                            } else {
                                jSONArray = jSONArrayOptJSONArray2;
                                if (strOptString6.startsWith("audio/")) {
                                    str7 = str11;
                                    int r0 = jSONObjectOptJSONObject4.optInt("bitrate", 0);
                                    if (strOptString6.contains("mp4") && r0 >= r12) {
                                        r12 = r0;
                                        str5 = strOptString7;
                                    } else if (str5.isEmpty()) {
                                        str5 = strOptString7;
                                    }
                                }
                            }
                            str7 = str11;
                        }
                        r72++;
                        jSONArrayOptJSONArray2 = jSONArray;
                        str11 = str7;
                    }
                    str4 = strOptString;
                } else {
                    str5 = "";
                    str4 = strOptString;
                }
            } else {
                str2 = strReplaceAll;
                str3 = "videoId";
                str4 = "";
                str5 = str4;
                str6 = str5;
            }
            JSONObject jSONObjectOptJSONObject5 = jSONObject4.optJSONObject("videoDetails");
            String strOptString8 = jSONObjectOptJSONObject5 != null ? jSONObjectOptJSONObject5.optString("title", "") : "";
            String strOptString9 = jSONObjectOptJSONObject5 != null ? jSONObjectOptJSONObject5.optString("author", "") : "";
            int r13 = jSONObjectOptJSONObject5 != null ? jSONObjectOptJSONObject5.optInt("lengthSeconds", 0) : 0;
            if (str6.isEmpty() && strOptString4.isEmpty()) {
                JSONObject jSONObject5 = new JSONObject();
                jSONObject5.put("success", false);
                jSONObject5.put("status", strOptString2);
                if (strOptString3.isEmpty()) {
                    strOptString3 = "Video akışı bulunamadı";
                }
                jSONObject5.put("error", strOptString3);
                String string = jSONObject5.toString();
                if (httpURLConnection != null) {
                    try {
                        httpURLConnection.disconnect();
                    } catch (Exception e3) {
                    }
                }
                return string;
            }
            JSONObject jSONObject6 = new JSONObject();
            jSONObject6.put("success", true);
            jSONObject6.put(str3, str2);
            jSONObject6.put("videoUrl", !str6.isEmpty() ? str6 : strOptString4);
            if (str5.isEmpty()) {
                str5 = str6;
            }
            jSONObject6.put("audioUrl", str5);
            jSONObject6.put("hlsUrl", strOptString4);
            jSONObject6.put("quality", str4);
            jSONObject6.put("title", strOptString8);
            jSONObject6.put("author", strOptString9);
            jSONObject6.put("lengthSeconds", r13);
            String string2 = jSONObject6.toString();
            if (httpURLConnection != null) {
                try {
                    httpURLConnection.disconnect();
                } catch (Exception e4) {
                }
            }
            return string2;
        } catch (Exception e5) {
            e = e5;
            httpURLConnection2 = httpURLConnection;
            try {
                JSONObject jSONObject7 = new JSONObject();
                jSONObject7.put("success", false);
                jSONObject7.put("error", e.getMessage() != null ? e.getMessage() : "Bağlantı hatası");
                String string3 = jSONObject7.toString();
                if (httpURLConnection2 != null) {
                    try {
                        httpURLConnection2.disconnect();
                    } catch (Exception e6) {
                    }
                }
                return string3;
            } catch (Exception e7) {
                if (httpURLConnection2 != null) {
                    try {
                        httpURLConnection2.disconnect();
                    } catch (Exception e8) {
                    }
                }
                return "{\"success\":false,\"error\":\"Bağlantı hatası\"}";
            }
        } catch (Throwable th3) {
            th = th3;
            httpURLConnection2 = httpURLConnection;
            if (httpURLConnection2 == null) {
                throw th;
            }
            try {
                httpURLConnection2.disconnect();
                throw th;
            } catch (Exception e9) {
                throw th;
            }
        }
    }
}
