package com.kevki.reader;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.webkit.ConsoleMessage;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_RESULT_CODE = 2001;
    private static final int NATIVE_IMPORT_FILE_CODE = 2002;
    public static MainActivity activeInstance = null;
    private View customFullscreenView;
    private WebChromeClient.CustomViewCallback customViewCallback;
    private ValueCallback filePathCallback;
    private FrameLayout rootLayout;
    private WebAppInterface webAppInterface;
    private WebView webView;
    private boolean canGoBackInApp = false;
    private String pendingFilePickCallbackId = null;

    static View -$$Nest$fgetcustomFullscreenView(MainActivity mainActivity) {
        return mainActivity.customFullscreenView;
    }

    static WebChromeClient.CustomViewCallback -$$Nest$fgetcustomViewCallback(MainActivity mainActivity) {
        return mainActivity.customViewCallback;
    }

    static ValueCallback -$$Nest$fgetfilePathCallback(MainActivity mainActivity) {
        return mainActivity.filePathCallback;
    }

    static FrameLayout -$$Nest$fgetrootLayout(MainActivity mainActivity) {
        return mainActivity.rootLayout;
    }

    static WebAppInterface -$$Nest$fgetwebAppInterface(MainActivity mainActivity) {
        return mainActivity.webAppInterface;
    }

    static WebView -$$Nest$fgetwebView(MainActivity mainActivity) {
        return mainActivity.webView;
    }

    static void -$$Nest$fputcustomFullscreenView(MainActivity mainActivity, View view) {
        mainActivity.customFullscreenView = view;
    }

    static void -$$Nest$fputcustomViewCallback(MainActivity mainActivity, WebChromeClient.CustomViewCallback customViewCallback) {
        mainActivity.customViewCallback = customViewCallback;
    }

    static void -$$Nest$fputfilePathCallback(MainActivity mainActivity, ValueCallback valueCallback) {
        mainActivity.filePathCallback = valueCallback;
    }

    static WebResourceResponse -$$Nest$mhandleYoutubeBridgeRequest(MainActivity mainActivity, Uri uri) {
        return mainActivity.handleYoutubeBridgeRequest(uri);
    }

    static void -$$Nest$msendPickedFileResult(MainActivity mainActivity, String str, boolean z, String str2, String str3, String str4) {
        mainActivity.sendPickedFileResult(str, z, str2, str3, str4);
    }

    static boolean -$$Nest$mshouldAllowInWebView(MainActivity mainActivity, String str, boolean z) {
        return mainActivity.shouldAllowInWebView(str, z);
    }

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        activeInstance = this;
        FrameLayout frameLayout = new FrameLayout(this);
        this.rootLayout = frameLayout;
        frameLayout.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        WebView webView = new WebView(this);
        this.webView = webView;
        this.rootLayout.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        setContentView(this.rootLayout);
        WebSettings settings = this.webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setCacheMode(-1);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(false);
        settings.setTextZoom(100);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        String userAgentString = settings.getUserAgentString();
        if (userAgentString != null) {
            settings.setUserAgentString(userAgentString.replace("; wv)", ")").replace("Version/4.0 ", ""));
        }
        if (Build.VERSION.SDK_INT >= 17) {
            settings.setMediaPlaybackRequiresUserGesture(false);
        }
        if (Build.VERSION.SDK_INT >= 21) {
            settings.setMixedContentMode(0);
            CookieManager cookieManager = CookieManager.getInstance();
            cookieManager.setAcceptCookie(true);
            cookieManager.setAcceptThirdPartyCookies(this.webView, true);
        }
        WebAppInterface webAppInterface = new WebAppInterface(this, this.webView);
        this.webAppInterface = webAppInterface;
        this.webView.addJavascriptInterface(webAppInterface, "Android");
        this.webView.setWebChromeClient(new 1());
        this.webView.setWebViewClient(new 2());
        this.webView.setLayerType(0, null);
        this.webView.setBackgroundColor(-15330029);
        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().setStatusBarColor(-15330029);
            getWindow().setNavigationBarColor(-15330029);
        }
        SharedPreferences sharedPreferences = getSharedPreferences("kevki_app_meta", 0);
        if (sharedPreferences.getInt("cached_ver", 0) != 5) {
            this.webView.clearCache(true);
            sharedPreferences.edit().putInt("cached_ver", 5).apply();
        }
        this.webView.loadUrl("file:///android_asset/index.html?v=5");
        try {
            FeedSyncService.ensureNotificationChannel(this);
            Intent intent = new Intent(this, (Class<?>) FeedSyncService.class);
            if (Build.VERSION.SDK_INT >= 26) {
                startForegroundService(intent);
            } else {
                startService(intent);
            }
            FeedSyncService.scheduleRestartAlarm(this, 12000L);
        } catch (Exception e) {
        }
    }

    class 1 extends WebChromeClient {
        1() {
        }

        @Override
        public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
            return super.onConsoleMessage(consoleMessage);
        }

        @Override
        public Bitmap getDefaultVideoPoster() {
            return Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
        }

        @Override
        public boolean onShowFileChooser(WebView webView, ValueCallback valueCallback, WebChromeClient.FileChooserParams fileChooserParams) {
            if (MainActivity.-$$Nest$fgetfilePathCallback(MainActivity.this) != null) {
                MainActivity.-$$Nest$fgetfilePathCallback(MainActivity.this).onReceiveValue(null);
            }
            MainActivity.-$$Nest$fputfilePathCallback(MainActivity.this, valueCallback);
            try {
                Intent intent = new Intent("android.intent.action.GET_CONTENT");
                intent.addCategory("android.intent.category.OPENABLE");
                intent.setType("*/*");
                MainActivity.this.startActivityForResult(Intent.createChooser(intent, "OPML veya CSV Dosyası Seçin"), MainActivity.FILE_CHOOSER_RESULT_CODE);
                return true;
            } catch (Exception e) {
                MainActivity.-$$Nest$fputfilePathCallback(MainActivity.this, null);
                return false;
            }
        }

        @Override
        public void onShowCustomView(View view, WebChromeClient.CustomViewCallback customViewCallback) {
            if (MainActivity.-$$Nest$fgetcustomFullscreenView(MainActivity.this) != null) {
                customViewCallback.onCustomViewHidden();
                return;
            }
            MainActivity.-$$Nest$fputcustomFullscreenView(MainActivity.this, view);
            MainActivity.-$$Nest$fputcustomViewCallback(MainActivity.this, customViewCallback);
            MainActivity.-$$Nest$fgetwebView(MainActivity.this).setVisibility(8);
            MainActivity.-$$Nest$fgetrootLayout(MainActivity.this).addView(MainActivity.-$$Nest$fgetcustomFullscreenView(MainActivity.this), new FrameLayout.LayoutParams(-1, -1));
            MainActivity.this.getWindow().addFlags(1024);
        }

        @Override
        public void onHideCustomView() {
            if (MainActivity.-$$Nest$fgetcustomFullscreenView(MainActivity.this) == null) {
                return;
            }
            MainActivity.this.getWindow().clearFlags(1024);
            MainActivity.-$$Nest$fgetrootLayout(MainActivity.this).removeView(MainActivity.-$$Nest$fgetcustomFullscreenView(MainActivity.this));
            MainActivity.-$$Nest$fputcustomFullscreenView(MainActivity.this, null);
            if (MainActivity.-$$Nest$fgetcustomViewCallback(MainActivity.this) != null) {
                MainActivity.-$$Nest$fgetcustomViewCallback(MainActivity.this).onCustomViewHidden();
                MainActivity.-$$Nest$fputcustomViewCallback(MainActivity.this, null);
            }
            MainActivity.-$$Nest$fgetwebView(MainActivity.this).setVisibility(0);
        }
    }

    class 2 extends WebViewClient {
        2() {
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView webView, WebResourceRequest webResourceRequest) {
            WebResourceResponse webResourceResponse;
            return (Build.VERSION.SDK_INT < 21 || webResourceRequest == null || webResourceRequest.getUrl() == null || (webResourceResponse = MainActivity.-$$Nest$mhandleYoutubeBridgeRequest(MainActivity.this, webResourceRequest.getUrl())) == null) ? super.shouldInterceptRequest(webView, webResourceRequest) : webResourceResponse;
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView webView, String str) {
            WebResourceResponse webResourceResponse;
            return (str == null || !str.startsWith("https://kevki.local/youtube") || (webResourceResponse = MainActivity.-$$Nest$mhandleYoutubeBridgeRequest(MainActivity.this, Uri.parse(str))) == null) ? super.shouldInterceptRequest(webView, str) : webResourceResponse;
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView webView, WebResourceRequest webResourceRequest) {
            if (Build.VERSION.SDK_INT < 21 || webResourceRequest == null || webResourceRequest.getUrl() == null) {
                return false;
            }
            String string = webResourceRequest.getUrl().toString();
            if (MainActivity.-$$Nest$mshouldAllowInWebView(MainActivity.this, string, webResourceRequest.isForMainFrame())) {
                return false;
            }
            MainActivity.-$$Nest$fgetwebAppInterface(MainActivity.this).openExternal(string);
            return true;
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView webView, String str) {
            if (MainActivity.-$$Nest$mshouldAllowInWebView(MainActivity.this, str, true)) {
                return false;
            }
            MainActivity.-$$Nest$fgetwebAppInterface(MainActivity.this).openExternal(str);
            return true;
        }

        @Override
        public void onPageFinished(WebView webView, String str) {
            super.onPageFinished(webView, str);
            if (str != null && str.startsWith("file:///android_asset/index.html")) {
                MainActivity mainActivity = MainActivity.this;
                mainActivity.handleIncomingIntent(mainActivity.getIntent());
            }
        }
    }

    class 3 implements Runnable {
        final String val$callbackId;

        3(String str) {
            this.val$callbackId = str;
        }

        @Override
        public void run() {
            Intent intent;
            try {
                if (Build.VERSION.SDK_INT >= 19) {
                    intent = new Intent("android.intent.action.OPEN_DOCUMENT");
                } else {
                    intent = new Intent("android.intent.action.GET_CONTENT");
                }
                intent.addCategory("android.intent.category.OPENABLE");
                intent.setType("*/*");
                MainActivity.this.startActivityForResult(Intent.createChooser(intent, "OPML veya CSV Dosyası Seçin"), MainActivity.NATIVE_IMPORT_FILE_CODE);
            } catch (Exception e) {
                MainActivity.-$$Nest$msendPickedFileResult(MainActivity.this, this.val$callbackId, false, "", "", e.getMessage() != null ? e.getMessage() : "Dosya seçici açılamadı");
            }
        }
    }

    public void launchNativeFilePicker(String str) {
        this.pendingFilePickCallbackId = str;
        runOnUiThread(new 3(str));
    }

    @Override
    protected void onActivityResult(int r10, int r11, Intent intent) {
        Uri[] uriArr;
        String dataString;
        super.onActivityResult(r10, r11, intent);
        if (r10 == FILE_CHOOSER_RESULT_CODE) {
            if (this.filePathCallback == null) {
                return;
            }
            if (r11 == -1 && intent != null && (dataString = intent.getDataString()) != null) {
                uriArr = new Uri[]{Uri.parse(dataString)};
            } else {
                uriArr = null;
            }
            this.filePathCallback.onReceiveValue(uriArr);
            this.filePathCallback = null;
            return;
        }
        if (r10 == NATIVE_IMPORT_FILE_CODE) {
            String str = this.pendingFilePickCallbackId;
            this.pendingFilePickCallbackId = null;
            if (str == null) {
                return;
            }
            if (r11 != -1 || intent == null || intent.getData() == null) {
                sendPickedFileResult(str, false, "", "", "İptal edildi");
            } else {
                new Thread(new 4(intent.getData(), str)).start();
            }
        }
    }

    class 4 implements Runnable {
        final String val$cbId;
        final Uri val$uri;

        4(Uri uri, String str) {
            this.val$uri = uri;
            this.val$cbId = str;
        }

        @Override
        public void run() {
            String str;
            int columnIndex;
            String string;
            try {
                String str2 = "import.opml";
                Cursor cursorQuery = MainActivity.this.getContentResolver().query(this.val$uri, null, null, null, null);
                if (cursorQuery == null) {
                    str = "import.opml";
                } else {
                    try {
                        if (cursorQuery.moveToFirst() && (columnIndex = cursorQuery.getColumnIndex("_display_name")) >= 0 && (string = cursorQuery.getString(columnIndex)) != null && !string.isEmpty()) {
                            str2 = string;
                        }
                        cursorQuery.close();
                        str = str2;
                    } catch (Throwable th) {
                        cursorQuery.close();
                        throw th;
                    }
                }
                InputStream inputStreamOpenInputStream = MainActivity.this.getContentResolver().openInputStream(this.val$uri);
                if (inputStreamOpenInputStream == null) {
                    MainActivity.-$$Nest$msendPickedFileResult(MainActivity.this, this.val$cbId, false, str, "", "Dosya okunamadı");
                    return;
                }
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStreamOpenInputStream, StandardCharsets.UTF_8), 16384);
                StringBuilder sb = new StringBuilder();
                char[] cArr = new char[8192];
                while (true) {
                    int r5 = bufferedReader.read(cArr);
                    if (r5 != -1) {
                        sb.append(cArr, 0, r5);
                    } else {
                        bufferedReader.close();
                        inputStreamOpenInputStream.close();
                        MainActivity.-$$Nest$msendPickedFileResult(MainActivity.this, this.val$cbId, true, str, sb.toString(), "");
                        return;
                    }
                }
            } catch (Exception e) {
                MainActivity.-$$Nest$msendPickedFileResult(MainActivity.this, this.val$cbId, false, "", "", e.getMessage() != null ? e.getMessage() : "Dosya okuma hatası");
            }
        }
    }

    class 5 implements Runnable {
        final String val$callbackId;
        final String val$content;
        final String val$error;
        final String val$fileName;
        final boolean val$success;

        5(String str, boolean z, String str2, String str3, String str4) {
            this.val$callbackId = str;
            this.val$success = z;
            this.val$fileName = str2;
            this.val$content = str3;
            this.val$error = str4;
        }

        @Override
        public void run() {
            if (MainActivity.-$$Nest$fgetwebView(MainActivity.this) != null) {
                MainActivity.-$$Nest$fgetwebView(MainActivity.this).evaluateJavascript(String.format("if (window.onNativeFilePicked) { window.onNativeFilePicked(%s, %b, %s, %s, %s); }", WebAppInterface.escapeJson(this.val$callbackId), Boolean.valueOf(this.val$success), WebAppInterface.escapeJson(this.val$fileName), WebAppInterface.escapeJson(this.val$content), WebAppInterface.escapeJson(this.val$error)), null);
            }
        }
    }

    private void sendPickedFileResult(String str, boolean z, String str2, String str3, String str4) {
        runOnUiThread(new 5(str, z, str2, str3, str4));
    }

    private boolean shouldAllowInWebView(String str, boolean z) {
        if (str == null) {
            return false;
        }
        if (str.startsWith("file:///android_asset/") || str.startsWith("https://kevki.local/") || str.startsWith("about:blank") || str.contains("youtube.com/embed/") || str.contains("youtube-nocookie.com/embed/") || str.contains("youtube.com/s/player/") || str.contains("googlevideo.com") || str.contains("ytimg.com")) {
            return true;
        }
        return !z && (str.startsWith("https://www.google.com/") || str.startsWith("https://accounts.google.com/"));
    }

    private WebResourceResponse handleYoutubeBridgeRequest(Uri uri) {
        String path;
        if (uri == null || !"kevki.local".equalsIgnoreCase(uri.getHost()) || (path = uri.getPath()) == null || !path.startsWith("/youtube")) {
            return null;
        }
        String queryParameter = uri.getQueryParameter("v");
        if (queryParameter == null) {
            queryParameter = "";
        }
        return new WebResourceResponse("text/html", "UTF-8", new ByteArrayInputStream(("<!DOCTYPE html><html><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no\"><meta name=\"referrer\" content=\"origin\"><style>*{margin:0;padding:0;box-sizing:border-box;background:#000;}html,body{width:100%;height:100%;overflow:hidden;background:#000;}iframe{position:absolute;top:0;left:0;width:100%;height:100%;border:0;}</style></head><body><iframe src=\"https://www.youtube.com/embed/" + queryParameter.replaceAll("[^a-zA-Z0-9_-]", "") + "?playsinline=1&rel=0&modestbranding=1&autoplay=" + ("1".equals(uri.getQueryParameter("autoplay")) ? "1" : "0") + "&enablejsapi=1&origin=https%3A%2F%2Fkevki.local\" referrerpolicy=\"origin\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share; fullscreen\" allowfullscreen></iframe></body></html>").getBytes(StandardCharsets.UTF_8)));
    }

    public void setCanGoBackInApp(boolean z) {
        this.canGoBackInApp = z;
    }

    class 6 implements Runnable {
        6() {
        }

        @Override
        public void run() {
            if (MainActivity.-$$Nest$fgetwebView(MainActivity.this) != null) {
                MainActivity.-$$Nest$fgetwebView(MainActivity.this).evaluateJavascript("if (window.app && window.app.onBackgroundPollUpdate) { window.app.onBackgroundPollUpdate(); }", null);
            }
        }
    }

    public void notifyWebViewNewItems() {
        runOnUiThread(new 6());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncomingIntent(intent);
    }

    public void handleIncomingIntent(Intent intent) {
        if (intent == null) {
            return;
        }
        if (intent.hasExtra("articleId")) {
            String stringExtra = intent.getStringExtra("articleId");
            intent.removeExtra("articleId");
            if (stringExtra != null && !stringExtra.isEmpty()) {
                this.webView.postDelayed(new 7(stringExtra), 350L);
            }
        }
        if ("android.intent.action.SEND".equals(intent.getAction()) && "text/plain".equals(intent.getType())) {
            String stringExtra2 = intent.getStringExtra("android.intent.extra.TEXT");
            String stringExtra3 = intent.getStringExtra("android.intent.extra.SUBJECT");
            intent.setAction("android.intent.action.MAIN");
            if (stringExtra2 != null && !stringExtra2.isEmpty()) {
                this.webView.postDelayed(new 8(stringExtra2, stringExtra3), 450L);
            }
        }
    }

    class 7 implements Runnable {
        final String val$articleId;

        7(String str) {
            this.val$articleId = str;
        }

        @Override
        public void run() {
            MainActivity.-$$Nest$fgetwebView(MainActivity.this).evaluateJavascript(String.format("if (window.app && window.app.openArticleFromNotification) { window.app.openArticleFromNotification(%s); }", WebAppInterface.escapeJson(this.val$articleId)), null);
        }
    }

    class 8 implements Runnable {
        final String val$sharedSubject;
        final String val$sharedText;

        8(String str, String str2) {
            this.val$sharedText = str;
            this.val$sharedSubject = str2;
        }

        @Override
        public void run() {
            WebView webView = MainActivity.-$$Nest$fgetwebView(MainActivity.this);
            Object[] objArr = new Object[2];
            objArr[0] = WebAppInterface.escapeJson(this.val$sharedText);
            String str = this.val$sharedSubject;
            if (str == null) {
                str = "";
            }
            objArr[1] = WebAppInterface.escapeJson(str);
            webView.evaluateJavascript(String.format("if (window.app && window.app.handleSharedContent) { window.app.handleSharedContent(%s, %s); }", objArr), null);
        }
    }

    public void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != 0) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1001);
        }
    }

    @Override
    public void onBackPressed() {
        if (this.customFullscreenView != null) {
            this.webView.getWebChromeClient().onHideCustomView();
        } else if (this.canGoBackInApp) {
            this.webView.evaluateJavascript("window.handleNativeBackPressed && window.handleNativeBackPressed();", null);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (activeInstance == this) {
            activeInstance = null;
        }
        super.onDestroy();
    }
}
