package com.kevki.reader;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) {
            return;
        }
        String action = intent.getAction();
        if ("android.intent.action.BOOT_COMPLETED".equals(action) || "android.intent.action.MY_PACKAGE_REPLACED".equals(action) || "android.intent.action.QUICKBOOT_POWERON".equals(action) || "com.kevki.reader.ACTION_POLL_FEEDS".equals(action)) {
            Context applicationContext = context.getApplicationContext();
            FeedSyncService.scheduleRestartAlarm(applicationContext, 12000L);
            try {
                Intent intent2 = new Intent(applicationContext, (Class<?>) FeedSyncService.class);
                intent2.setAction("ACTION_START_OR_POLL");
                if (Build.VERSION.SDK_INT >= 26) {
                    applicationContext.startForegroundService(intent2);
                } else {
                    applicationContext.startService(intent2);
                }
            } catch (Exception e) {
                FeedSyncService.triggerImmediatePollWithFinish(applicationContext, goAsync());
            }
        }
    }
}
