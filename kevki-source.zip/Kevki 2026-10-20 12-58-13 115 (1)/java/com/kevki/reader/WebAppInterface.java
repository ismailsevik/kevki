package com.kevki.reader;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Toast;
import com.kevki.reader.NetworkHelper;
import java.util.HashSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONArray;
import org.json.JSONObject;

public class WebAppInterface {
    public static final String BILLING_PREFS = "kevki_billing_prefs";
    private final MainActivity activity;
    private final ExecutorService executorService = Executors.newFixedThreadPool(12);
    private final WebView webView;

    static MainActivity -$$Nest$fgetactivity(WebAppInterface webAppInterface) {
        return webAppInterface.activity;
    }

    static WebView -$$Nest$fgetwebView(WebAppInterface webAppInterface) {
        return webAppInterface.webView;
    }

    static void -$$Nest$msendPurchaseResult(WebAppInterface webAppInterface, String str, String str2) {
        webAppInterface.sendPurchaseResult(str, str2);
    }

    public WebAppInterface(MainActivity mainActivity, WebView webView) {
        this.activity = mainActivity;
        this.webView = webView;
    }

    class 1 implements Runnable {
        final boolean val$canGoBack;

        1(boolean z) {
            this.val$canGoBack = z;
        }

        @Override
        public void run() {
            WebAppInterface.-$$Nest$fgetactivity(WebAppInterface.this).setCanGoBackInApp(this.val$canGoBack);
        }
    }

    @JavascriptInterface
    public void setNavState(boolean z) {
        this.activity.runOnUiThread(new 1(z));
    }

    @JavascriptInterface
    public void pickImportFile(String str) {
        this.activity.launchNativeFilePicker(str);
    }

    class 2 implements Runnable {
        final String val$callbackId;
        final String val$url;

        2(String str, String str2) {
            this.val$url = str;
            this.val$callbackId = str2;
        }

        @Override
        public void run() {
            NetworkHelper.FetchResult fetchResultFetch = NetworkHelper.fetch(this.val$url);
            WebAppInterface.-$$Nest$fgetactivity(WebAppInterface.this).runOnUiThread(new 1(fetchResultFetch.success, fetchResultFetch.statusCode, fetchResultFetch.data != null ? fetchResultFetch.data : "", fetchResultFetch.errorMessage != null ? fetchResultFetch.errorMessage : ""));
        }

        class 1 implements Runnable {
            final String val$data;
            final String val$error;
            final int val$status;
            final boolean val$success;

            1(boolean z, int r3, String str, String str2) {
                this.val$success = z;
                this.val$status = r3;
                this.val$data = str;
                this.val$error = str2;
            }

            @Override
            public void run() {
                WebAppInterface.-$$Nest$fgetwebView(WebAppInterface.this).evaluateJavascript(String.format("if (window.onNativeFetchResult) { window.onNativeFetchResult(%s, %b, %d, %s, %s); }", WebAppInterface.escapeJson(2.this.val$callbackId), Boolean.valueOf(this.val$success), Integer.valueOf(this.val$status), WebAppInterface.escapeJson(this.val$data), WebAppInterface.escapeJson(this.val$error)), null);
            }
        }
    }

    @JavascriptInterface
    public void fetchUrl(String str, String str2) {
        this.executorService.execute(new 2(str, str2));
    }

    class 3 implements Runnable {
        final String val$callbackId;
        final String val$videoId;

        3(String str, String str2) {
            this.val$videoId = str;
            this.val$callbackId = str2;
        }

        class 1 implements Runnable {
            final String val$jsonResult;

            1(String str) {
                this.val$jsonResult = str;
            }

            @Override
            public void run() {
                WebAppInterface.-$$Nest$fgetwebView(WebAppInterface.this).evaluateJavascript(String.format("if (window.onNativeYoutubeStreamResult) { window.onNativeYoutubeStreamResult(%s, %s); }", WebAppInterface.escapeJson(3.this.val$callbackId), WebAppInterface.escapeJson(this.val$jsonResult)), null);
            }
        }

        @Override
        public void run() {
            WebAppInterface.-$$Nest$fgetactivity(WebAppInterface.this).runOnUiThread(new 1(NetworkHelper.resolveYoutubeStreamJson(this.val$videoId)));
        }
    }

    @JavascriptInterface
    public void resolveYoutubeVideo(String str, String str2) {
        this.executorService.execute(new 3(str, str2));
    }

    @JavascriptInterface
    public String getBillingState() {
        try {
            SharedPreferences sharedPreferences = this.activity.getSharedPreferences(BILLING_PREFS, 0);
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("isPro", sharedPreferences.getBoolean("is_pro", false));
            jSONObject.put("sku", sharedPreferences.getString("plan_sku", "kevki_pro_lifetime"));
            jSONObject.put("planTitle", sharedPreferences.getString("plan_title", "Ömür Boyu Premium (Tek Seferlik)"));
            jSONObject.put("priceText", sharedPreferences.getString("price_text", "₺399,99"));
            jSONObject.put("orderId", sharedPreferences.getString("order_id", ""));
            jSONObject.put("purchaseTime", sharedPreferences.getLong("purchase_time", 0L));
            return jSONObject.toString();
        } catch (Exception e) {
            return "{\"isPro\":false}";
        }
    }

    class 4 implements Runnable {
        final String val$callbackId;
        final String val$priceText;

        4(String str, String str2) {
            this.val$priceText = str;
            this.val$callbackId = str2;
        }

        @Override
        public void run() {
            try {
                AlertDialog.Builder builder = new AlertDialog.Builder(WebAppInterface.-$$Nest$fgetactivity(WebAppInterface.this), 16974374);
                builder.setTitle("Ömür Boyu Premium (Tek Seferlik)");
                builder.setMessage("Paket: Ömür Boyu Tek Seferlik Erişim\nTutar: " + this.val$priceText + " (Tek Seferlik Ödeme)\n\nTüm özelliklerin kilidini ömür boyu kalıcı olarak açmak için satın alma işlemini onaylıyor musunuz?");
                builder.setPositiveButton("Tek Seferlik Satın Al", new 1());
                builder.setNegativeButton("İptal", new 2());
                builder.setOnCancelListener(new 3());
                builder.show();
            } catch (Exception e) {
                WebAppInterface.-$$Nest$msendPurchaseResult(WebAppInterface.this, this.val$callbackId, "{\"success\":false,\"error\":\"Satın alma ekranı açılamadı\"}");
            }
        }

        class 1 implements DialogInterface.OnClickListener {
            1() {
            }

            @Override
            public void onClick(DialogInterface dialogInterface, int r10) {
                long jCurrentTimeMillis = System.currentTimeMillis();
                String str = "GPA.3392-" + ((jCurrentTimeMillis % 9000) + 1000) + "-" + (((jCurrentTimeMillis / 1000) % 9000) + 1000) + "-84210";
                WebAppInterface.-$$Nest$fgetactivity(WebAppInterface.this).getSharedPreferences(WebAppInterface.BILLING_PREFS, 0).edit().putBoolean("is_pro", true).putString("plan_sku", "kevki_pro_lifetime").putString("plan_title", "Ömür Boyu Premium (Tek Seferlik)").putString("price_text", 4.this.val$priceText).putString("order_id", str).putLong("purchase_time", jCurrentTimeMillis).apply();
                WebAppInterface.this.triggerHaptic(1);
                try {
                    JSONObject jSONObject = new JSONObject();
                    jSONObject.put("success", true);
                    jSONObject.put("isPro", true);
                    jSONObject.put("sku", "kevki_pro_lifetime");
                    jSONObject.put("planTitle", "Ömür Boyu Premium (Tek Seferlik)");
                    jSONObject.put("priceText", 4.this.val$priceText);
                    jSONObject.put("orderId", str);
                    jSONObject.put("purchaseTime", jCurrentTimeMillis);
                    WebAppInterface.-$$Nest$msendPurchaseResult(WebAppInterface.this, 4.this.val$callbackId, jSONObject.toString());
                } catch (Exception e) {
                }
            }
        }

        class 2 implements DialogInterface.OnClickListener {
            2() {
            }

            @Override
            public void onClick(DialogInterface dialogInterface, int r3) {
                WebAppInterface.-$$Nest$msendPurchaseResult(WebAppInterface.this, 4.this.val$callbackId, "{\"success\":false,\"cancelled\":true,\"error\":\"İşlem iptal edildi\"}");
            }
        }

        class 3 implements DialogInterface.OnCancelListener {
            3() {
            }

            @Override
            public void onCancel(DialogInterface dialogInterface) {
                WebAppInterface.-$$Nest$msendPurchaseResult(WebAppInterface.this, 4.this.val$callbackId, "{\"success\":false,\"cancelled\":true,\"error\":\"İşlem iptal edildi\"}");
            }
        }
    }

    @JavascriptInterface
    public void launchPurchaseFlow(String str, String str2, String str3, String str4) {
        this.activity.runOnUiThread(new 4(str3, str4));
    }

    class 5 implements Runnable {
        final String val$callbackId;

        5(String str) {
            this.val$callbackId = str;
        }

        @Override
        public void run() {
            WebAppInterface.-$$Nest$fgetactivity(WebAppInterface.this).getSharedPreferences(WebAppInterface.BILLING_PREFS, 0).edit().clear().apply();
            WebAppInterface.-$$Nest$msendPurchaseResult(WebAppInterface.this, this.val$callbackId, "{\"success\":true,\"isPro\":false}");
        }
    }

    @JavascriptInterface
    public void cancelSubscription(String str) {
        this.activity.runOnUiThread(new 5(str));
    }

    private void sendPurchaseResult(String str, String str2) {
        this.webView.evaluateJavascript(String.format("if (window.onNativePurchaseResult) { window.onNativePurchaseResult(%s, %s); }", escapeJson(str), escapeJson(str2)), null);
    }

    class 6 implements Runnable {
        final String val$feedsJson;
        final boolean val$globalNotifyEnabled;
        final String val$seenIdsJson;

        6(String str, boolean z, String str2) {
            this.val$seenIdsJson = str;
            this.val$globalNotifyEnabled = z;
            this.val$feedsJson = str2;
        }

        @Override
        public void run() {
            try {
                Context applicationContext = WebAppInterface.-$$Nest$fgetactivity(WebAppInterface.this).getApplicationContext();
                SharedPreferences sharedPreferences = applicationContext.getSharedPreferences("kevki_bg_sync", 0);
                HashSet hashSet = new HashSet(sharedPreferences.getStringSet("seen_ids", new HashSet()));
                String str = this.val$seenIdsJson;
                if (str != null && !str.isEmpty()) {
                    JSONArray jSONArray = new JSONArray(this.val$seenIdsJson);
                    for (int r7 = 0; r7 < jSONArray.length(); r7++) {
                        String strOptString = jSONArray.optString(r7, "");
                        if (!strOptString.isEmpty()) {
                            hashSet.add(strOptString);
                        }
                    }
                }
                SharedPreferences.Editor editorEdit = sharedPreferences.edit();
                editorEdit.putBoolean("global_notify_enabled", this.val$globalNotifyEnabled);
                String str2 = this.val$feedsJson;
                if (str2 != null) {
                    editorEdit.putString("feeds_json", str2);
                    try {
                        JSONArray jSONArray2 = new JSONArray(this.val$feedsJson);
                        for (int r3 = 0; r3 < jSONArray2.length(); r3++) {
                            JSONObject jSONObjectOptJSONObject = jSONArray2.optJSONObject(r3);
                            if (jSONObjectOptJSONObject != null) {
                                String strOptString2 = jSONObjectOptJSONObject.optString("id", "");
                                if (strOptString2.isEmpty()) {
                                    continue;
                                } else {
                                    editorEdit.putBoolean("init_" + strOptString2, true);
                                }
                            }
                        }
                    } catch (Exception e) {
                    }
                }
                editorEdit.putStringSet("seen_ids", hashSet);
                editorEdit.apply();
                Intent intent = new Intent(applicationContext, (Class<?>) FeedSyncService.class);
                if (Build.VERSION.SDK_INT >= 26) {
                    applicationContext.startForegroundService(intent);
                } else {
                    applicationContext.startService(intent);
                }
                FeedSyncService.scheduleRestartAlarm(applicationContext, 12000L);
            } catch (Exception e2) {
            }
        }
    }

    @JavascriptInterface
    public void syncBackgroundState(String str, boolean z, String str2) {
        this.executorService.execute(new 6(str2, z, str));
    }

    @JavascriptInterface
    public void shareArticle(String str, String str2) {
        try {
            Intent intent = new Intent("android.intent.action.SEND");
            intent.setType("text/plain");
            intent.putExtra("android.intent.extra.SUBJECT", str);
            intent.putExtra("android.intent.extra.TEXT", str + "\n" + str2);
            this.activity.startActivity(Intent.createChooser(intent, "Paylaş"));
        } catch (Exception e) {
            showToast("Paylaşılamadı: " + e.getMessage());
        }
    }

    @JavascriptInterface
    public void openExternal(String str) {
        if (str != null) {
            try {
                if (!str.isEmpty()) {
                    this.activity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(str)));
                }
            } catch (Exception e) {
                showToast("Bağlantı açılamadı: " + e.getMessage());
            }
        }
    }

    class 7 implements Runnable {
        final String val$message;

        7(String str) {
            this.val$message = str;
        }

        @Override
        public void run() {
            Toast.makeText(WebAppInterface.-$$Nest$fgetactivity(WebAppInterface.this), this.val$message, 0).show();
        }
    }

    @JavascriptInterface
    public void showToast(String str) {
        this.activity.runOnUiThread(new 7(str));
    }

    @JavascriptInterface
    public void triggerHaptic(int r4) {
        try {
            Vibrator vibrator = (Vibrator) this.activity.getSystemService("vibrator");
            if (vibrator != null && vibrator.hasVibrator()) {
                int r42 = r4 == 1 ? 45 : 22;
                if (Build.VERSION.SDK_INT >= 26) {
                    vibrator.vibrate(VibrationEffect.createOneShot(r42, -1));
                } else {
                    vibrator.vibrate(r42);
                }
            }
        } catch (Exception e) {
        }
    }

    class 8 implements Runnable {
        final boolean val$darkIcons;
        final String val$hexColor;

        8(String str, boolean z) {
            this.val$hexColor = str;
            this.val$darkIcons = z;
        }

        @Override
        public void run() {
            int r1;
            try {
                Window window = WebAppInterface.-$$Nest$fgetactivity(WebAppInterface.this).getWindow();
                int color = Color.parseColor(this.val$hexColor);
                if (Build.VERSION.SDK_INT >= 21) {
                    window.setStatusBarColor(color);
                    window.setNavigationBarColor(color);
                }
                if (Build.VERSION.SDK_INT >= 23) {
                    View decorView = window.getDecorView();
                    int systemUiVisibility = decorView.getSystemUiVisibility();
                    if (this.val$darkIcons) {
                        r1 = systemUiVisibility | 8192;
                    } else {
                        r1 = systemUiVisibility & (-8193);
                    }
                    decorView.setSystemUiVisibility(r1);
                }
            } catch (Exception e) {
            }
        }
    }

    @JavascriptInterface
    public void setStatusBarColor(String str, boolean z) {
        this.activity.runOnUiThread(new 8(str, z));
    }

    @JavascriptInterface
    public String getAppVersion() {
        return "5.0.0";
    }

    class 9 implements Runnable {
        9() {
        }

        @Override
        public void run() {
            WebAppInterface.-$$Nest$fgetactivity(WebAppInterface.this).requestNotificationPermission();
        }
    }

    @JavascriptInterface
    public void requestNotificationPermission() {
        this.activity.runOnUiThread(new 9());
    }

    @JavascriptInterface
    public boolean areNotificationsEnabled() {
        return Build.VERSION.SDK_INT < 33 || this.activity.checkSelfPermission("android.permission.POST_NOTIFICATIONS") == 0;
    }

    class 10 implements Runnable {
        final String val$articleId;
        final String val$message;
        final int val$notificationId;
        final String val$title;

        10(String str, String str2, String str3, int r5) {
            this.val$title = str;
            this.val$message = str2;
            this.val$articleId = str3;
            this.val$notificationId = r5;
        }

        @Override
        public void run() {
            FeedSyncService.sendInstantNotification(WebAppInterface.-$$Nest$fgetactivity(WebAppInterface.this), this.val$title, this.val$message, this.val$articleId, this.val$notificationId);
        }
    }

    @JavascriptInterface
    public void showNotification(String str, String str2, String str3, int r12) {
        this.activity.runOnUiThread(new 10(str, str2, str3, r12));
    }

    class 11 implements Runnable {
        final String val$articleId;
        final String val$message;
        final int val$notificationId;
        final String val$title;

        11(String str, String str2, String str3, int r5) {
            this.val$title = str;
            this.val$message = str2;
            this.val$articleId = str3;
            this.val$notificationId = r5;
        }

        @Override
        public void run() {
            FeedSyncService.sendInstantNotification(WebAppInterface.-$$Nest$fgetactivity(WebAppInterface.this), this.val$title, this.val$message, this.val$articleId, this.val$notificationId);
        }
    }

    public static String escapeJson(String str) {
        if (str == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder("\"");
        for (int r3 = 0; r3 < str.length(); r3++) {
            char cCharAt = str.charAt(r3);
            switch (cCharAt) {
                case '\b':
                    sb.append("\\b");
                    break;
                case '\t':
                    sb.append("\\t");
                    break;
                case '\n':
                    sb.append("\\n");
                    break;
                case '\f':
                    sb.append("\\f");
                    break;
                case '\r':
                    sb.append("\\r");
                    break;
                case '\"':
                    sb.append("\\\"");
                    break;
                case '\\':
                    sb.append("\\\\");
                    break;
                case 8232:
                    sb.append("\\u2028");
                    break;
                case 8233:
                    sb.append("\\u2029");
                    break;
                default:
                    if (cCharAt < ' ') {
                        sb.append(String.format("\\u%04x", Integer.valueOf(cCharAt)));
                    } else {
                        sb.append(cCharAt);
                    }
                    break;
            }
        }
        sb.append("\"");
        return sb.toString();
    }
}
