package com.kevki.reader;

public final class R {

    public static final class attr {
    }

    public static final class color {
        public static final int accent = 0x7f040002;
        public static final int feedbin_bg = 0x7f040003;
        public static final int feedbin_border = 0x7f040005;
        public static final int feedbin_sidebar = 0x7f040004;
        public static final int primary = 0x7f040000;
        public static final int primary_dark = 0x7f040001;
    }

    public static final class mipmap {
        public static final int ic_launcher = 0x7f020000;
    }

    public static final class string {
        public static final int app_name = 0x7f050000;
        public static final int feedbin_desc = 0x7f050001;
    }

    public static final class style {
        public static final int AppTheme = 0x7f060000;
    }

    public static final class xml {
        public static final int network_security_config = 0x7f030000;
    }
}
